################## Steps todos cenarios que buscam clientes ##################
Dado("consultar por {string}") do |tipo_cliente|
    @atendimento.menu_cliente.consultar_tipo_cliente(tipo_cliente)
end

Dado("realizar a busca do cliente {string}") do |cliente|
    puts cliente
    @atendimento.menu_cliente.consultar_cliente(cliente)
    @atendimento.demanda_cliente.validar_cliente
    @atendimento.demanda_cliente.situacao_cliente
end

################## Steps especifico da funcionalidade: "Buscar Cliente" ##################

Dado("realizar uma busca para o cliente {string}") do |cliente|
    @atendimento.menu_cliente.consultar_cliente(cliente)
    if page.has_text?("Selecione o tipo da conta que o cliente deseja acessar.")
        @atendimento.menu_cliente.selecionar_conta
        @atendimento.demanda_cliente.validar_cliente
    end
end

Dado("realizar uma busca por cliente {string} com várias contas") do |cliente|
    @atendimento.menu_cliente.consultar_cliente(cliente)
end

######################## Cliente PF ##################################
Então("devo confirmar dados do cliente") do
    @atendimento.demanda_cliente.confirmar_dados_cliente
end

Então("deve mostrar Alerta informativo.") do
    @atendimento.demanda_cliente.situacao_cliente
end

################## Não Localizado PF e PJ ##################
Então("retorna cliente não encontrado") do 
    @atendimento.demanda_cliente.validar_nao_localizado
end

################## Não cliente PF e PJ##################

Então("confirma busca") do
    @atendimento.demanda_cliente.busca_nao_cliente
end

################## Bloqueio VR ##################
Então("deve mostrar Alerta {string}") do |mensagem_bloqueiovr|
    expect(@atendimento.demanda_cliente.bloqueio_vr).to have_content mensagem_bloqueiovr
end

################## Contrato não Ativo ##################
Então("deve mostrar alerta contrato não ativo") do
    @atendimento.demanda_cliente.cont_nao_ativo
end

################## Tipo conta ##################
Dado("realizar uma busca por cliente {string}") do |cliente|
    @atendimento.menu_cliente.consultar_cliente(cliente)
end

Dado("selecione conta") do
    @atendimento.menu_cliente.conta_diferente
end

################## COBRANÇA EXTERNA ##################
Então("deve mostrar Alerta Cobrança Externa") do
    @atendimento.demanda_cliente.cobranca_ext
end

################## PRE PAGO ##################
Então("deve constar informação {string} no menu lateral") do |forma_pagamento|
    expect(@atendimento.demanda_cliente.consulta_prepago).to have_content forma_pagamento
end

################# PRE PAGO VALOR ZERADO #################
Então("retorna valor de disparo igual a {string}") do |mensagem_prepago_zerado|
    expect(@atendimento.demanda_cliente.prepago_zerado).to have_content mensagem_prepago_zerado
end