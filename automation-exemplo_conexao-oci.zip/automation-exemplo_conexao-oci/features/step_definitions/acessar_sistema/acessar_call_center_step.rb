Dado("que estou na tela de login do Call Center") do
	@atendimento = CallCenter.new
	@atendimento.load
end

#ALTERADO
Quando("realizar o login com usuário e senha válido {string}") do |tipo_empresa|
	@atendimento.login.login(tipo_empresa)
end


Então("o login é realizado com sucesso") do
    #expect(@atendimento).to have_content("Olá, #{USUARIO_ACESSO[:login_admin]}")
    @atendimento.menu_atendimento.iniciar_atendimento
end

E("selecionar o perfil do atendimento {string}") do |tipo_perfil|
    @atendimento.demanda_atendimento.selecionar_perfil(tipo_perfil)
end

Então("visualizar o número de protocolo do atendimento") do
	expect(@atendimento.demanda_atendimento.numero_protocolo) != nil
end


#DEFAULT => Realiza o atendimento utilizando o operador-admin com o perfil Administrador
#Utilizado em todos os cenários
Dado("que estou realizando um atendimento no Call Center") do
	steps %Q{
		Dado que estou na tela de login do Call Center
        Quando realizar o login com usuário e senha válido "Sem Parar"
        Então o login é realizado com sucesso
        E selecionar o perfil do atendimento "Administrador"
		Então visualizar o número de protocolo do atendimento
        
	}
end

#Realiza o login para validar vários perfis de atendimento
Dado("que estou realizando o login no Call Center") do
	steps %Q{
		Dado que estou na tela de login do Call Center
		Quando realizar o login com usuário e senha válido "Sem Parar"
        Então o login é realizado com sucesso
	}
end

#NOVO
#Realiza o atendimento utilizando o operador-caixa com o perfil Administrador.
#Utilizado nos cenários da caixa
Dado("que estou realizando o login no Call Center para clientes JV Caixa") do
	steps %Q{
		Dado que estou na tela de login do Call Center
        Quando realizar o login com usuário e senha válido "JV Caixa"
        Então o login é realizado com sucesso
		E selecionar o perfil do atendimento "Administrador."
		Então visualizar o número de protocolo do atendimento
	}
end