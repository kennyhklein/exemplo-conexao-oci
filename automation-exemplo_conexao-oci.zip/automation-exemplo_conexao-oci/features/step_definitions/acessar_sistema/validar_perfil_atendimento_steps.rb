


Então("verifico a exibição das demandas do primeiro nível referente o perfil {string}") do |tipo_perfil|
    #@atendimento.perfil_atendimento.verfica_demanda_primeiro_nivel(tipo_perfil)
    expect(@atendimento.perfil_atendimento.verfica_demanda_primeiro_nivel(tipo_perfil)).to be true

end

Quando("no perfil {string} selecionar a demanda {string} e verificar as funcionalidades exibidas") do |tipo_perfil, demanda|
    #@atendimento.perfil_atendimento.seleciona_demanda(tipo_perfil, demanda)
    expect(@atendimento.perfil_atendimento.seleciona_demanda(tipo_perfil, demanda)).to be true
end


Quando("confirmo que embarcador não possui veículo ativo") do 
    @atendimento.perfil_atendimento.seleciona_avancar
end

Quando("acesso todas as demandas do menu inicial") do
    @atendimento.perfil_atendimento.acessa_demandas_menu_inicial_retencao
end

Então("finalizo o atendimento") do
    @atendimento.perfil_atendimento.finalizo_atendimento
end

Então("selecionar os motivos do atendimento") do
    @atendimento.demanda_atendimento.seleciona_motivo_atendimento
end
