require 'site_prism'

class BuscarCliente < SitePrism::Section

    #Busca Cliente
    element :input_consulta_cliente,                   "#actionForm_valor"
    element :button_consulta_cliente, :xpath,          "//input[contains(@src, 'ok.gif')]"

    element :select_conta_cliente,                       "#selectContaUsuario"
    element :option_conta_usuario,                       "//*[@id='selectContaUsuario']/option[2]"

    #Confirmação dos Dados / Situação do Cliente
    element :button_avancar_situacao_cliente,          "[value='avançar']"
    element :button_avancar_confirmacao_dados, :xpath, "//body//input[2]"
    element :text_result_codigo_cliente,               "//*[@id='identificacaoPositivaForm']/table/tbody/tr[1]/td[2]/span"
    element :button_avancar_confirmacao_cliente,       "[value='confirmar']"
    element :txt_chamada,                              ".texto-chamada"

    #Selecionar Demanda e Confirmar
    element :button_avancar_dados,                     "[value='avançar']"
    

    #Consultar Cliente
    def consultar_tipo_cliente(tipo_cliente)
        select(tipo_cliente, from:                        "actionForm_filtros").select_option
    end

    def consultar_cliente(cliente)
        banco = BancoDeDados.new

          
        case cliente

            when "cliente_valido"
                @clienteQuery = banco.retorna_cliente_valido
                
            else 
                @clienteSemQuery = "true"
        end


        if(@clienteSemQuery == "true")
            input_consulta_cliente.set        ""
            input_consulta_cliente.set        CLIENTE[:"#{cliente}"]
            button_consulta_cliente.click
        else 
            
            input_consulta_cliente.set        "#{@clienteQuery}"
            button_consulta_cliente.click
            puts "código do cliente: #{@clienteQuery}"
        end
    end

    def selecionar_conta
        puts "entrou para selcionar a conta"
        select("Usuário", from:                         "selectContaUsuario")
    end    

    def validar_cliente
        button_avancar_confirmacao_cliente.click
    end

    #Verifica se cliente é adimplente
    def situacao_cliente
        if page.has_text?("ATENÇÃO")
            button_avancar_situacao_cliente.click
        
        else
        
        end
    end






################## Cod especifico da funcionalidade: "Buscar Cliente" ##################   
    #Selecionar Demanda e Confirmar
    element :button_adicionar_dados,                    "[value='adicionar']"
    element :button_cancelar_dados,                     "[value='cancelar']"

    #Check cadastrar cliente
    element :checkbox_cadastrar_cliente,                 "#actionForm_clienteNaoCadastrado"

    #Preencher campo Nome não cliente
    element :input_nome_nao_cliente,                     "#actionForm_identificacao"

    
    element :select_escolha_conta,                          "#selectContaUsuario"
    element :text_menu_lateral,                             "#middle"
    element :text_pre_pago_valor_zerado,  :xpath,           "//b[contains(text(),'VALOR DE DISPARO IGUAL A ZERO.')]"
    element :text_confirmacao_dados,  :xpath,               "//*[@id='identificacaoPositivaForm']/table/tbody/tr[2]/td[2]/span"
    element :text_alerta,  :xpath,                          "//div[@id='geral']//p[1]"
    element :text_conteudo_menu,  :xpath,                   "//div[@class='conteudo-miolo']"
    element :text_menu,   :xpath,                           "//div[@class='body_portlet']"
    element :text_nao_cliente,  :xpath,                     "//td[@class='texto-chamada']"
    element :client_nao_localizado,  :xpath,                "//div[@class='body_portlet']//form"
    #validar cliente
    def validar_buscar_cliente
        txt_chamada.text
        txt_chamada.assert_text("Antes de prosseguir, valide os dados do cliente abaixo e clique em CONFIRMAR")   
    end
    
    #Confirmar de já foi dado os dados do cliente
    def confirmar_dados_cliente
        text_confirmacao_dados.assert_text("#{@cliente}")
    end

    #Nao cliente
    def busca_nao_cliente
        if text_menu.has_text?("CPF")
            text_nao_cliente.assert_text("CPF não foi encontrado no sistema.")
        else
            text_nao_cliente.assert_text("CNPJ não foi encontrado no sistema.")
        end
    end

    
    #Cliente nao localizado
    def validar_nao_localizado
        client_nao_localizado.assert_text("Cliente não cadastrado.")
    end 


    #bloqueio VR
    def bloqueio_vr 
        button_avancar_confirmacao_cliente.click
        text_conteudo_menu.text
    end

    #Contrato não ativo
    def cont_nao_ativo
        button_avancar_confirmacao_cliente.click
        text_alerta.assert_text("Cliente NÃO POSSUI contratos ATIVOS.")
    end

    #Tipo Conta
    def tipo_conta
        select_escolha_conta.click
    end   

    def conta_diferente
        select("Embarcador-34274233005910", from:    "selectContaUsuario")
    end

    #cobranca externa
    def cobranca_ext
        button_avancar_confirmacao_cliente.click
        text_alerta.assert_text("Cliente está INADIMPLENTE, com dívida em processo de COBRANÇA EXTERNA/JUDICIAL.")
    end

    #Pre Pago
    def consulta_prepago
        button_avancar_confirmacao_cliente.click
        find("#middle", match: :first).text
    end

    #Pre Pago Valor Zerado
    def prepago_zerado
        button_avancar_confirmacao_cliente.click
        text_pre_pago_valor_zerado.text
    end
    
end