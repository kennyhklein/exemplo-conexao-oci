require 'site_prism'

class Login < SitePrism::Section

    #Tela Login
    element :input_usuario,  '#actionForm_login'
    element :input_senha,    '#actionForm_senha'
    element :button_avancar, '[value="Login"]'

    def login(tipo_empresa)

        case tipo_empresa

        when "Sem Parar"

            input_usuario.set   USUARIO_ACESSO[:login_admin]
            input_senha.set     USUARIO_ACESSO[:senha_admin]

        end

        sleep(5)
        button_avancar.click 
        
    end




end
