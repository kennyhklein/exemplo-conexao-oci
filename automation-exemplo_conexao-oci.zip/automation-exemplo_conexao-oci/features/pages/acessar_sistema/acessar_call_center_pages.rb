require 'site_prism'

class AtendimentoCallCenter < SitePrism::Section

    #Iniciar Atendimento
    element :button_iniciar_atendimento, :xpath,       "//img[contains(@src, 'bt-iniciar-atendimento.gif')]"

    element :radio_retencao, :xpath, "//html[1]/body[1]/div[5]/div[1]/div[1]/div[2]/div[1]/div[2]/form[1]/fieldset[1]/p[1]/input[1]"

    #Selecionar Perfil
    element :radio_perfil_sac,                         "[value='SAC/CRC']"
    element :radio_perfil_customer,                    "[value='Customer']"
    element :radio_perfil_credenciado,                 "[value='Credenciado']"
    element :radio_perfil_cobranca,                    "[value='Cobrança']"
    element :radio_perfil_retencao,                    "[value='Retenção']"
    element :radio_perfil_b2b,                         "[value='B2B']"
    element :radio_perfil_vp,                          "[value='Vale Pedagio']"
    element :radio_perfil_consulta,                    "[value='Consulta']"
    element :radio_perfil_administrador,               "[value='Administrador']"
    element :radio_perfil_pamovida,                    "[value='PA Movida']"
    element :radio_perfil_movidarac,                   "[value='Movida RAC']"
    element :radio_perfil_lojas,                       "[value='Lojas']"
    element :radio_perfil_televendas,                  "[value='Televendas']"
    element :radio_perfil_admin_vendas,                "[value='Admin Vendas']"
    element :radio_perfil_fraude,                      "[value='Fraude']"
    element :radio_perfil_atendimento_inteiro,         "[value='Atendimento Interno']"
    element :radio_perfil_ouvidoria,                   "[value='Ouvidoria']"
    element :radio_perfil_qualidade_cadastro,          "[value='Qualidade de Cadastro']"
    element :radio_perfil_chat,                        "[value='Chat']"

    #Perfis Caixa
    element :radio_perfil_sac_caixa,                         "[value='SAC/CRC.']"
    element :radio_perfil_retencao_caixa,                    "[value='Retenção.']"
    element :radio_perfil_administrador_caixa,               "[value='Administrador.']"

    
    element :button_avancar, '[value=avançar]'
    element :button_confirmar_perfil,                  ".botao-arredondado"

    element :input_nome_sac,    "#actionForm_nome"
    element :input_telefone_sac,    "#actionForm_telefone"





    #Confirmação dos Dados
    element :text_numero_protocolo, :xpath,            "//div[@class='body_portlet']/table/tbody/tr/td[2]/span"
    
 
    #Inicia o atendimento no sistema call center
    def iniciar_atendimento
        button_iniciar_atendimento.click
    end

    def selecionar_perfil(tipo_perfil)
        #implementar logica de qual perfil selecionar caso mude.
        
        case tipo_perfil
        
            when "Administrador"
            radio_perfil_administrador.click
            button_confirmar_perfil.click
            #button_avancar.click

            when "SAC/CRC"
            radio_perfil_sac.click
            button_confirmar_perfil.click
            button_avancar.click

            input_nome_sac.set "TESTE AUTOMACAO"
            input_telefone_sac.set "11999887766"
            button_avancar.click

            when "Customer"
            radio_perfil_customer.click
            button_confirmar_perfil.click
            button_avancar.click

            when "Retenção"
            radio_perfil_retencao.click
            button_confirmar_perfil.click

            button_avancar.click

            when "Cobrança"
            radio_perfil_cobranca.click
            button_confirmar_perfil.click
            button_avancar.click

            when "Lojas"
            radio_perfil_lojas.click
            button_confirmar_perfil.click
            button_avancar.click

            when "Vale Pedágio"
            radio_perfil_vp.click
            button_confirmar_perfil.click
            button_avancar.click

            when "Consulta"
            radio_perfil_consulta.click
            button_confirmar_perfil.click
            button_avancar.click

            when "PA Movida"
            radio_perfil_pamovida.click
            button_confirmar_perfil.click
            button_avancar.click
            
            when "Movida RAC"
            radio_perfil_movidarac.click
            button_confirmar_perfil.click
            button_avancar.click

            when "Admin Vendas"
            radio_perfil_admin_vendas.click
            button_confirmar_perfil.click
            button_avancar.click
        
            when "Televendas"
            radio_perfil_televendas.click
            button_confirmar_perfil.click
            button_avancar.click

            when "Fraude"
            radio_perfil_fraude.click
            button_confirmar_perfil.click
            button_avancar.click

            when "Atendimento Interno"
            radio_perfil_atendimento_inteiro.click
            button_confirmar_perfil.click
            button_avancar.click

            when "Ouvidoria"
            radio_perfil_ouvidoria.click
            button_confirmar_perfil.click
            button_avancar.click

            when "Qualidade de Cadastro"
            radio_perfil_qualidade_cadastro.click
            button_confirmar_perfil.click
            button_avancar.click

            when "Chat"
            radio_perfil_chat.click
            button_confirmar_perfil.click
            button_avancar.click

            when "B2B"
            radio_perfil_b2b.click
            button_confirmar_perfil.click
            button_avancar.click


            #Perfil Caixa
            when "Administrador."
            radio_perfil_administrador_caixa.click
            button_confirmar_perfil.click
            #button_avancar.click

            when "SAC/CRC."
            radio_perfil_sac_caixa.click
            button_confirmar_perfil.click

            
            button_avancar.click

            when "Retenção."
            radio_perfil_retencao_caixa.click
            button_confirmar_perfil.click

            button_avancar.click



        end 
    end

    def numero_protocolo
        protocolo = text_numero_protocolo.text
        puts "Número Protocolo: #{protocolo}"
        button_avancar.click
    end

    def seleciona_motivo_atendimento

        radio_retencao.click
        button_avancar.click

        radio_retencao.click
        button_avancar.click
        
    end


end