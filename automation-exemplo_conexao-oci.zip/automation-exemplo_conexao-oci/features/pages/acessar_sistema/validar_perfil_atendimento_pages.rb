


class PerfilAtendimento < SitePrism::Section

    element :button_logout, :xpath,       "//img[contains(@src, 'logout.gif')]"
    element :button_home, :xpath,       "//img[contains(@src, 'bt-home.gif')]"
    element :button_avancar,    '[value=avançar]'
    element :button_cancelar,    '[value=cancelar]'
    element :button_alterar_forma_pagamento, '[value="Alterar Forma Pagamento"]'
    element :button_alterar_incluir_promocao, '[value="Alterar/Incluir Promoção"]'
    element :button_alterar_plano, '[value="Alterar Plano"]'
    element :button_bloqueio_vendido, '[value="Bloqueio Informe de Venda"]'
    element :button_cancelamento, '[value="Cancelamento"]'
    element :button_consultar_faturas, '[value="Consultar Faturas"]'



    def verfica_demanda_primeiro_nivel(tipo_perfil)

        case tipo_perfil
            
            when "Administrador"
                primeiro_nivel_default()
        
            when "SAC"
                primeiro_nivel_default()
               

            when "Customer"
                primeiro_nivel_default()
        

            when "Retenção"
                primeiro_nivel_default()

            when "Lojas"
                primeiro_nivel_default()
        

            when "Cobrança"
            
                find(:xpath, "//select[@id='selectPrimeiroNivel']").click

                #Demandas que deve exibir para o perfil
                if page.has_selector?(:xpath, "//select[@id='selectPrimeiroNivel']/option[@value='alterar']")
                        result_alterar = true
                    else 
                        result_alterar = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectPrimeiroNivel']/option[@value='consultar']")
                        result_consultar = true
                    else 
                        result_consultar = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectPrimeiroNivel']/option[@value='localizar']")
                        result_localizar = true
                    else 
                        result_localizar = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectPrimeiroNivel']/option[@value='solicitar']")
                        result_solicitar = true
                    else 
                        result_solicitar = false
                end

                #Demandas que NÃO deve exibir para o perfil
                if page.has_no_selector?(:xpath, "//select[@id='selectPrimeiroNivel']/option[@value='confirmar']")
                        result_confirmar = true
                    else 
                        result_confirmar = false
                end
                
                if page.has_no_selector?(:xpath, "//select[@id='selectPrimeiroNivel']/option[@value='contestar']")
                        result_contestar = true
                    else 
                        result_contestar = false
                end

                if page.has_no_selector?(:xpath, "//select[@id='selectPrimeiroNivel']/option[@value='reclamar']")
                        result_reclamar = true
                      else
                        result_reclamar = false
                    end

                if result_alterar && result_confirmar && result_consultar && result_localizar && result_solicitar && result_contestar && result_reclamar == true
                        return true
                    else
                        return false
                end 


            
            when "Vale Pedágio"
            
                find(:xpath, "//select[@id='selectPrimeiroNivel']").click

                #Demandas que deve exibir para o perfil
                if page.has_selector?(:xpath, "//select[@id='selectPrimeiroNivel']/option[@value='alterar']")
                        result_alterar = true
                    else 
                        result_alterar = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectPrimeiroNivel']/option[@value='consultar']")
                        result_consultar = true
                    else 
                        result_consultar = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectPrimeiroNivel']/option[@value='solicitar']")
                        result_solicitar = true
                    else 
                        result_solicitar = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectPrimeiroNivel']/option[@value='contestar']")
                        result_contestar = true
                    else 
                        result_contestar = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectPrimeiroNivel']/option[@value='reclamar']")
                        result_reclamar = true
                    else
                        result_reclamar = false
                end

                #Demandas que NÃO deve exibir para o perfil
                if page.has_no_selector?(:xpath, "//select[@id='selectPrimeiroNivel']/option[@value='confirmar']")
                        result_confirmar = true
                    else 
                        result_confirmar = false
                end

                if page.has_no_selector?(:xpath, "//select[@id='selectPrimeiroNivel']/option[@value='localizar']")
                        result_localizar = true
                    else 
                        result_localizar = false
                end
                
                

                if result_alterar && result_confirmar && result_consultar && result_localizar && result_solicitar && result_contestar && result_reclamar == true
                        return true
                    else
                        return false
                end 


            
            when "Consulta"
            
                find(:xpath, "//select[@id='selectPrimeiroNivel']").click

                #Demandas que deve exibir para o perfil
                if page.has_selector?(:xpath, "//select[@id='selectPrimeiroNivel']/option[@value='consultar']")
                        result_consultar = true
                    else 
                        result_consultar = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectPrimeiroNivel']/option[@value='solicitar']")
                        result_solicitar = true
                    else 
                        result_solicitar = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectPrimeiroNivel']/option[@value='contestar']")
                        result_contestar = true
                    else 
                        result_contestar = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectPrimeiroNivel']/option[@value='reclamar']")
                        result_reclamar = true
                    else
                        result_reclamar = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectPrimeiroNivel']/option[@value='localizar']")
                        result_localizar = true
                    else 
                        result_localizar = false
                end

                #Demandas que NÃO deve exibir para o perfil
                if page.has_no_selector?(:xpath, "//select[@id='selectPrimeiroNivel']/option[@value='confirmar']")
                        result_confirmar = true
                    else 
                        result_confirmar = false
                end

                if page.has_no_selector?(:xpath, "//select[@id='selectPrimeiroNivel']/option[@value='alterar']")
                        result_alterar = true
                    else 
                        result_alterar = false
                end

                

                if result_alterar && result_confirmar && result_consultar && result_localizar && result_solicitar && result_contestar && result_reclamar == true
                        return true
                    else
                        return false
                end 


            when "PA Movida"

                    find(:xpath, "//select[@id='selectPrimeiroNivel']").click

                    #Demandas que deve exibir para o perfil

                    if page.has_selector?(:xpath, "//select[@id='selectPrimeiroNivel']/option[@value='alterar']")
                            result_alterar = true
                        else 
                            result_alterar = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectPrimeiroNivel']/option[@value='consultar']")
                            result_consultar = true
                        else 
                            result_consultar = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectPrimeiroNivel']/option[@value='solicitar']")
                            result_solicitar = true
                        else 
                            result_solicitar = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectPrimeiroNivel']/option[@value='contestar']")
                            result_contestar = true
                        else 
                            result_contestar = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectPrimeiroNivel']/option[@value='reclamar']")
                            result_reclamar = true
                        else
                            result_reclamar = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectPrimeiroNivel']/option[@value='localizar']")
                            result_localizar = true
                        else 
                            result_localizar = false
                    end

                    
                    #Demandas que NÃO deve exibir para o perfil
                    if page.has_no_selector?(:xpath, "//select[@id='selectPrimeiroNivel']/option[@value='confirmar']")
                            result_confirmar = true
                        else 
                            result_confirmar = false
                    end

                    
                    if result_alterar && result_confirmar && result_consultar && result_localizar && result_solicitar && result_contestar && result_reclamar == true
                            return true
                        else
                            return false
                    end 


            when "Movida RAC"
                
                    find(:xpath, "//select[@id='selectPrimeiroNivel']").click

                    #Demandas que deve exibir para o perfil

                    if page.has_selector?(:xpath, "//select[@id='selectPrimeiroNivel']/option[@value='alterar']")
                            result_alterar = true
                        else 
                            result_alterar = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectPrimeiroNivel']/option[@value='consultar']")
                            result_consultar = true
                        else 
                            result_consultar = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectPrimeiroNivel']/option[@value='solicitar']")
                            result_solicitar = true
                        else 
                            result_solicitar = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectPrimeiroNivel']/option[@value='contestar']")
                            result_contestar = true
                        else 
                            result_contestar = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectPrimeiroNivel']/option[@value='reclamar']")
                            result_reclamar = true
                        else
                            result_reclamar = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectPrimeiroNivel']/option[@value='localizar']")
                            result_localizar = true
                        else 
                            result_localizar = false
                    end

                    
                    #Demandas que NÃO deve exibir para o perfil
                    if page.has_no_selector?(:xpath, "//select[@id='selectPrimeiroNivel']/option[@value='confirmar']")
                            result_confirmar = true
                        else 
                            result_confirmar = false
                    end

                    
                    if result_alterar && result_confirmar && result_consultar && result_localizar && result_solicitar && result_contestar && result_reclamar == true
                            return true
                        else
                            return false
                    end 


            when "Admin Vendas"
                primeiro_nivel_default()

            when "Televendas"

                find(:xpath, "//select[@id='selectPrimeiroNivel']").click

                #Demandas que deve exibir para o perfil
                if page.has_selector?(:xpath, "//select[@id='selectPrimeiroNivel']/option[@value='alterar']")
                        result_alterar = true
                    else 
                        result_alterar = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectPrimeiroNivel']/option[@value='consultar']")
                        result_consultar = true
                    else 
                        result_consultar = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectPrimeiroNivel']/option[@value='localizar']")
                        result_localizar = true
                    else 
                        result_localizar = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectPrimeiroNivel']/option[@value='solicitar']")
                        result_solicitar = true
                    else 
                        result_solicitar = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectPrimeiroNivel']/option[@value='contestar']")
                        result_contestar = true
                    else 
                        result_contestar = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectPrimeiroNivel']/option[@value='reclamar']")
                        result_reclamar = true
                    else
                        result_reclamar = false
                end

                #Demandas que NÃO deve exibir para o perfil
                if page.has_no_selector?(:xpath, "//select[@id='selectPrimeiroNivel']/option[@value='confirmar']")
                        result_confirmar = true
                    else 
                        result_confirmar = false
                end
                
                

                if result_alterar && result_confirmar && result_consultar && result_localizar && result_solicitar && result_contestar && result_reclamar == true
                        return true
                    else
                        return false
                end 

        
            
            when "Fraude"
                primeiro_nivel_default()
        
            when "Atendimento Interno"
                primeiro_nivel_default()

            when "Ouvidoria"
                primeiro_nivel_default()
            
            when "Qualidade de Cadastro"
                primeiro_nivel_default()
        
            when "Chat"
                primeiro_nivel_default()

            when "B2B"
                primeiro_nivel_default()

        end 

    
    
    
    end



    def seleciona_demanda(tipo_perfil, demanda)


        case tipo_perfil
            
            when "Administrador"

                case demanda

                when "alterar"
                    alterar_default(demanda)
                    

                when "confirmar"
                    confirmar_default(demanda)
                    

                when "consultar"
                    consultar_default(demanda)
                   

                when "contestar"
                    contestar_default(demanda)


                when "localizar"
                    localizar_default(demanda)
                    

                when "reclamar"


                    find(:xpath, "//*[@name='Demandas_1wlw-select_key:{actionForm.primeiroNivelSelecionado}']/option[@value='#{demanda}']").click
        
                    #Demandas que deve exibir para o perfil
                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_reclamar_acidenteComCancela']")
                            result_rec_acidente_cancela = true
                        else 
                            result_rec_acidente_cancela = false
                    end
            
                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_reclamar_acidenteloja']")
                            result_rec_acidente_loja = true
                        else 
                            result_rec_acidente_loja = false
                    end
            
                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_reclamar_cancelanaoabriu']")
                            result_rec_cancela_nao_abriu = true
                        else 
                            result_rec_cancela_nao_abriu = false
                    end
            
                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_reclamar_ausenciaDebito']")
                            result_rec_ausencia_debito = true
                        else 
                            result_rec_ausencia_debito = false
                    end
            
                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_reclamar_tagNaoRecebido']")
                            result_rec_tag_nao_recebido = true
                        else 
                            result_rec_tag_nao_recebido = false
                    end
            
                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_reclamar_mauatendimento']")
                            result_rec_mau_atendimento = true
                        else 
                            result_rec_mau_atendimento = false
                    end
            
                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_reclamar_tagSemCliente']")
                            result_rec_tag_sem_cliente = true
                        else 
                            result_rec_tag_sem_cliente = false
                    end
            
                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_reclamar_creditoNaoRecebido']")
                            result_rec_credito_nao_recebido = true
                        else 
                            result_rec_credito_nao_recebido = false
                    end
            
                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_reclamar_financiamento']")
                            result_rec_financiamento = true
                        else 
                            result_rec_financiamento = false
                    end
            
                    #Demandas que não deve exibir para o perfil
                    if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_reclamar_mauatendimentoEmbarcador']")
                            result_rec_mau_atendimento_embarcador = true
                        else 
                            result_rec_mau_atendimento_embarcador = false
                    end
            
                    if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_reclamar_siteWebServiceEmbarcador']")
                            result_rec_site_service_embarcador = true
                        else 
                            result_rec_site_service_embarcador = false
                    end

                    if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_reclamar_naoconsegueabastecer']")
                        result_rec_nao_consegue_abastecer = true
                        else 
                        result_rec_nao_consegue_abastecer = false
                    end
            
            
                    if result_rec_acidente_cancela && result_rec_acidente_loja && result_rec_cancela_nao_abriu && result_rec_ausencia_debito && result_rec_tag_nao_recebido &&
                       result_rec_mau_atendimento && result_rec_nao_consegue_abastecer && result_rec_tag_sem_cliente && result_rec_credito_nao_recebido && result_rec_financiamento &&
                       result_rec_mau_atendimento_embarcador && result_rec_site_service_embarcador == true
                            puts "entrou true reclamar"
                            return true
                        else
                            puts "entrou false reclamar"
                            return false
            
                    end


                when "solicitar"

                    find(:xpath, "//*[@name='Demandas_1wlw-select_key:{actionForm.primeiroNivelSelecionado}']/option[@value='#{demanda}']").click

                    #Demandas que deve exibir para o perfil
                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_bloqueioRouboExtravio']")
                            result_sol_bloqueio_extravio = true
                        else 
                            result_sol_bloqueio_extravio = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_bloqueioVeiculoVendido']")
                            result_sol_bloqueio_veiculo_vendido = true
                        else 
                            result_sol_bloqueio_veiculo_vendido = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_encerramentoTag']")
                            result_sol_encerramento_tag = true
                        else 
                            result_sol_encerramento_tag = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_gravacaoatendimento']")
                            result_sol_gravacao_atendimento = true
                        else 
                            result_sol_gravacao_atendimento = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_historicoatendimento']")
                            result_sol_historico_atendimento = true
                        else 
                            result_sol_historico_atendimento = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_solicitarTermoDeAdesao']")
                            result_sol_termo_adesao = true
                        else 
                            result_sol_termo_adesao = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_declaracaoQuitacaoDebitos']")
                            result_sol_declaracao_quitacao_debitos = true
                        else 
                            result_sol_declaracao_quitacao_debitos = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_emitirNotaFiscalEletronica']")
                            result_sol_emitir_nota_fiscal = true
                        else 
                            result_sol_emitir_nota_fiscal = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_exclusaoSerasa']")
                            result_sol_exclusao_serasa = true
                        else 
                            result_sol_exclusao_serasa = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_exclusaoProdutosAdicionais']")
                            result_sol_exclusao_produtos_adicionais = true
                        else 
                            result_sol_exclusao_produtos_adicionais = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_inclusaoProdutosAdicionais']")
                            result_sol_inclusao_produtos_adicionais = true
                        else 
                            result_sol_inclusao_produtos_adicionais = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitar_incluirocorrencia']")
                            result_sol_incluir_ocorrencias = true
                        else 
                            result_sol_incluir_ocorrencias = false
                    end
                   
                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitar_incluirpromocao']")
                            result_sol_incluir_promocao = true
                        else 
                            result_sol_incluir_promocao = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_reembolsoLiberalidade']")
                            result_sol_reembolso_liberalidade = true
                        else 
                            result_sol_reembolso_liberalidade = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_iniciarPausaPlano']")
                            result_sol_iniciar_pausa_plano = true
                        else 
                            result_sol_iniciar_pausa_plano = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_reembolso_reembolsoPorSaldoCartao']")
                            result_sol_reembolso_saldo_cartao = true
                        else 
                            result_sol_reembolso_saldo_cartao = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_segundaViaDeExtrato']")
                            result_sol_segunda_via_extrato = true
                        else 
                            result_sol_segunda_via_extrato = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_veiculoAtivo']")
                            result_sol_veiculo_ativo = true
                        else 
                            result_sol_veiculo_ativo = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_representanteComercial']")
                            result_sol_representante_comercial = true
                        else 
                            result_sol_representante_comercial = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_registrarSugestao']")
                            result_sol_registrar_sugestao = true
                        else 
                            result_sol_registrar_sugestao = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_inclusaoVeiculo']")
                            result_sol_inclusao_veiculo = true
                        else 
                            result_sol_inclusao_veiculo = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_priorizacao']")
                            result_sol_priorizacao = true
                        else 
                            result_sol_priorizacao = false
                    end
            
                    #Demandas que não deve exibir para o perfil
                    if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_contatoTelevendas']")
                            result_sol_contato_televendas = true
                        else 
                            result_sol_contato_televendas = false
                    end
    
                    if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_reenvioFaturaEmbarcador']")
                            result_sol_reenvio_fatura_embarcador = true
                        else 
                            result_sol_reenvio_fatura_embarcador = false
                    end
    
                    if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_solicitarEsclarecimentoDuvidas']")
                            result_sol_esclarecimento_duvidas = true
                        else 
                            result_sol_esclarecimento_duvidas = false
                    end

                    if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_auxilioLocalizarTransportadorEmbarcador']")
                            result_sol_auxilio_localizador_transportador_vp = true
                        else 
                            result_sol_auxilio_localizador_transportador_vp = false
                    end
                    
                    if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_auxilionavegacaosite']")
                            result_sol_auxilio_navegacao_site = true
                        else 
                            result_sol_auxilio_navegacao_site = false
                    end

                    if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_integracaosistemica']")
                            result_sol_integracao_sistemica = true
                        else 
                            result_sol_integracao_sistemica = false
                    end        

                    if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_liberacaocreditohomologacaoembarcador']")
                            result_sol_liberacao_credito_embarcador = true
                        else 
                            result_sol_liberacao_credito_embarcador = false
                    end            

                    if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_reembolsoTransferenciaSaldo']")
                            result_sol_reembolso_transferencia_saldo = true
                        else 
                            result_sol_reembolso_transferencia_saldo = false
                    end            

                    if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_representanteComercialEmbarcador']")
                            result_sol_representante_comercial_embarcador = true
                        else 
                            result_sol_representante_comercial_embarcador = false
                    end            


                    if  result_sol_bloqueio_extravio && result_sol_bloqueio_veiculo_vendido && result_sol_encerramento_tag && result_sol_gravacao_atendimento &&
                        result_sol_historico_atendimento && result_sol_termo_adesao && result_sol_declaracao_quitacao_debitos && result_sol_emitir_nota_fiscal &&
                        result_sol_exclusao_serasa && result_sol_exclusao_produtos_adicionais && result_sol_inclusao_produtos_adicionais && result_sol_incluir_ocorrencias &&
                        result_sol_iniciar_pausa_plano && result_sol_reembolso_saldo_cartao && result_sol_segunda_via_extrato && result_sol_veiculo_ativo &&
                        result_sol_representante_comercial && result_sol_registrar_sugestao && result_sol_inclusao_veiculo && result_sol_priorizacao && result_sol_contato_televendas && 
                        result_sol_reenvio_fatura_embarcador && result_sol_esclarecimento_duvidas && result_sol_reembolso_liberalidade && result_sol_incluir_promocao && 
                        result_sol_auxilio_localizador_transportador_vp && result_sol_auxilio_navegacao_site && result_sol_integracao_sistemica && 
                        result_sol_liberacao_credito_embarcador && result_sol_reembolso_transferencia_saldo && result_sol_representante_comercial_embarcador == true
                            puts "entrou true solicitar"
                            return true
                        else
                            puts "entrou false solicitar"
                            return false
            
                    end
            end
        
            when "SAC"

                case demanda
                
                when "alterar"
                    alterar_default(demanda)
                    

                when "confirmar"
                    confirmar_default(demanda)
                    

                when "consultar"
                    consultar_default(demanda)
                   

                when "contestar"
                    contestar_default(demanda)


                when "localizar"
                    localizar_default(demanda)
                    

                when "reclamar"
                    reclamar_default(demanda)
                    

                when "solicitar"

                    find(:xpath, "//*[@name='Demandas_1wlw-select_key:{actionForm.primeiroNivelSelecionado}']/option[@value='#{demanda}']").click
            
                    #Demandas que deve exibir para o perfil
                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_bloqueioRouboExtravio']")
                            result_sol_bloqueio_extravio = true
                        else 
                            result_sol_bloqueio_extravio = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_bloqueioVeiculoVendido']")
                            result_sol_bloqueio_veiculo_vendido = true
                        else 
                            result_sol_bloqueio_veiculo_vendido = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_contatoTelevendas']")
                            result_sol_contato_televendas = true
                        else 
                            result_sol_contato_televendas = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_encerramentoTag']")
                            result_sol_encerramento_tag = true
                        else 
                            result_sol_encerramento_tag = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_gravacaoatendimento']")
                            result_sol_gravacao_atendimento = true
                        else 
                            result_sol_gravacao_atendimento = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_historicoatendimento']")
                            result_sol_historico_atendimento = true
                        else 
                            result_sol_historico_atendimento = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_solicitarTermoDeAdesao']")
                            result_sol_termo_adesao = true
                        else 
                            result_sol_termo_adesao = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_declaracaoQuitacaoDebitos']")
                            result_sol_declaracao_quitacao_debitos = true
                        else 
                            result_sol_declaracao_quitacao_debitos = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_emitirNotaFiscalEletronica']")
                            result_sol_emitir_nota_fiscal = true
                        else 
                            result_sol_emitir_nota_fiscal = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_exclusaoSerasa']")
                            result_sol_exclusao_serasa = true
                        else 
                            result_sol_exclusao_serasa = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_exclusaoProdutosAdicionais']")
                            result_sol_exclusao_produtos_adicionais = true
                        else 
                            result_sol_exclusao_produtos_adicionais = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_inclusaoProdutosAdicionais']")
                            result_sol_inclusao_produtos_adicionais = true
                        else 
                            result_sol_inclusao_produtos_adicionais = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitar_incluirocorrencia']")
                            result_sol_incluir_ocorrencias = true
                        else 
                            result_sol_incluir_ocorrencias = false
                    end
                
                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_iniciarPausaPlano']")
                            result_sol_iniciar_pausa_plano = true
                        else 
                            result_sol_iniciar_pausa_plano = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_reembolso_reembolsoPorSaldoCartao']")
                            result_sol_reembolso_saldo_cartao = true
                        else 
                            result_sol_reembolso_saldo_cartao = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_segundaViaDeExtrato']")
                            result_sol_segunda_via_extrato = true
                        else 
                            result_sol_segunda_via_extrato = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_veiculoAtivo']")
                            result_sol_veiculo_ativo = true
                        else 
                            result_sol_veiculo_ativo = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_representanteComercial']")
                            result_sol_representante_comercial = true
                        else 
                            result_sol_representante_comercial = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_registrarSugestao']")
                            result_sol_registrar_sugestao = true
                        else 
                            result_sol_registrar_sugestao = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_inclusaoVeiculo']")
                            result_sol_inclusao_veiculo = true
                        else 
                            result_sol_inclusao_veiculo = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_priorizacao']")
                            result_sol_priorizacao = true
                        else 
                            result_sol_priorizacao = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_reenvioFaturaEmbarcador']")
                            result_sol_reenvio_fatura_embarcador = true
                        else 
                            result_sol_reenvio_fatura_embarcador = false
                    end
                
                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_solicitarEsclarecimentoDuvidas']")
                            result_sol_esclarecimento_duvidas = true
                        else 
                            result_sol_esclarecimento_duvidas = false
                    end


                    #Demandas que não deve exibir para o perfil
                    if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_auxilioLocalizarTransportadorEmbarcador']")
                            result_sol_auxilio_localizador_transportador_vp = true
                        else 
                            result_sol_auxilio_localizador_transportador_vp = false
                    end
                    
                    if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_auxilionavegacaosite']")
                            result_sol_auxilio_navegacao_site = true
                        else 
                            result_sol_auxilio_navegacao_site = false
                    end

                    if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_integracaosistemica']")
                            result_sol_integracao_sistemica = true
                        else 
                            result_sol_integracao_sistemica = false
                    end        

                    if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_liberacaocreditohomologacaoembarcador']")
                            result_sol_liberacao_credito_embarcador = true
                        else 
                            result_sol_liberacao_credito_embarcador = false
                    end            

                    if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_reembolsoTransferenciaSaldo']")
                            result_sol_reembolso_transferencia_saldo = true
                        else 
                            result_sol_reembolso_transferencia_saldo = false
                    end            

                    if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_representanteComercialEmbarcador']")
                            result_sol_representante_comercial_embarcador = true
                        else 
                            result_sol_representante_comercial_embarcador = false
                    end  
                    
                    if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitar_incluirpromocao']")
                            result_sol_incluir_promocao = true
                        else 
                            result_sol_incluir_promocao = false
                    end

                    if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_reembolsoLiberalidade']")
                            result_sol_reembolso_liberalidade = true
                        else 
                            result_sol_reembolso_liberalidade = false
                    end



                    if  result_sol_bloqueio_extravio && result_sol_bloqueio_veiculo_vendido && result_sol_encerramento_tag && result_sol_gravacao_atendimento &&
                        result_sol_historico_atendimento && result_sol_termo_adesao && result_sol_declaracao_quitacao_debitos && result_sol_emitir_nota_fiscal &&
                        result_sol_exclusao_serasa && result_sol_exclusao_produtos_adicionais && result_sol_inclusao_produtos_adicionais && result_sol_incluir_ocorrencias &&
                        result_sol_iniciar_pausa_plano && result_sol_reembolso_saldo_cartao && result_sol_segunda_via_extrato && result_sol_veiculo_ativo &&
                        result_sol_representante_comercial && result_sol_registrar_sugestao && result_sol_inclusao_veiculo && result_sol_priorizacao && result_sol_contato_televendas && 
                        result_sol_reenvio_fatura_embarcador && result_sol_esclarecimento_duvidas && result_sol_reembolso_liberalidade && result_sol_incluir_promocao && 
                        result_sol_auxilio_localizador_transportador_vp && result_sol_auxilio_navegacao_site && result_sol_integracao_sistemica && 
                        result_sol_liberacao_credito_embarcador && result_sol_reembolso_transferencia_saldo && result_sol_representante_comercial_embarcador == true
                            puts "entrou true solicitar"
                            return true
                        else
                            puts "entrou false solicitar"
                            return false
            
                    end
            end

            when "Customer"
        
                case demanda
                
                when "alterar"
                    alterar_default(demanda)
                    

                when "confirmar"
                    confirmar_default(demanda)
                    

                when "consultar"
                    consultar_default(demanda)
                   

                when "contestar"
                    contestar_default(demanda)


                when "localizar"
                    localizar_default(demanda)
                    

                when "reclamar"
                    reclamar_default(demanda)


                when "solicitar"

                    find(:xpath, "//*[@name='Demandas_1wlw-select_key:{actionForm.primeiroNivelSelecionado}']/option[@value='#{demanda}']").click

                    #Demandas que deve exibir para o perfil
                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_bloqueioRouboExtravio']")
                            result_sol_bloqueio_extravio = true
                        else 
                            result_sol_bloqueio_extravio = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_bloqueioVeiculoVendido']")
                            result_sol_bloqueio_veiculo_vendido = true
                        else 
                            result_sol_bloqueio_veiculo_vendido = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_contatoTelevendas']")
                            result_sol_contato_televendas = true
                        else 
                            result_sol_contato_televendas = false
                    end
                    
                    #DEV PRECISA INCLUIR DEMANDA - ATUALMENTE NÃO EXIBE 
                    # if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_encerramentoTag']")
                    #         result_sol_encerramento_tag = true
                    #     else 
                    #         result_sol_encerramento_tag = false
                    # end

                    

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_historicoatendimento']")
                            result_sol_historico_atendimento = true
                        else 
                            result_sol_historico_atendimento = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_solicitarTermoDeAdesao']")
                            result_sol_termo_adesao = true
                        else 
                            result_sol_termo_adesao = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_declaracaoQuitacaoDebitos']")
                            result_sol_declaracao_quitacao_debitos = true
                        else 
                            result_sol_declaracao_quitacao_debitos = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_emitirNotaFiscalEletronica']")
                            result_sol_emitir_nota_fiscal = true
                        else 
                            result_sol_emitir_nota_fiscal = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_exclusaoSerasa']")
                            result_sol_exclusao_serasa = true
                        else 
                            result_sol_exclusao_serasa = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_exclusaoProdutosAdicionais']")
                            result_sol_exclusao_produtos_adicionais = true
                        else 
                            result_sol_exclusao_produtos_adicionais = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_inclusaoProdutosAdicionais']")
                            result_sol_inclusao_produtos_adicionais = true
                        else 
                            result_sol_inclusao_produtos_adicionais = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitar_incluirocorrencia']")
                            result_sol_incluir_ocorrencias = true
                        else 
                            result_sol_incluir_ocorrencias = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_iniciarPausaPlano']")
                            result_sol_iniciar_pausa_plano = true
                        else 
                            result_sol_iniciar_pausa_plano = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_reembolso_reembolsoPorSaldoCartao']")
                            result_sol_reembolso_saldo_cartao = true
                        else 
                            result_sol_reembolso_saldo_cartao = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_segundaViaDeExtrato']")
                            result_sol_segunda_via_extrato = true
                        else 
                            result_sol_segunda_via_extrato = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_veiculoAtivo']")
                            result_sol_veiculo_ativo = true
                        else 
                            result_sol_veiculo_ativo = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_representanteComercial']")
                            result_sol_representante_comercial = true
                        else 
                            result_sol_representante_comercial = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_registrarSugestao']")
                            result_sol_registrar_sugestao = true
                        else 
                            result_sol_registrar_sugestao = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_inclusaoVeiculo']")
                            result_sol_inclusao_veiculo = true
                        else 
                            result_sol_inclusao_veiculo = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_priorizacao']")
                            result_sol_priorizacao = true
                        else 
                            result_sol_priorizacao = false
                    end

                    
                    #Demandas que não deve exibir para o perfil
                    if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_gravacaoatendimento']")
                            result_sol_gravacao_atendimento = true
                        else 
                            result_sol_gravacao_atendimento = false
                    end

                    if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_auxilioLocalizarTransportadorEmbarcador']")
                            result_sol_auxilio_localizador_transportador_vp = true
                        else 
                            result_sol_auxilio_localizador_transportador_vp = false
                    end
                    
                    if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_auxilionavegacaosite']")
                            result_sol_auxilio_navegacao_site = true
                        else 
                            result_sol_auxilio_navegacao_site = false
                    end

                    if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_integracaosistemica']")
                            result_sol_integracao_sistemica = true
                        else 
                            result_sol_integracao_sistemica = false
                    end        

                    if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_liberacaocreditohomologacaoembarcador']")
                            result_sol_liberacao_credito_embarcador = true
                        else 
                            result_sol_liberacao_credito_embarcador = false
                    end            

                    if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_reembolsoTransferenciaSaldo']")
                            result_sol_reembolso_transferencia_saldo = true
                        else 
                            result_sol_reembolso_transferencia_saldo = false
                    end            

                    if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_representanteComercialEmbarcador']")
                            result_sol_representante_comercial_embarcador = true
                        else 
                            result_sol_representante_comercial_embarcador = false
                    end  
                    
                    if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitar_incluirpromocao']")
                            result_sol_incluir_promocao = true
                        else 
                            result_sol_incluir_promocao = false
                    end

                    if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_reembolsoLiberalidade']")
                            result_sol_reembolso_liberalidade = true
                        else 
                            result_sol_reembolso_liberalidade = false
                    end

                    if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_reenvioFaturaEmbarcador']")
                            result_sol_reenvio_fatura_embarcador = true
                        else 
                            result_sol_reenvio_fatura_embarcador = false
                    end

                    if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_solicitarEsclarecimentoDuvidas']")
                            result_sol_esclarecimento_duvidas = true
                        else 
                            result_sol_esclarecimento_duvidas = false
                    end



                    if  result_sol_bloqueio_extravio && result_sol_bloqueio_veiculo_vendido && result_sol_gravacao_atendimento &&
                        result_sol_historico_atendimento && result_sol_termo_adesao && result_sol_declaracao_quitacao_debitos && result_sol_emitir_nota_fiscal &&
                        result_sol_exclusao_serasa && result_sol_exclusao_produtos_adicionais && result_sol_inclusao_produtos_adicionais && result_sol_incluir_ocorrencias &&
                        result_sol_iniciar_pausa_plano && result_sol_reembolso_saldo_cartao && result_sol_segunda_via_extrato && result_sol_veiculo_ativo &&
                        result_sol_representante_comercial && result_sol_registrar_sugestao && result_sol_inclusao_veiculo && result_sol_priorizacao && result_sol_contato_televendas && 
                        result_sol_reenvio_fatura_embarcador && result_sol_esclarecimento_duvidas && result_sol_reembolso_liberalidade && result_sol_incluir_promocao && 
                        result_sol_auxilio_localizador_transportador_vp && result_sol_auxilio_navegacao_site && result_sol_integracao_sistemica && 
                        result_sol_liberacao_credito_embarcador && result_sol_reembolso_transferencia_saldo && result_sol_representante_comercial_embarcador == true
                            #result_sol_encerramento_tag &&
                            puts "entrou true solicitar"
                            return true
                        else
                            puts "entrou false solicitar"
                            return false

                    end
                    
            end

            when "Retenção"

                case demanda
                
                when "alterar"
                    alterar_default(demanda)
                    

                when "confirmar"
                    confirmar_default(demanda)


                when "consultar"
                    
                    find(:xpath, "//*[@name='Demandas_1wlw-select_key:{actionForm.primeiroNivelSelecionado}']/option[@value='#{demanda}']").click

                    #Demandas que deve exibir para o perfil
                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_historicoAtendimentos']")
                            result_cons_historico_atendimento = true
                        else 
                            result_cons_historico_atendimento = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_historicoBloqueios']")
                            result_cons_historico_bloqueio = true
                        else 
                            result_cons_historico_bloqueio = false
                    end
                    
                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_cobrancaExternaJudicial']")
                            result_cons_cobranca_judicial= true
                        else 
                            result_cons_cobranca_judicial = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consultar_credito']")
                            result_cons_credito = true
                        else 
                            result_cons_credito = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_dadosCadastrais']")
                            result_cons_dados_cadastrais = true
                        else 
                            result_cons_dados_cadastrais = false
                    end
                    
                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_dadosDeCobranca']")
                            result_cons_dados_cobranca = true
                        else 
                            result_cons_dados_cobranca = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_dispositivosVirtuais']")
                            result_cons_dispositivo_virtual = true
                        else 
                            result_cons_dispositivo_virtual = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_consultarFatura']")
                            result_cons_faturas = true
                        else 
                            result_cons_faturas = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_historicoAlteracoes']")
                            result_cons_historico_alteracoes = true
                        else 
                            result_cons_historico_alteracoes = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_consultaHistoricoInadimplencia']")
                            result_cons_historico_inadimplencia = true
                        else 
                            result_cons_historico_inadimplencia = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_consultarLancamentoClienteCartao']")
                            result_cons_lancamento_cartao = true
                        else 
                            result_cons_lancamento_cartao = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_procedimento']")
                            result_cons_procedimento = true
                        else 
                            result_cons_procedimento = false
                    end
                    
                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consultar_produtos_suplementares']")
                            result_cons_produto_suplementar = true
                        else 
                            result_cons_produto_suplementar = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_promocao']")
                            result_cons_promocao = true
                        else 
                            result_cons_promocao = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_consultarReembolsos']")
                            result_cons_reembolso = true
                        else 
                            result_cons_reembolso = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_historicoAnaliseCredito']")
                            result_cons_historico_analise_credito = true
                        else 
                            result_cons_historico_analise_credito = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_situacaoTag']")
                            result_cons_situacao_tag = true
                        else 
                            result_cons_situacao_tag = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_utilizacao']")
                            result_cons_utilizacao = true
                        else 
                            result_cons_utilizacao = false
                    end

                    
                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_veiculos']")
                            result_cons_veiculos = true
                        else 
                            result_cons_veiculos = false
                    end
                    

                    #Demandas que não deve exibir para o perfil
                    if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_consultarViagemEmbarcador']")
                            result_cons_viagem_embarcador = true
                        else 
                            result_cons_viagem_embarcador = false
                    end

                    if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_limite_abastece']")
                            result_cons_limite_abastece = true
                        else 
                            result_cons_limite_abastece = false
                    end

                    if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_dadosCadastraisEmbarcador']")
                            result_cons_dados_embarcador = true
                        else 
                            result_cons_dados_embarcador = false
                    end

                    if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_consultarExtratoEmbarcador']")
                            result_cons_extrato_embarcador = true
                        else 
                            result_cons_extrato_embarcador = false
                    end

                    if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_faturaEmbarcador']")
                            result_cons_fatura_embarcador = true
                        else 
                            result_cons_fatura_embarcador = false
                    end

                    if  result_cons_historico_atendimento && result_cons_historico_bloqueio && result_cons_cobranca_judicial && result_cons_credito && result_cons_dados_cadastrais &&
                        result_cons_dados_cobranca && result_cons_dispositivo_virtual && result_cons_faturas && result_cons_historico_alteracoes && result_cons_historico_inadimplencia &&
                        result_cons_lancamento_cartao && result_cons_procedimento && result_cons_produto_suplementar && result_cons_promocao && result_cons_reembolso && 
                        result_cons_historico_analise_credito && result_cons_situacao_tag && result_cons_utilizacao && result_cons_veiculos && result_cons_viagem_embarcador &&
                        result_cons_dados_embarcador && result_cons_extrato_embarcador && result_cons_fatura_embarcador == true  #&& result_cons_limite_abastece
                            puts "entrou true consultar"    
                            return true
                        else
                            puts "entrou false consultar"    
                            return false
                    end 
                                  
                    

                                    
                
                when "contestar"
                    contestar_default(demanda)


                when "localizar"
                    localizar_default(demanda)


                when "reclamar"

                    find(:xpath, "//*[@name='Demandas_1wlw-select_key:{actionForm.primeiroNivelSelecionado}']/option[@value='#{demanda}']").click

                    #Demandas que deve exibir para o perfil
                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_reclamar_acidenteComCancela']")
                            result_rec_acidente_cancela = true
                        else 
                            result_rec_acidente_cancela = false
                    end
            
                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_reclamar_acidenteloja']")
                            result_rec_acidente_loja = true
                        else 
                            result_rec_acidente_loja = false
                    end
            
                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_reclamar_cancelanaoabriu']")
                            result_rec_cancela_nao_abriu = true
                        else 
                            result_rec_cancela_nao_abriu = false
                    end
            
                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_reclamar_ausenciaDebito']")
                            result_rec_ausencia_debito = true
                        else 
                            result_rec_ausencia_debito = false
                    end
            
                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_reclamar_tagNaoRecebido']")
                            result_rec_tag_nao_recebido = true
                        else 
                            result_rec_tag_nao_recebido = false
                    end
            
                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_reclamar_mauatendimento']")
                            result_rec_mau_atendimento = true
                        else 
                            result_rec_mau_atendimento = false
                    end
            
                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_reclamar_tagSemCliente']")
                            result_rec_tag_sem_cliente = true
                        else 
                            result_rec_tag_sem_cliente = false
                    end
            
                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_reclamar_creditoNaoRecebido']")
                            result_rec_credito_nao_recebido = true
                        else 
                            result_rec_credito_nao_recebido = false
                    end
            
                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_reclamar_naoconsegueabastecer']")
                            result_rec_nao_consegue_abastecer = true
                        else 
                            result_rec_nao_consegue_abastecer = false
                    end
            
                    #Demandas que não deve exibir para o perfil
                    if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_reclamar_mauatendimentoEmbarcador']")
                            result_rec_mau_atendimento_embarcador = true
                        else 
                            result_rec_mau_atendimento_embarcador = false
                    end
            
                    if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_reclamar_siteWebServiceEmbarcador']")
                            result_rec_site_service_embarcador = true
                        else 
                            result_rec_site_service_embarcador = false
                    end

                    if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_reclamar_financiamento']")
                            result_rec_financiamento = true
                        else 
                            result_rec_financiamento = false
                    end

            
            
                    if result_rec_acidente_cancela && result_rec_acidente_loja && result_rec_cancela_nao_abriu && result_rec_ausencia_debito && result_rec_tag_nao_recebido &&
                    result_rec_mau_atendimento && result_rec_nao_consegue_abastecer && result_rec_tag_sem_cliente && result_rec_credito_nao_recebido && result_rec_financiamento &&
                    result_rec_mau_atendimento_embarcador && result_rec_site_service_embarcador == true
                            puts "entrou true reclamar"
                            return true
                        else
                            puts "entrou false reclamar"
                            return false
            
                    end
                   
                    

                when "solicitar"

                    find(:xpath, "//*[@name='Demandas_1wlw-select_key:{actionForm.primeiroNivelSelecionado}']/option[@value='#{demanda}']").click
            
                    #Demandas que deve exibir para o perfil
                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_bloqueioRouboExtravio']")
                            result_sol_bloqueio_extravio = true
                        else 
                            result_sol_bloqueio_extravio = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_bloqueioVeiculoVendido']")
                            result_sol_bloqueio_veiculo_vendido = true
                        else 
                            result_sol_bloqueio_veiculo_vendido = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_historicoatendimento']")
                            result_sol_historico_atendimento = true
                        else 
                            result_sol_historico_atendimento = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_solicitarTermoDeAdesao']")
                            result_sol_termo_adesao = true
                        else 
                            result_sol_termo_adesao = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_declaracaoQuitacaoDebitos']")
                            result_sol_declaracao_quitacao_debitos = true
                        else 
                            result_sol_declaracao_quitacao_debitos = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_emitirNotaFiscalEletronica']")
                            result_sol_emitir_nota_fiscal = true
                        else 
                            result_sol_emitir_nota_fiscal = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_exclusaoSerasa']")
                            result_sol_exclusao_serasa = true
                        else 
                            result_sol_exclusao_serasa = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_exclusaoProdutosAdicionais']")
                            result_sol_exclusao_produtos_adicionais = true
                        else 
                            result_sol_exclusao_produtos_adicionais = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_inclusaoProdutosAdicionais']")
                            result_sol_inclusao_produtos_adicionais = true
                        else 
                            result_sol_inclusao_produtos_adicionais = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitar_incluirocorrencia']")
                            result_sol_incluir_ocorrencias = true
                        else 
                            result_sol_incluir_ocorrencias = false
                    end
                
                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitar_incluirpromocao']")
                            result_sol_incluir_promocao = true
                        else 
                            result_sol_incluir_promocao = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_iniciarPausaPlano']")
                            result_sol_iniciar_pausa_plano = true
                        else 
                            result_sol_iniciar_pausa_plano = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_reembolso_reembolsoPorSaldoCartao']")
                            result_sol_reembolso_saldo_cartao = true
                        else 
                            result_sol_reembolso_saldo_cartao = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_segundaViaDeExtrato']")
                            result_sol_segunda_via_extrato = true
                        else 
                            result_sol_segunda_via_extrato = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_veiculoAtivo']")
                            result_sol_veiculo_ativo = true
                        else 
                            result_sol_veiculo_ativo = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_representanteComercial']")
                            result_sol_representante_comercial = true
                        else 
                            result_sol_representante_comercial = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_registrarSugestao']")
                            result_sol_registrar_sugestao = true
                        else 
                            result_sol_registrar_sugestao = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_inclusaoVeiculo']")
                            result_sol_inclusao_veiculo = true
                        else 
                            result_sol_inclusao_veiculo = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_priorizacao']")
                            result_sol_priorizacao = true
                        else 
                            result_sol_priorizacao = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_contatoTelevendas']")
                            result_sol_contato_televendas = true
                        else 
                            result_sol_contato_televendas = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_encerramentoTag']")
                            result_sol_encerramento_tag = true
                        else 
                            result_sol_encerramento_tag = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_reenvioFaturaEmbarcador']")
                            result_sol_reenvio_fatura_embarcador = true
                        else 
                            result_sol_reenvio_fatura_embarcador = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_solicitarEsclarecimentoDuvidas']")
                            result_sol_esclarecimento_duvidas = true
                        else 
                            result_sol_esclarecimento_duvidas = false
                    end
            
                    #Demandas que não deve exibir para o perfil
                    
                    if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_auxilioLocalizarTransportadorEmbarcador']")
                            result_sol_auxilio_localizador_transportador_vp = true
                        else 
                            result_sol_auxilio_localizador_transportador_vp = false
                    end
                    
                    if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_auxilionavegacaosite']")
                            result_sol_auxilio_navegacao_site = true
                        else 
                            result_sol_auxilio_navegacao_site = false
                    end

                    if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_integracaosistemica']")
                            result_sol_integracao_sistemica = true
                        else 
                            result_sol_integracao_sistemica = false
                    end        

                    if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_liberacaocreditohomologacaoembarcador']")
                            result_sol_liberacao_credito_embarcador = true
                        else 
                            result_sol_liberacao_credito_embarcador = false
                    end            

                    if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_reembolsoTransferenciaSaldo']")
                            result_sol_reembolso_transferencia_saldo = true
                        else 
                            result_sol_reembolso_transferencia_saldo = false
                    end            

                    if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_representanteComercialEmbarcador']")
                            result_sol_representante_comercial_embarcador = true
                        else 
                            result_sol_representante_comercial_embarcador = false
                    end
                    
                    if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_gravacaoatendimento']")
                            result_sol_gravacao_atendimento = true
                        else 
                            result_sol_gravacao_atendimento = false
                    end

                    if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_reembolsoLiberalidade']")
                            result_sol_reembolso_liberalidade = true
                        else 
                            result_sol_reembolso_liberalidade = false
                    end
                    
                    


                    if  result_sol_bloqueio_extravio && result_sol_bloqueio_veiculo_vendido && result_sol_encerramento_tag && result_sol_gravacao_atendimento &&
                        result_sol_historico_atendimento && result_sol_termo_adesao && result_sol_declaracao_quitacao_debitos && result_sol_emitir_nota_fiscal &&
                        result_sol_exclusao_serasa && result_sol_exclusao_produtos_adicionais && result_sol_inclusao_produtos_adicionais && result_sol_incluir_ocorrencias &&
                        result_sol_iniciar_pausa_plano && result_sol_reembolso_saldo_cartao && result_sol_segunda_via_extrato && result_sol_veiculo_ativo &&
                        result_sol_representante_comercial && result_sol_registrar_sugestao && result_sol_inclusao_veiculo && result_sol_priorizacao && result_sol_contato_televendas && 
                        result_sol_reenvio_fatura_embarcador && result_sol_esclarecimento_duvidas && result_sol_reembolso_liberalidade && result_sol_incluir_promocao && 
                        result_sol_auxilio_localizador_transportador_vp && result_sol_auxilio_navegacao_site && result_sol_integracao_sistemica && 
                        result_sol_liberacao_credito_embarcador && result_sol_reembolso_transferencia_saldo && result_sol_representante_comercial_embarcador == true
                            puts "entrou true solicitar"
                            return true
                        else
                            puts "entrou false solicitar"
                            return false
            
                    end

            end    

            when "Cobrança"
   
                    case demanda
    
                    when "alterar"
                        find(:xpath, "//*[@name='Demandas_1wlw-select_key:{actionForm.primeiroNivelSelecionado}']/option[@value='#{demanda}']").click

                        #Demandas que deve exibir para o perfil
                        if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_alterar_alterarDadosCartaoCredito']")
                                result_alt_cartao_credito = true
                            else 
                                result_alt_cartao_credito = false
                        end

                        if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_alterar_alterarDadosContaCorrente']")
                                result_alt_conta_corrente = true
                            else 
                                result_alt_conta_corrente = false
                        end
                        
                        if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_alterar_alterarDataVencimento']")
                                result_alt_data_vencimento = true
                            else 
                                result_alt_data_vencimento = false
                        end

                        if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_alterar_formaPagamento']")
                                result_alt_forma_pagamento = true
                            else 
                                result_alt_forma_pagamento = false
                        end

                        if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_alterar_alterarValorPeriodico']")
                                result_alt_valor_periodico = true
                            else 
                                result_alt_valor_periodico = false
                        end


                        #Demandas que não deve exibir para o perfil
                        if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_alterar_dadosCadastrais']")
                                result_alt_dados_cadastrais = true
                            else 
                                result_alt_dados_cadastrais = false
                        end

                        if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_alterar_dadosCadastraisVeiculo']")
                                result_alt_dados_veiculos = true
                            else 
                                result_alt_dados_veiculos = false
                        end

                        if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1NIvel_alterar_plano']")
                                result_alt_plano = true
                            else 
                                result_alt_plano = false
                        end

                        if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_alterar_telefonesms']")
                                result_alt_telefone_sms = true
                            else 
                                result_alt_telefone_sms = false
                        end
                        
                        if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_alterar_dadosCadastraisEmbarcador']")
                                result_alt_dados_embarcador = true
                            else 
                                result_alt_dados_embarcador = false
                        end

                        if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_alterar_atualizacaoCadastralAnual']")
                                result_alt_atualizacao_anual = true
                            else 
                                result_alt_atualizacao_anual = false
                        end

                        if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_alterar_formaReembolso']")
                                result_alt_forma_reembolso = true
                            else 
                                result_alt_forma_reembolso = false
                        end


                        if result_alt_dados_cadastrais && result_alt_conta_corrente && result_alt_cartao_credito && result_alt_dados_veiculos && result_alt_data_vencimento &&
                            result_alt_telefone_sms && result_alt_forma_pagamento && result_alt_forma_reembolso && result_alt_valor_periodico && result_alt_atualizacao_anual && result_alt_dados_embarcador == true 
                                
                                puts "entrou true alterar"    
                                return true
                            else
                                puts "entrou false alterar"  
                                return false
                        end 
        
    
                    when "consultar"

                        find(:xpath, "//*[@name='Demandas_1wlw-select_key:{actionForm.primeiroNivelSelecionado}']/option[@value='#{demanda}']").click
                                      
                        #Demandas que deve exibir para o perfil
                        if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_historicoAtendimentos']")
                                result_cons_historico_atendimento = true
                            else 
                                result_cons_historico_atendimento = false
                        end

                        if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_cobrancaExternaJudicial']")
                                result_cons_cobranca_judicial= true
                            else 
                                result_cons_cobranca_judicial = false
                        end

                        if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_dadosCadastrais']")
                                result_cons_dados_cadastrais = true
                            else 
                                result_cons_dados_cadastrais = false
                        end
                        
                        if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_dadosDeCobranca']")
                                result_cons_dados_cobranca = true
                            else 
                                result_cons_dados_cobranca = false
                        end

                        if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_dispositivosVirtuais']")
                                result_cons_dispositivo_virtual = true
                            else 
                                result_cons_dispositivo_virtual = false
                        end

                        if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_consultarFatura']")
                                result_cons_faturas = true
                            else 
                                result_cons_faturas = false
                        end

                        if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_consultarLancamentoClienteCartao']")
                                result_cons_lancamento_cartao = true
                            else 
                                result_cons_lancamento_cartao = false
                        end

                        if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_procedimento']")
                                result_cons_procedimento = true
                            else 
                                result_cons_procedimento = false
                        end
                        
                        if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_situacaoTag']")
                                result_cons_situacao_tag = true
                            else 
                                result_cons_situacao_tag = false
                        end

                        if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_veiculos']")
                                result_cons_veiculos = true
                            else 
                                result_cons_veiculos = false
                        end
                        

                        #Demandas que não deve exibir para o perfil

                        if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_consultarViagemEmbarcador']")
                                result_cons_viagem_embarcador = true
                            else 
                                result_cons_viagem_embarcador = false
                        end

                        if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_utilizacao']")
                                result_cons_utilizacao = true
                            else 
                                result_cons_utilizacao = false
                        end

                        if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_limite_abastece']")
                                result_cons_limite_abastece = true
                            else 
                                result_cons_limite_abastece = false
                        end
                        
                        if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_dadosCadastraisEmbarcador']")
                                result_cons_dados_embarcador = true
                            else 
                                result_cons_dados_embarcador = false
                        end

                        if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_consultarExtratoEmbarcador']")
                                result_cons_extrato_embarcador = true
                            else 
                                result_cons_extrato_embarcador = false
                        end

                        if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_faturaEmbarcador']")
                                result_cons_fatura_embarcador = true
                            else 
                                result_cons_fatura_embarcador = false
                        end

                        if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_historicoBloqueios']")
                                result_cons_historico_bloqueio = true
                            else 
                                result_cons_historico_bloqueio = false
                        end

                        if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consultar_credito']")
                                result_cons_credito = true
                            else 
                                result_cons_credito = false
                        end

                        if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_promocao']")
                                result_cons_promocao = true
                            else 
                                result_cons_promocao = false
                        end
                        
                        if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_historicoAlteracoes']")
                                result_cons_historico_alteracoes = true
                            else 
                                result_cons_historico_alteracoes = false
                        end

                        if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_consultaHistoricoInadimplencia']")
                                result_cons_historico_inadimplencia = true
                            else 
                                result_cons_historico_inadimplencia = false
                        end

                        if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consultar_produtos_suplementares']")
                                result_cons_produto_suplementar = true
                            else 
                                result_cons_produto_suplementar = false
                        end

                        if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_consultarReembolsos']")
                                result_cons_reembolso = true
                            else 
                                result_cons_reembolso = false
                        end

                        if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_historicoAnaliseCredito']")
                                result_cons_historico_analise_credito = true
                            else 
                                result_cons_historico_analise_credito = false
                        end



                        if  result_cons_historico_atendimento && result_cons_historico_bloqueio && result_cons_cobranca_judicial && result_cons_credito && result_cons_dados_cadastrais &&
                            result_cons_dados_cobranca && result_cons_dispositivo_virtual && result_cons_faturas && result_cons_historico_alteracoes && result_cons_historico_inadimplencia &&
                            result_cons_lancamento_cartao && result_cons_procedimento && result_cons_produto_suplementar && result_cons_promocao && result_cons_reembolso && 
                            result_cons_historico_analise_credito && result_cons_situacao_tag && result_cons_utilizacao && result_cons_veiculos && result_cons_viagem_embarcador &&
                            result_cons_dados_embarcador && result_cons_extrato_embarcador && result_cons_fatura_embarcador && result_cons_limite_abastece == true  
                                puts "entrou true consultar"    
                                return true
                            else
                                puts "entrou false consultar"    
                                return false
                        end 

                        
        
                    when "localizar"

                        find(:xpath, "//*[@name='Demandas_1wlw-select_key:{actionForm.primeiroNivelSelecionado}']/option[@value='#{demanda}']").click

                        #Demandas que deve exibir para o perfil
                        if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_localizar_baixapagamento']")
                                result_loc_baixa_pagamento = true
                            else 
                                result_loc_baixa_pagamento = false
                        end
                        
                        #Demandas que não deve exibir para o perfil
                        if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_localizar_tagdevolvido']")
                                result_const_tag_devolvido = true
                            else 
                                result_const_tag_devolvido = false
                        end
                        
                        if result_loc_baixa_pagamento && result_const_tag_devolvido == true
                                puts "entrou true localizar"    
                                return true
                            else
                                puts "entrou false localizar" 
                                return false
                        end
                    
    
                    when "solicitar"

                        find(:xpath, "//*[@name='Demandas_1wlw-select_key:{actionForm.primeiroNivelSelecionado}']/option[@value='#{demanda}']").click

                        #Demandas que deve exibir para o perfil
                        if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_exclusaoSerasa']")
                                result_sol_exclusao_serasa = true
                            else 
                                result_sol_exclusao_serasa = false
                        end

                        if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_segundaViaDeExtrato']")
                                result_sol_segunda_via_extrato = true
                            else 
                                result_sol_segunda_via_extrato = false
                        end

                        #Demandas que não deve exibir para o perfil
                        if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_bloqueioRouboExtravio']")
                                result_sol_bloqueio_extravio = true
                            else 
                                result_sol_bloqueio_extravio = false
                        end

                        if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_bloqueioVeiculoVendido']")
                                result_sol_bloqueio_veiculo_vendido = true
                            else 
                                result_sol_bloqueio_veiculo_vendido = false
                        end

                        if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_contatoTelevendas']")
                                result_sol_contato_televendas = true
                            else 
                                result_sol_contato_televendas = false
                        end

                        if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_encerramentoTag']")
                                result_sol_encerramento_tag = true
                            else 
                                result_sol_encerramento_tag = false
                        end

                        if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_gravacaoatendimento']")
                                result_sol_gravacao_atendimento = true
                            else 
                                result_sol_gravacao_atendimento = false
                        end

                        if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_historicoatendimento']")
                                result_sol_historico_atendimento = true
                            else 
                                result_sol_historico_atendimento = false
                        end

                        if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_solicitarTermoDeAdesao']")
                                result_sol_termo_adesao = true
                            else 
                                result_sol_termo_adesao = false
                        end

                        if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_declaracaoQuitacaoDebitos']")
                                result_sol_declaracao_quitacao_debitos = true
                            else 
                                result_sol_declaracao_quitacao_debitos = false
                        end

                        if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_emitirNotaFiscalEletronica']")
                                result_sol_emitir_nota_fiscal = true
                            else 
                                result_sol_emitir_nota_fiscal = false
                        end

                        if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_exclusaoProdutosAdicionais']")
                                result_sol_exclusao_produtos_adicionais = true
                            else 
                                result_sol_exclusao_produtos_adicionais = false
                        end

                        if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_inclusaoProdutosAdicionais']")
                                result_sol_inclusao_produtos_adicionais = true
                            else 
                                result_sol_inclusao_produtos_adicionais = false
                        end

                        if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitar_incluirocorrencia']")
                                result_sol_incluir_ocorrencias = true
                            else 
                                result_sol_incluir_ocorrencias = false
                        end
                    
                        if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_iniciarPausaPlano']")
                                result_sol_iniciar_pausa_plano = true
                            else 
                                result_sol_iniciar_pausa_plano = false
                        end

                        if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_reembolso_reembolsoPorSaldoCartao']")
                                result_sol_reembolso_saldo_cartao = true
                            else 
                                result_sol_reembolso_saldo_cartao = false
                        end

                        if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_veiculoAtivo']")
                                result_sol_veiculo_ativo = true
                            else 
                                result_sol_veiculo_ativo = false
                        end

                        if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_representanteComercial']")
                                result_sol_representante_comercial = true
                            else 
                                result_sol_representante_comercial = false
                        end

                        if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_registrarSugestao']")
                                result_sol_registrar_sugestao = true
                            else 
                                result_sol_registrar_sugestao = false
                        end

                        if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_inclusaoVeiculo']")
                                result_sol_inclusao_veiculo = true
                            else 
                                result_sol_inclusao_veiculo = false
                        end

                        if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_priorizacao']")
                                result_sol_priorizacao = true
                            else 
                                result_sol_priorizacao = false
                        end

                        if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_reenvioFaturaEmbarcador']")
                                result_sol_reenvio_fatura_embarcador = true
                            else 
                                result_sol_reenvio_fatura_embarcador = false
                        end
                    
                        if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_solicitarEsclarecimentoDuvidas']")
                                result_sol_esclarecimento_duvidas = true
                            else 
                                result_sol_esclarecimento_duvidas = false
                        end

                        if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_auxilioLocalizarTransportadorEmbarcador']")
                                result_sol_auxilio_localizador_transportador_vp = true
                            else 
                                result_sol_auxilio_localizador_transportador_vp = false
                        end
                        
                        if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_auxilionavegacaosite']")
                                result_sol_auxilio_navegacao_site = true
                            else 
                                result_sol_auxilio_navegacao_site = false
                        end

                        if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_integracaosistemica']")
                                result_sol_integracao_sistemica = true
                            else 
                                result_sol_integracao_sistemica = false
                        end        

                        if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_liberacaocreditohomologacaoembarcador']")
                                result_sol_liberacao_credito_embarcador = true
                            else 
                                result_sol_liberacao_credito_embarcador = false
                        end            

                        if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_reembolsoTransferenciaSaldo']")
                                result_sol_reembolso_transferencia_saldo = true
                            else 
                                result_sol_reembolso_transferencia_saldo = false
                        end            

                        if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_representanteComercialEmbarcador']")
                                result_sol_representante_comercial_embarcador = true
                            else 
                                result_sol_representante_comercial_embarcador = false
                        end  
                        
                        if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitar_incluirpromocao']")
                                result_sol_incluir_promocao = true
                            else 
                                result_sol_incluir_promocao = false
                        end

                        if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_reembolsoLiberalidade']")
                                result_sol_reembolso_liberalidade = true
                            else 
                                result_sol_reembolso_liberalidade = false
                        end


                        if  result_sol_bloqueio_extravio && result_sol_bloqueio_veiculo_vendido && result_sol_encerramento_tag && result_sol_gravacao_atendimento &&
                            result_sol_historico_atendimento && result_sol_termo_adesao && result_sol_declaracao_quitacao_debitos && result_sol_emitir_nota_fiscal &&
                            result_sol_exclusao_serasa && result_sol_exclusao_produtos_adicionais && result_sol_inclusao_produtos_adicionais && result_sol_incluir_ocorrencias &&
                            result_sol_iniciar_pausa_plano && result_sol_reembolso_saldo_cartao && result_sol_segunda_via_extrato && result_sol_veiculo_ativo &&
                            result_sol_representante_comercial && result_sol_registrar_sugestao && result_sol_inclusao_veiculo && result_sol_priorizacao && result_sol_contato_televendas && 
                            result_sol_reenvio_fatura_embarcador && result_sol_esclarecimento_duvidas && result_sol_reembolso_liberalidade && result_sol_incluir_promocao && 
                            result_sol_auxilio_localizador_transportador_vp && result_sol_auxilio_navegacao_site && result_sol_integracao_sistemica && 
                            result_sol_liberacao_credito_embarcador && result_sol_reembolso_transferencia_saldo && result_sol_representante_comercial_embarcador == true
                                puts "entrou true solicitar"
                                return true
                            else
                                puts "entrou false solicitar"
                                return false
                
                        end
    
            end

            when "Lojas"
   
                case demanda

                when "alterar"
                    alterar_default(demanda)

                when "confirmar"
                    confirmar_default(demanda)

                when "consultar"

                    find(:xpath, "//*[@name='Demandas_1wlw-select_key:{actionForm.primeiroNivelSelecionado}']/option[@value='#{demanda}']").click

                    #Demandas que deve exibir para o perfil
                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_historicoAtendimentos']")
                            result_cons_historico_atendimento = true
                        else 
                            result_cons_historico_atendimento = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_historicoBloqueios']")
                            result_cons_historico_bloqueio = true
                        else 
                            result_cons_historico_bloqueio = false
                    end
                    
                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_cobrancaExternaJudicial']")
                            result_cons_cobranca_judicial= true
                        else 
                            result_cons_cobranca_judicial = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consultar_credito']")
                            result_cons_credito = true
                        else 
                            result_cons_credito = false
                    end
                
                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_dadosCadastrais']")
                            result_cons_dados_cadastrais = true
                        else 
                            result_cons_dados_cadastrais = false
                    end
                    
                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_dadosDeCobranca']")
                            result_cons_dados_cobranca = true
                        else 
                            result_cons_dados_cobranca = false
                    end
                
                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_dispositivosVirtuais']")
                            result_cons_dispositivo_virtual = true
                        else 
                            result_cons_dispositivo_virtual = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_consultarFatura']")
                            result_cons_faturas = true
                        else 
                            result_cons_faturas = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_historicoAlteracoes']")
                            result_cons_historico_alteracoes = true
                        else 
                            result_cons_historico_alteracoes = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_consultaHistoricoInadimplencia']")
                            result_cons_historico_inadimplencia = true
                        else 
                            result_cons_historico_inadimplencia = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_consultarLancamentoClienteCartao']")
                            result_cons_lancamento_cartao = true
                        else 
                            result_cons_lancamento_cartao = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_procedimento']")
                            result_cons_procedimento = true
                        else 
                            result_cons_procedimento = false
                    end
                    
                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consultar_produtos_suplementares']")
                            result_cons_produto_suplementar = true
                        else 
                            result_cons_produto_suplementar = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_promocao']")
                            result_cons_promocao = true
                        else 
                            result_cons_promocao = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_consultarReembolsos']")
                            result_cons_reembolso = true
                        else 
                            result_cons_reembolso = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_historicoAnaliseCredito']")
                            result_cons_historico_analise_credito = true
                        else 
                            result_cons_historico_analise_credito = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_situacaoTag']")
                            result_cons_situacao_tag = true
                        else 
                            result_cons_situacao_tag = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_utilizacao']")
                            result_cons_utilizacao = true
                        else 
                            result_cons_utilizacao = false
                    end

                    
                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_veiculos']")
                            result_cons_veiculos = true
                        else 
                            result_cons_veiculos = false
                    end
                    
                    #DEV PRECISA CORRIGIR - NAO EXIBE E DEVERIA EXIBIR 
                    # if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_limite_abastece']")
                    #         result_cons_limite_abastece = true
                    #     else 
                    #         result_cons_limite_abastece = false
                    # end
                
                
                    #Demandas que não deve exibir para o perfil
                    if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_consultarViagemEmbarcador']")
                            result_cons_viagem_embarcador = true
                        else 
                            result_cons_viagem_embarcador = false
                    end

                    if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_dadosCadastraisEmbarcador']")
                            result_cons_dados_embarcador = true
                        else 
                            result_cons_dados_embarcador = false
                    end

                    if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_consultarExtratoEmbarcador']")
                            result_cons_extrato_embarcador = true
                        else 
                            result_cons_extrato_embarcador = false
                    end

                    if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_faturaEmbarcador']")
                            result_cons_fatura_embarcador = true
                        else 
                            result_cons_fatura_embarcador = false
                    end

                    if  result_cons_historico_atendimento && result_cons_historico_bloqueio && result_cons_cobranca_judicial && result_cons_credito && result_cons_dados_cadastrais &&
                        result_cons_dados_cobranca && result_cons_dispositivo_virtual && result_cons_faturas && result_cons_historico_alteracoes && result_cons_historico_inadimplencia &&
                        result_cons_lancamento_cartao && result_cons_procedimento && result_cons_produto_suplementar && result_cons_promocao && result_cons_reembolso && 
                        result_cons_historico_analise_credito && result_cons_situacao_tag && result_cons_utilizacao && result_cons_veiculos && result_cons_viagem_embarcador &&
                        result_cons_dados_embarcador && result_cons_extrato_embarcador && result_cons_fatura_embarcador == true  #&& result_cons_limite_abastece 
                        
                            puts "entrou true consultar"    
                            return true
                        else
                            puts "entrou false consultar"    
                            return false
                    end 


                when "contestar"
                    contestar_default(demanda)

                when "localizar"
                    localizar_default(demanda)

                when "reclamar"

                    find(:xpath, "//*[@name='Demandas_1wlw-select_key:{actionForm.primeiroNivelSelecionado}']/option[@value='#{demanda}']").click
            
                    #Demandas que deve exibir para o perfil
                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_reclamar_acidenteComCancela']")
                            result_rec_acidente_cancela = true
                        else 
                            result_rec_acidente_cancela = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_reclamar_acidenteloja']")
                            result_rec_acidente_loja = true
                        else 
                            result_rec_acidente_loja = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_reclamar_cancelanaoabriu']")
                            result_rec_cancela_nao_abriu = true
                        else 
                            result_rec_cancela_nao_abriu = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_reclamar_ausenciaDebito']")
                            result_rec_ausencia_debito = true
                        else 
                            result_rec_ausencia_debito = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_reclamar_mauatendimento']")
                            result_rec_mau_atendimento = true
                        else 
                            result_rec_mau_atendimento = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_reclamar_naoconsegueabastecer']")
                            result_rec_nao_consegue_abastecer = true
                        else 
                            result_rec_nao_consegue_abastecer = false
                    end
                    
                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_reclamar_tagSemCliente']")
                            result_rec_tag_sem_cliente = true
                        else 
                            result_rec_tag_sem_cliente = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_reclamar_creditoNaoRecebido']")
                            result_rec_credito_nao_recebido = true
                        else 
                            result_rec_credito_nao_recebido = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_reclamar_financiamento']")
                            result_rec_financiamento = true
                        else 
                            result_rec_financiamento = false
                    end

                    
                    #Demandas que não deve exibir para o perfil
                    if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_reclamar_mauatendimentoEmbarcador']")
                            result_rec_mau_atendimento_embarcador = true
                        else 
                            result_rec_mau_atendimento_embarcador = false
                    end

                    if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_reclamar_siteWebServiceEmbarcador']")
                            result_rec_site_service_embarcador = true
                        else 
                            result_rec_site_service_embarcador = false
                    end

                    # DEV PRECISA CORRIGIR - ESTÁ EXIBINDO, MAS NAO DEVERIA EXIBIR
                    # if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_reclamar_tagNaoRecebido']")
                    #         result_rec_tag_nao_recebido = true
                    #     else 
                    #         result_rec_tag_nao_recebido = false
                    # end

                    


                    if result_rec_acidente_cancela && result_rec_acidente_loja && result_rec_cancela_nao_abriu && result_rec_ausencia_debito && 
                    result_rec_mau_atendimento && result_rec_nao_consegue_abastecer && result_rec_tag_sem_cliente && result_rec_credito_nao_recebido && result_rec_financiamento &&
                    result_rec_mau_atendimento_embarcador && result_rec_site_service_embarcador == true #result_rec_tag_nao_recebido &&
                            puts "entrou true reclamar"
                            return true
                        else
                            puts "entrou false reclamar"
                            return false

                    end


                when "solicitar"

                    find(:xpath, "//*[@name='Demandas_1wlw-select_key:{actionForm.primeiroNivelSelecionado}']/option[@value='#{demanda}']").click
                
                    #Demandas que deve exibir para o perfil
                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_bloqueioRouboExtravio']")
                            result_sol_bloqueio_extravio = true
                        else 
                            result_sol_bloqueio_extravio = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_contatoTelevendas']")
                            result_sol_contato_televendas = true
                        else 
                            result_sol_contato_televendas = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_historicoatendimento']")
                            result_sol_historico_atendimento = true
                        else 
                            result_sol_historico_atendimento = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_solicitarTermoDeAdesao']")
                            result_sol_termo_adesao = true
                        else 
                            result_sol_termo_adesao = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_declaracaoQuitacaoDebitos']")
                            result_sol_declaracao_quitacao_debitos = true
                        else 
                            result_sol_declaracao_quitacao_debitos = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_emitirNotaFiscalEletronica']")
                            result_sol_emitir_nota_fiscal = true
                        else 
                            result_sol_emitir_nota_fiscal = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_exclusaoSerasa']")
                            result_sol_exclusao_serasa = true
                        else 
                            result_sol_exclusao_serasa = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_exclusaoProdutosAdicionais']")
                            result_sol_exclusao_produtos_adicionais = true
                        else 
                            result_sol_exclusao_produtos_adicionais = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_inclusaoProdutosAdicionais']")
                            result_sol_inclusao_produtos_adicionais = true
                        else 
                            result_sol_inclusao_produtos_adicionais = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitar_incluirocorrencia']")
                            result_sol_incluir_ocorrencias = true
                        else 
                            result_sol_incluir_ocorrencias = false
                    end
                
                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_iniciarPausaPlano']")
                            result_sol_iniciar_pausa_plano = true
                        else 
                            result_sol_iniciar_pausa_plano = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_reembolso_reembolsoPorSaldoCartao']")
                            result_sol_reembolso_saldo_cartao = true
                        else 
                            result_sol_reembolso_saldo_cartao = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_veiculoAtivo']")
                            result_sol_veiculo_ativo = true
                        else 
                            result_sol_veiculo_ativo = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_representanteComercial']")
                            result_sol_representante_comercial = true
                        else 
                            result_sol_representante_comercial = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_registrarSugestao']")
                            result_sol_registrar_sugestao = true
                        else 
                            result_sol_registrar_sugestao = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_inclusaoVeiculo']")
                            result_sol_inclusao_veiculo = true
                        else 
                            result_sol_inclusao_veiculo = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_priorizacao']")
                            result_sol_priorizacao = true
                        else 
                            result_sol_priorizacao = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_segundaViaDeExtrato']")
                            result_sol_segunda_via_extrato = true
                        else 
                            result_sol_segunda_via_extrato = false
                    end


                    #Demandas que não deve exibir para o perfil
                    if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_reenvioFaturaEmbarcador']")
                            result_sol_reenvio_fatura_embarcador = true
                        else 
                            result_sol_reenvio_fatura_embarcador = false
                    end
                    
                    if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_auxilioLocalizarTransportadorEmbarcador']")
                            result_sol_auxilio_localizador_transportador_vp = true
                        else 
                            result_sol_auxilio_localizador_transportador_vp = false
                    end
                    
                    if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_auxilionavegacaosite']")
                            result_sol_auxilio_navegacao_site = true
                        else 
                            result_sol_auxilio_navegacao_site = false
                    end

                    if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_integracaosistemica']")
                            result_sol_integracao_sistemica = true
                        else 
                            result_sol_integracao_sistemica = false
                    end        

                    if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_liberacaocreditohomologacaoembarcador']")
                            result_sol_liberacao_credito_embarcador = true
                        else 
                            result_sol_liberacao_credito_embarcador = false
                    end            

                    if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_reembolsoTransferenciaSaldo']")
                            result_sol_reembolso_transferencia_saldo = true
                        else 
                            result_sol_reembolso_transferencia_saldo = false
                    end            

                    if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_representanteComercialEmbarcador']")
                            result_sol_representante_comercial_embarcador = true
                        else 
                            result_sol_representante_comercial_embarcador = false
                    end  
                    
                    if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitar_incluirpromocao']")
                            result_sol_incluir_promocao = true
                        else 
                            result_sol_incluir_promocao = false
                    end

                    if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_reembolsoLiberalidade']")
                            result_sol_reembolso_liberalidade = true
                        else 
                            result_sol_reembolso_liberalidade = false
                    end

                    #DEV PRECISA CORRIGIR - ESTÁ EXIBINDO E NAO DEVERIA EXIBIR
                    # if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_bloqueioVeiculoVendido']")
                    #         result_sol_bloqueio_veiculo_vendido = true
                    #     else 
                    #         result_sol_bloqueio_veiculo_vendido = false
                    # end

                    if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_encerramentoTag']")
                            result_sol_encerramento_tag = true
                        else 
                            result_sol_encerramento_tag = false
                    end

                    if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_gravacaoatendimento']")
                            result_sol_gravacao_atendimento = true
                        else 
                            result_sol_gravacao_atendimento = false
                    end

                    if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_solicitarEsclarecimentoDuvidas']")
                            result_sol_esclarecimento_duvidas = true
                        else 
                            result_sol_esclarecimento_duvidas = false
                    end



                    if  result_sol_bloqueio_extravio && result_sol_encerramento_tag && result_sol_gravacao_atendimento &&
                        result_sol_historico_atendimento && result_sol_termo_adesao && result_sol_declaracao_quitacao_debitos && result_sol_emitir_nota_fiscal &&
                        result_sol_exclusao_serasa && result_sol_exclusao_produtos_adicionais && result_sol_inclusao_produtos_adicionais && result_sol_incluir_ocorrencias &&
                        result_sol_iniciar_pausa_plano && result_sol_reembolso_saldo_cartao && result_sol_segunda_via_extrato && result_sol_veiculo_ativo &&
                        result_sol_representante_comercial && result_sol_registrar_sugestao && result_sol_inclusao_veiculo && result_sol_priorizacao && result_sol_contato_televendas && 
                        result_sol_reenvio_fatura_embarcador && result_sol_esclarecimento_duvidas && result_sol_reembolso_liberalidade && result_sol_incluir_promocao && 
                        result_sol_auxilio_localizador_transportador_vp && result_sol_auxilio_navegacao_site && result_sol_integracao_sistemica && 
                        result_sol_liberacao_credito_embarcador && result_sol_reembolso_transferencia_saldo && result_sol_representante_comercial_embarcador == true
                        #result_sol_bloqueio_veiculo_vendido &&
                            puts "entrou true solicitar"
                            return true
                        else
                            puts "entrou false solicitar"
                            return false
            
                    end

            end
        
            when "Vale Pedágio"
   
                case demanda

                when "alterar"
                    find(:xpath, "//*[@name='Demandas_1wlw-select_key:{actionForm.primeiroNivelSelecionado}']/option[@value='#{demanda}']").click

                    #Demandas que deve exibir para o perfil

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_alterar_dadosCadastraisEmbarcador']")
                            result_alt_dados_embarcador = true
                        else 
                            result_alt_dados_embarcador = false
                    end

                    
                    #Demandas que não deve exibir para o perfil
                    if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_alterar_dadosCadastrais']")
                            result_alt_dados_cadastrais = true
                        else 
                            result_alt_dados_cadastrais = false
                    end

                    if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_alterar_dadosCadastraisVeiculo']")
                            result_alt_dados_veiculos = true
                        else 
                            result_alt_dados_veiculos = false
                    end

                    if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1NIvel_alterar_plano']")
                            result_alt_plano = true
                        else 
                            result_alt_plano = false
                    end

                    if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_alterar_telefonesms']")
                            result_alt_telefone_sms = true
                        else 
                            result_alt_telefone_sms = false
                    end
                    
                    if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_alterar_atualizacaoCadastralAnual']")
                            result_alt_atualizacao_anual = true
                        else 
                            result_alt_atualizacao_anual = false
                    end

                    if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_alterar_formaReembolso']")
                            result_alt_forma_reembolso = true
                        else 
                            result_alt_forma_reembolso = false
                    end

                    if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_alterar_alterarDadosCartaoCredito']")
                            result_alt_cartao_credito = true
                        else 
                            result_alt_cartao_credito = false
                    end

                    if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_alterar_alterarDadosContaCorrente']")
                            result_alt_conta_corrente = true
                        else 
                            result_alt_conta_corrente = false
                    end
                    
                    if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_alterar_alterarDataVencimento']")
                            result_alt_data_vencimento = true
                        else 
                            result_alt_data_vencimento = false
                    end

                    if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_alterar_formaPagamento']")
                            result_alt_forma_pagamento = true
                        else 
                            result_alt_forma_pagamento = false
                    end

                    if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_alterar_alterarValorPeriodico']")
                            result_alt_valor_periodico = true
                        else 
                            result_alt_valor_periodico = false
                    end


                    if result_alt_dados_cadastrais && result_alt_conta_corrente && result_alt_cartao_credito && result_alt_dados_veiculos && result_alt_data_vencimento &&
                        result_alt_telefone_sms && result_alt_forma_pagamento && result_alt_forma_reembolso && result_alt_valor_periodico && result_alt_atualizacao_anual && result_alt_dados_embarcador == true 
                            
                            puts "entrou true alterar"    
                            return true
                        else
                            puts "entrou false alterar"  
                            return false
                    end 


                when "consultar"

                    find(:xpath, "//*[@name='Demandas_1wlw-select_key:{actionForm.primeiroNivelSelecionado}']/option[@value='#{demanda}']").click
                                
                    #Demandas que deve exibir para o perfil
                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_historicoAtendimentos']")
                            result_cons_historico_atendimento = true
                        else 
                            result_cons_historico_atendimento = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_consultarViagemEmbarcador']")
                            result_cons_viagem_embarcador = true
                        else 
                            result_cons_viagem_embarcador = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_dadosCadastraisEmbarcador']")
                            result_cons_dados_embarcador = true
                        else 
                            result_cons_dados_embarcador = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_consultarExtratoEmbarcador']")
                            result_cons_extrato_embarcador = true
                        else 
                            result_cons_extrato_embarcador = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_faturaEmbarcador']")
                            result_cons_fatura_embarcador = true
                        else 
                            result_cons_fatura_embarcador = false
                    end


                    #Demandas que não deve exibir para o perfil

                    if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_cobrancaExternaJudicial']")
                            result_cons_cobranca_judicial= true
                        else 
                            result_cons_cobranca_judicial = false
                    end

                    if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_dadosCadastrais']")
                            result_cons_dados_cadastrais = true
                        else 
                            result_cons_dados_cadastrais = false
                    end
                    
                    if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_dadosDeCobranca']")
                            result_cons_dados_cobranca = true
                        else 
                            result_cons_dados_cobranca = false
                    end

                    if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_dispositivosVirtuais']")
                            result_cons_dispositivo_virtual = true
                        else 
                            result_cons_dispositivo_virtual = false
                    end

                    if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_consultarFatura']")
                            result_cons_faturas = true
                        else 
                            result_cons_faturas = false
                    end

                    if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_consultarLancamentoClienteCartao']")
                            result_cons_lancamento_cartao = true
                        else 
                            result_cons_lancamento_cartao = false
                    end

                    if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_procedimento']")
                            result_cons_procedimento = true
                        else 
                            result_cons_procedimento = false
                    end
                    
                    if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_situacaoTag']")
                            result_cons_situacao_tag = true
                        else 
                            result_cons_situacao_tag = false
                    end

                    if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_veiculos']")
                            result_cons_veiculos = true
                        else 
                            result_cons_veiculos = false
                    end

                    if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_utilizacao']")
                            result_cons_utilizacao = true
                        else 
                            result_cons_utilizacao = false
                    end

                    if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_limite_abastece']")
                            result_cons_limite_abastece = true
                        else 
                            result_cons_limite_abastece = false
                    end
                    
                    if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_historicoBloqueios']")
                            result_cons_historico_bloqueio = true
                        else 
                            result_cons_historico_bloqueio = false
                    end

                    if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consultar_credito']")
                            result_cons_credito = true
                        else 
                            result_cons_credito = false
                    end

                    if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_promocao']")
                            result_cons_promocao = true
                        else 
                            result_cons_promocao = false
                    end
                    
                    if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_historicoAlteracoes']")
                            result_cons_historico_alteracoes = true
                        else 
                            result_cons_historico_alteracoes = false
                    end

                    if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_consultaHistoricoInadimplencia']")
                            result_cons_historico_inadimplencia = true
                        else 
                            result_cons_historico_inadimplencia = false
                    end

                    if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consultar_produtos_suplementares']")
                            result_cons_produto_suplementar = true
                        else 
                            result_cons_produto_suplementar = false
                    end

                    if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_consultarReembolsos']")
                            result_cons_reembolso = true
                        else 
                            result_cons_reembolso = false
                    end

                    if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_historicoAnaliseCredito']")
                            result_cons_historico_analise_credito = true
                        else 
                            result_cons_historico_analise_credito = false
                    end



                    if  result_cons_historico_atendimento && result_cons_historico_bloqueio && result_cons_cobranca_judicial && result_cons_credito && result_cons_dados_cadastrais &&
                        result_cons_dados_cobranca && result_cons_dispositivo_virtual && result_cons_faturas && result_cons_historico_alteracoes && result_cons_historico_inadimplencia &&
                        result_cons_lancamento_cartao && result_cons_procedimento && result_cons_produto_suplementar && result_cons_promocao && result_cons_reembolso && 
                        result_cons_historico_analise_credito && result_cons_situacao_tag && result_cons_utilizacao && result_cons_veiculos && result_cons_viagem_embarcador &&
                        result_cons_dados_embarcador && result_cons_extrato_embarcador && result_cons_fatura_embarcador && result_cons_limite_abastece == true  
                            puts "entrou true consultar"    
                            return true
                        else
                            puts "entrou false consultar"    
                            return false
                    end 

                    

                when "contestar"

                    find(:xpath, "//*[@name='Demandas_1wlw-select_key:{actionForm.primeiroNivelSelecionado}']/option[@value='#{demanda}']").click

                    #Demandas que deve exibir para o perfil

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_contestar_credito_indisponivel_embarcador']")
                            result_const_credito_indisponivel_embarcador = true
                        else 
                            result_const_credito_indisponivel_embarcador = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_contestar_multaValePedagioEmbarcador']")
                            result_const_multa_vale_pedagio_embarcador = true
                        else 
                            result_const_multa_vale_pedagio_embarcador = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_contestar_viagemtransportadorvp']")
                            result_const_viagem_transportador_vp = true
                        else 
                            result_const_viagem_transportador_vp = false
                    end


                    
                    #Demandas que não deve exibir para o perfil
                    if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_contestar_multaEvasao']")
                            result_const_multa_evasao = true
                        else 
                            result_const_multa_evasao = false
                    end

                    if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_contestar_pagamentoIndevido']")
                            result_const_pagamento_indevido = true
                        else 
                            result_const_pagamento_indevido = false
                    end

                    if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_contestar_placa']")
                            result_const_placa = true
                        else 
                            result_const_placa = false
                    end

                    if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_contestar_passagempedagio']")
                            result_const_passagem_pedagio = true
                        else 
                            result_const_passagem_pedagio = false
                    end

                    if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_contestar_taxaExtravio']")
                            result_const_taxa = true
                        else 
                            result_const_taxa = false
                    end
                
                    if  result_const_multa_evasao && result_const_pagamento_indevido && result_const_placa && result_const_passagem_pedagio && result_const_taxa &&
                        result_const_credito_indisponivel_embarcador && result_const_multa_vale_pedagio_embarcador && result_const_viagem_transportador_vp == true
                        puts "entrou true contestar"        
                            return true
                        else
                            puts "entrou false contestar"
                            return false
                    end 


                when "reclamar"

                    find(:xpath, "//*[@name='Demandas_1wlw-select_key:{actionForm.primeiroNivelSelecionado}']/option[@value='#{demanda}']").click
        
                    #Demandas que deve exibir para o perfil
                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_reclamar_mauatendimentoEmbarcador']")
                            result_rec_mau_atendimento_embarcador = true
                        else 
                            result_rec_mau_atendimento_embarcador = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_reclamar_siteWebServiceEmbarcador']")
                            result_rec_site_service_embarcador = true
                        else 
                            result_rec_site_service_embarcador = false
                    end

                    
                    #Demandas que não deve exibir para o perfil
                    if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_reclamar_acidenteComCancela']")
                            result_rec_acidente_cancela = true
                        else 
                            result_rec_acidente_cancela = false
                    end

                    if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_reclamar_acidenteloja']")
                            result_rec_acidente_loja = true
                        else 
                            result_rec_acidente_loja = false
                    end

                    if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_reclamar_cancelanaoabriu']")
                            result_rec_cancela_nao_abriu = true
                        else 
                            result_rec_cancela_nao_abriu = false
                    end

                    if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_reclamar_ausenciaDebito']")
                            result_rec_ausencia_debito = true
                        else 
                            result_rec_ausencia_debito = false
                    end

                    if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_reclamar_tagNaoRecebido']")
                            result_rec_tag_nao_recebido = true
                        else 
                            result_rec_tag_nao_recebido = false
                    end

                    if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_reclamar_mauatendimento']")
                            result_rec_mau_atendimento = true
                        else 
                            result_rec_mau_atendimento = false
                    end

                    if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_reclamar_naoconsegueabastecer']")
                            result_rec_nao_consegue_abastecer = true
                        else 
                            result_rec_nao_consegue_abastecer = false
                    end
                    
                    if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_reclamar_tagSemCliente']")
                            result_rec_tag_sem_cliente = true
                        else 
                            result_rec_tag_sem_cliente = false
                    end

                    if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_reclamar_creditoNaoRecebido']")
                            result_rec_credito_nao_recebido = true
                        else 
                            result_rec_credito_nao_recebido = false
                    end

                    if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_reclamar_financiamento']")
                            result_rec_financiamento = true
                        else 
                            result_rec_financiamento = false
                    end


                    if result_rec_acidente_cancela && result_rec_acidente_loja && result_rec_cancela_nao_abriu && result_rec_ausencia_debito && result_rec_tag_nao_recebido &&
                    result_rec_mau_atendimento && result_rec_nao_consegue_abastecer && result_rec_tag_sem_cliente && result_rec_credito_nao_recebido && result_rec_financiamento &&
                    result_rec_mau_atendimento_embarcador && result_rec_site_service_embarcador == true
                            puts "entrou true reclamar"
                            return true
                        else
                            puts "entrou false reclamar"
                            return false

                    end

                    

                when "solicitar"

                    find(:xpath, "//*[@name='Demandas_1wlw-select_key:{actionForm.primeiroNivelSelecionado}']/option[@value='#{demanda}']").click

                    #Demandas que deve exibir para o perfil

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitar_incluirocorrencia']")
                            result_sol_incluir_ocorrencias = true
                        else 
                            result_sol_incluir_ocorrencias = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_reenvioFaturaEmbarcador']")
                            result_sol_reenvio_fatura_embarcador = true
                        else 
                            result_sol_reenvio_fatura_embarcador = false
                    end
                
                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_solicitarEsclarecimentoDuvidas']")
                            result_sol_esclarecimento_duvidas = true
                        else 
                            result_sol_esclarecimento_duvidas = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_auxilioLocalizarTransportadorEmbarcador']")
                            result_sol_auxilio_localizador_transportador_vp = true
                        else 
                            result_sol_auxilio_localizador_transportador_vp = false
                    end
                    
                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_auxilionavegacaosite']")
                            result_sol_auxilio_navegacao_site = true
                        else 
                            result_sol_auxilio_navegacao_site = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_integracaosistemica']")
                            result_sol_integracao_sistemica = true
                        else 
                            result_sol_integracao_sistemica = false
                    end        

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_liberacaocreditohomologacaoembarcador']")
                            result_sol_liberacao_credito_embarcador = true
                        else 
                            result_sol_liberacao_credito_embarcador = false
                    end            

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_reembolsoTransferenciaSaldo']")
                            result_sol_reembolso_transferencia_saldo = true
                        else 
                            result_sol_reembolso_transferencia_saldo = false
                    end            

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_representanteComercialEmbarcador']")
                            result_sol_representante_comercial_embarcador = true
                        else 
                            result_sol_representante_comercial_embarcador = false
                    end  


                    #Demandas que não deve exibir para o perfil
                    if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_exclusaoSerasa']")
                            result_sol_exclusao_serasa = true
                        else 
                            result_sol_exclusao_serasa = false
                    end

                    if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_segundaViaDeExtrato']")
                            result_sol_segunda_via_extrato = true
                        else 
                            result_sol_segunda_via_extrato = false
                    end

                    if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_bloqueioRouboExtravio']")
                            result_sol_bloqueio_extravio = true
                        else 
                            result_sol_bloqueio_extravio = false
                    end

                    if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_bloqueioVeiculoVendido']")
                            result_sol_bloqueio_veiculo_vendido = true
                        else 
                            result_sol_bloqueio_veiculo_vendido = false
                    end

                    if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_contatoTelevendas']")
                            result_sol_contato_televendas = true
                        else 
                            result_sol_contato_televendas = false
                    end

                    if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_encerramentoTag']")
                            result_sol_encerramento_tag = true
                        else 
                            result_sol_encerramento_tag = false
                    end

                    if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_gravacaoatendimento']")
                            result_sol_gravacao_atendimento = true
                        else 
                            result_sol_gravacao_atendimento = false
                    end

                    if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_historicoatendimento']")
                            result_sol_historico_atendimento = true
                        else 
                            result_sol_historico_atendimento = false
                    end

                    if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_solicitarTermoDeAdesao']")
                            result_sol_termo_adesao = true
                        else 
                            result_sol_termo_adesao = false
                    end

                    if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_declaracaoQuitacaoDebitos']")
                            result_sol_declaracao_quitacao_debitos = true
                        else 
                            result_sol_declaracao_quitacao_debitos = false
                    end

                    if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_emitirNotaFiscalEletronica']")
                            result_sol_emitir_nota_fiscal = true
                        else 
                            result_sol_emitir_nota_fiscal = false
                    end

                    if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_exclusaoProdutosAdicionais']")
                            result_sol_exclusao_produtos_adicionais = true
                        else 
                            result_sol_exclusao_produtos_adicionais = false
                    end

                    if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_inclusaoProdutosAdicionais']")
                            result_sol_inclusao_produtos_adicionais = true
                        else 
                            result_sol_inclusao_produtos_adicionais = false
                    end

                    
                
                    if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_iniciarPausaPlano']")
                            result_sol_iniciar_pausa_plano = true
                        else 
                            result_sol_iniciar_pausa_plano = false
                    end

                    if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_reembolso_reembolsoPorSaldoCartao']")
                            result_sol_reembolso_saldo_cartao = true
                        else 
                            result_sol_reembolso_saldo_cartao = false
                    end

                    if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_veiculoAtivo']")
                            result_sol_veiculo_ativo = true
                        else 
                            result_sol_veiculo_ativo = false
                    end

                    if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_representanteComercial']")
                            result_sol_representante_comercial = true
                        else 
                            result_sol_representante_comercial = false
                    end

                    if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_registrarSugestao']")
                            result_sol_registrar_sugestao = true
                        else 
                            result_sol_registrar_sugestao = false
                    end

                    if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_inclusaoVeiculo']")
                            result_sol_inclusao_veiculo = true
                        else 
                            result_sol_inclusao_veiculo = false
                    end

                    if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_priorizacao']")
                            result_sol_priorizacao = true
                        else 
                            result_sol_priorizacao = false
                    end

                    if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitar_incluirpromocao']")
                            result_sol_incluir_promocao = true
                        else 
                            result_sol_incluir_promocao = false
                    end

                    if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_reembolsoLiberalidade']")
                            result_sol_reembolso_liberalidade = true
                        else 
                            result_sol_reembolso_liberalidade = false
                    end


                    if  result_sol_bloqueio_extravio && result_sol_bloqueio_veiculo_vendido && result_sol_encerramento_tag && result_sol_gravacao_atendimento &&
                        result_sol_historico_atendimento && result_sol_termo_adesao && result_sol_declaracao_quitacao_debitos && result_sol_emitir_nota_fiscal &&
                        result_sol_exclusao_serasa && result_sol_exclusao_produtos_adicionais && result_sol_inclusao_produtos_adicionais && result_sol_incluir_ocorrencias &&
                        result_sol_iniciar_pausa_plano && result_sol_reembolso_saldo_cartao && result_sol_segunda_via_extrato && result_sol_veiculo_ativo &&
                        result_sol_representante_comercial && result_sol_registrar_sugestao && result_sol_inclusao_veiculo && result_sol_priorizacao && result_sol_contato_televendas && 
                        result_sol_reenvio_fatura_embarcador && result_sol_esclarecimento_duvidas && result_sol_reembolso_liberalidade && result_sol_incluir_promocao && 
                        result_sol_auxilio_localizador_transportador_vp && result_sol_auxilio_navegacao_site && result_sol_integracao_sistemica && 
                        result_sol_liberacao_credito_embarcador && result_sol_reembolso_transferencia_saldo && result_sol_representante_comercial_embarcador == true
                            puts "entrou true solicitar"
                            return true
                        else
                            puts "entrou false solicitar"
                            return false
            
                    end

            end

            when "Consulta"
    
                case demanda

                when "consultar"

                    find(:xpath, "//*[@name='Demandas_1wlw-select_key:{actionForm.primeiroNivelSelecionado}']/option[@value='#{demanda}']").click
                                
                    #Demandas que deve exibir para o perfil
                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_historicoAtendimentos']")
                            result_cons_historico_atendimento = true
                        else 
                            result_cons_historico_atendimento = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_cobrancaExternaJudicial']")
                            result_cons_cobranca_judicial= true
                        else 
                            result_cons_cobranca_judicial = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_dadosCadastrais']")
                            result_cons_dados_cadastrais = true
                        else 
                            result_cons_dados_cadastrais = false
                    end
                    
                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_dadosDeCobranca']")
                            result_cons_dados_cobranca = true
                        else 
                            result_cons_dados_cobranca = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_dispositivosVirtuais']")
                            result_cons_dispositivo_virtual = true
                        else 
                            result_cons_dispositivo_virtual = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_consultarFatura']")
                            result_cons_faturas = true
                        else 
                            result_cons_faturas = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_consultarLancamentoClienteCartao']")
                            result_cons_lancamento_cartao = true
                        else 
                            result_cons_lancamento_cartao = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_procedimento']")
                            result_cons_procedimento = true
                        else 
                            result_cons_procedimento = false
                    end
                    
                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_situacaoTag']")
                            result_cons_situacao_tag = true
                        else 
                            result_cons_situacao_tag = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_veiculos']")
                            result_cons_veiculos = true
                        else 
                            result_cons_veiculos = false
                    end
                    
                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_consultarViagemEmbarcador']")
                            result_cons_viagem_embarcador = true
                        else 
                            result_cons_viagem_embarcador = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_utilizacao']")
                            result_cons_utilizacao = true
                        else 
                            result_cons_utilizacao = false
                    end

                    #DEV PRECISA CORRIGIR - NAO ESTÁ EXIBINDO, MAS DEVERIA EXIBIR
                    # if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_limite_abastece']")
                    #         result_cons_limite_abastece = true
                    #     else 
                    #         result_cons_limite_abastece = false
                    # end
                    
                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_dadosCadastraisEmbarcador']")
                            result_cons_dados_embarcador = true
                        else 
                            result_cons_dados_embarcador = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_consultarExtratoEmbarcador']")
                            result_cons_extrato_embarcador = true
                        else 
                            result_cons_extrato_embarcador = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_faturaEmbarcador']")
                            result_cons_fatura_embarcador = true
                        else 
                            result_cons_fatura_embarcador = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_historicoBloqueios']")
                            result_cons_historico_bloqueio = true
                        else 
                            result_cons_historico_bloqueio = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consultar_credito']")
                            result_cons_credito = true
                        else 
                            result_cons_credito = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_promocao']")
                            result_cons_promocao = true
                        else 
                            result_cons_promocao = false
                    end
                    
                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_historicoAlteracoes']")
                            result_cons_historico_alteracoes = true
                        else 
                            result_cons_historico_alteracoes = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_consultaHistoricoInadimplencia']")
                            result_cons_historico_inadimplencia = true
                        else 
                            result_cons_historico_inadimplencia = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consultar_produtos_suplementares']")
                            result_cons_produto_suplementar = true
                        else 
                            result_cons_produto_suplementar = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_consultarReembolsos']")
                            result_cons_reembolso = true
                        else 
                            result_cons_reembolso = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_historicoAnaliseCredito']")
                            result_cons_historico_analise_credito = true
                        else 
                            result_cons_historico_analise_credito = false
                    end



                    if  result_cons_historico_atendimento && result_cons_historico_bloqueio && result_cons_cobranca_judicial && result_cons_credito && result_cons_dados_cadastrais &&
                        result_cons_dados_cobranca && result_cons_dispositivo_virtual && result_cons_faturas && result_cons_historico_alteracoes && result_cons_historico_inadimplencia &&
                        result_cons_lancamento_cartao && result_cons_procedimento && result_cons_produto_suplementar && result_cons_promocao && result_cons_reembolso && 
                        result_cons_historico_analise_credito && result_cons_situacao_tag && result_cons_utilizacao && result_cons_veiculos && result_cons_viagem_embarcador &&
                        result_cons_dados_embarcador && result_cons_extrato_embarcador && result_cons_fatura_embarcador  == true  #&& result_cons_limite_abastece
                            puts "entrou true consultar"    
                            return true
                        else
                            puts "entrou false consultar"    
                            return false
                    end 

                when "contestar"

                    find(:xpath, "//*[@name='Demandas_1wlw-select_key:{actionForm.primeiroNivelSelecionado}']/option[@value='#{demanda}']").click

                    #Demandas que deve exibir para o perfil
                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_contestar_multaEvasao']")
                            result_const_multa_evasao = true
                        else 
                            result_const_multa_evasao = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_contestar_pagamentoIndevido']")
                            result_const_pagamento_indevido = true
                        else 
                            result_const_pagamento_indevido = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_contestar_placa']")
                            result_const_placa = true
                        else 
                            result_const_placa = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_contestar_passagempedagio']")
                            result_const_passagem_pedagio = true
                        else 
                            result_const_passagem_pedagio = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_contestar_taxaExtravio']")
                            result_const_taxa = true
                        else 
                            result_const_taxa = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_contestar_credito_indisponivel_embarcador']")
                            result_const_credito_indisponivel_embarcador = true
                        else 
                            result_const_credito_indisponivel_embarcador = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_contestar_multaValePedagioEmbarcador']")
                            result_const_multa_vale_pedagio_embarcador = true
                        else 
                            result_const_multa_vale_pedagio_embarcador = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_contestar_viagemtransportadorvp']")
                            result_const_viagem_transportador_vp = true
                        else 
                            result_const_viagem_transportador_vp = false
                    end
                    
                   
                
                    if  result_const_multa_evasao && result_const_pagamento_indevido && result_const_placa && result_const_passagem_pedagio && result_const_taxa &&
                        result_const_credito_indisponivel_embarcador && result_const_multa_vale_pedagio_embarcador && result_const_viagem_transportador_vp == true
                        puts "entrou true contestar"        
                            return true
                        else
                            puts "entrou false contestar"
                            return false
                    end 
                    

                when "localizar"

                    find(:xpath, "//*[@name='Demandas_1wlw-select_key:{actionForm.primeiroNivelSelecionado}']/option[@value='#{demanda}']").click

                    #Demandas que deve exibir para o perfil
                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_localizar_baixapagamento']")
                            result_loc_baixa_pagamento = true
                        else 
                            result_loc_baixa_pagamento = false
                    end
                    
                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_localizar_tagdevolvido']")
                            result_const_tag_devolvido = true
                        else 
                            result_const_tag_devolvido = false
                    end
                
                    
                    if result_loc_baixa_pagamento && result_const_tag_devolvido == true
                            puts "entrou true localizar"    
                            return true
                        else
                            puts "entrou false localizar" 
                            return false
                    end
                

                when "reclamar"

                    find(:xpath, "//*[@name='Demandas_1wlw-select_key:{actionForm.primeiroNivelSelecionado}']/option[@value='#{demanda}']").click
        
                    #Demandas que deve exibir para o perfil
                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_reclamar_acidenteComCancela']")
                            result_rec_acidente_cancela = true
                        else 
                            result_rec_acidente_cancela = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_reclamar_acidenteloja']")
                            result_rec_acidente_loja = true
                        else 
                            result_rec_acidente_loja = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_reclamar_cancelanaoabriu']")
                            result_rec_cancela_nao_abriu = true
                        else 
                            result_rec_cancela_nao_abriu = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_reclamar_ausenciaDebito']")
                            result_rec_ausencia_debito = true
                        else 
                            result_rec_ausencia_debito = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_reclamar_tagNaoRecebido']")
                            result_rec_tag_nao_recebido = true
                        else 
                            result_rec_tag_nao_recebido = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_reclamar_mauatendimento']")
                            result_rec_mau_atendimento = true
                        else 
                            result_rec_mau_atendimento = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_reclamar_naoconsegueabastecer']")
                            result_rec_nao_consegue_abastecer = true
                        else 
                            result_rec_nao_consegue_abastecer = false
                    end
                    
                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_reclamar_tagSemCliente']")
                            result_rec_tag_sem_cliente = true
                        else 
                            result_rec_tag_sem_cliente = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_reclamar_creditoNaoRecebido']")
                            result_rec_credito_nao_recebido = true
                        else 
                            result_rec_credito_nao_recebido = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_reclamar_mauatendimentoEmbarcador']")
                            result_rec_mau_atendimento_embarcador = true
                        else 
                            result_rec_mau_atendimento_embarcador = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_reclamar_siteWebServiceEmbarcador']")
                            result_rec_site_service_embarcador = true
                        else 
                            result_rec_site_service_embarcador = false
                    end

                    

                    #Demandas que não deve exibir para o perfil
                    if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_reclamar_financiamento']")
                            result_rec_financiamento = true
                        else 
                            result_rec_financiamento = false
                    end
                    
                    
                    if result_rec_acidente_cancela && result_rec_acidente_loja && result_rec_cancela_nao_abriu && result_rec_ausencia_debito && result_rec_tag_nao_recebido &&
                    result_rec_mau_atendimento && result_rec_nao_consegue_abastecer && result_rec_tag_sem_cliente && result_rec_credito_nao_recebido && result_rec_financiamento &&
                    result_rec_mau_atendimento_embarcador && result_rec_site_service_embarcador == true
                            puts "entrou true reclamar"
                            return true
                        else
                            puts "entrou false reclamar"
                            return false

                    end



                when "solicitar"

                    find(:xpath, "//*[@name='Demandas_1wlw-select_key:{actionForm.primeiroNivelSelecionado}']/option[@value='#{demanda}']").click
            
                    #Demandas que deve exibir para o perfil
                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_bloqueioRouboExtravio']")
                            result_sol_bloqueio_extravio = true
                        else 
                            result_sol_bloqueio_extravio = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_contatoTelevendas']")
                            result_sol_contato_televendas = true
                        else 
                            result_sol_contato_televendas = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_encerramentoTag']")
                            result_sol_encerramento_tag = true
                        else 
                            result_sol_encerramento_tag = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_gravacaoatendimento']")
                            result_sol_gravacao_atendimento = true
                        else 
                            result_sol_gravacao_atendimento = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_historicoatendimento']")
                            result_sol_historico_atendimento = true
                        else 
                            result_sol_historico_atendimento = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_solicitarTermoDeAdesao']")
                            result_sol_termo_adesao = true
                        else 
                            result_sol_termo_adesao = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_declaracaoQuitacaoDebitos']")
                            result_sol_declaracao_quitacao_debitos = true
                        else 
                            result_sol_declaracao_quitacao_debitos = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_emitirNotaFiscalEletronica']")
                            result_sol_emitir_nota_fiscal = true
                        else 
                            result_sol_emitir_nota_fiscal = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_exclusaoSerasa']")
                            result_sol_exclusao_serasa = true
                        else 
                            result_sol_exclusao_serasa = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_exclusaoProdutosAdicionais']")
                            result_sol_exclusao_produtos_adicionais = true
                        else 
                            result_sol_exclusao_produtos_adicionais = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_inclusaoProdutosAdicionais']")
                            result_sol_inclusao_produtos_adicionais = true
                        else 
                            result_sol_inclusao_produtos_adicionais = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_reembolso_reembolsoPorSaldoCartao']")
                            result_sol_reembolso_saldo_cartao = true
                        else 
                            result_sol_reembolso_saldo_cartao = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_segundaViaDeExtrato']")
                            result_sol_segunda_via_extrato = true
                        else 
                            result_sol_segunda_via_extrato = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_veiculoAtivo']")
                            result_sol_veiculo_ativo = true
                        else 
                            result_sol_veiculo_ativo = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_representanteComercial']")
                            result_sol_representante_comercial = true
                        else 
                            result_sol_representante_comercial = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_registrarSugestao']")
                            result_sol_registrar_sugestao = true
                        else 
                            result_sol_registrar_sugestao = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_inclusaoVeiculo']")
                            result_sol_inclusao_veiculo = true
                        else 
                            result_sol_inclusao_veiculo = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_priorizacao']")
                            result_sol_priorizacao = true
                        else 
                            result_sol_priorizacao = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_reenvioFaturaEmbarcador']")
                            result_sol_reenvio_fatura_embarcador = true
                        else 
                            result_sol_reenvio_fatura_embarcador = false
                    end
                
                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_solicitarEsclarecimentoDuvidas']")
                            result_sol_esclarecimento_duvidas = true
                        else 
                            result_sol_esclarecimento_duvidas = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_auxilioLocalizarTransportadorEmbarcador']")
                            result_sol_auxilio_localizador_transportador_vp = true
                        else 
                            result_sol_auxilio_localizador_transportador_vp = false
                    end
                    
                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_auxilionavegacaosite']")
                            result_sol_auxilio_navegacao_site = true
                        else 
                            result_sol_auxilio_navegacao_site = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_integracaosistemica']")
                            result_sol_integracao_sistemica = true
                        else 
                            result_sol_integracao_sistemica = false
                    end        

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_liberacaocreditohomologacaoembarcador']")
                            result_sol_liberacao_credito_embarcador = true
                        else 
                            result_sol_liberacao_credito_embarcador = false
                    end            

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_reembolsoTransferenciaSaldo']")
                            result_sol_reembolso_transferencia_saldo = true
                        else 
                            result_sol_reembolso_transferencia_saldo = false
                    end            

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_representanteComercialEmbarcador']")
                            result_sol_representante_comercial_embarcador = true
                        else 
                            result_sol_representante_comercial_embarcador = false
                    end  

                    #DEV PRECISA CORRIGIR, ESTÁ EXIBINDO, MAS NAO DEVERIA EXIBIR
                    # if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_bloqueioVeiculoVendido']")
                    #         result_sol_bloqueio_veiculo_vendido = true
                    #     else 
                    #         result_sol_bloqueio_veiculo_vendido = false
                    # end

                    # if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_reembolsoLiberalidade']")
                    #         result_sol_reembolso_liberalidade = true
                    #     else 
                    #         result_sol_reembolso_liberalidade = false
                    # end

                    # if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitar_incluirocorrencia']")
                    #         result_sol_incluir_ocorrencias = true
                    #     else 
                    #         result_sol_incluir_ocorrencias = false
                    # end


                    #Demandas que não deve exibir para o perfil
                    if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitar_incluirpromocao']")
                            result_sol_incluir_promocao = true
                        else 
                            result_sol_incluir_promocao = false
                    end

                   
                
                    if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_iniciarPausaPlano']")
                            result_sol_iniciar_pausa_plano = true
                        else 
                            result_sol_iniciar_pausa_plano = false
                    end



                    if  result_sol_bloqueio_extravio && result_sol_encerramento_tag && result_sol_gravacao_atendimento &&
                        result_sol_historico_atendimento && result_sol_termo_adesao && result_sol_declaracao_quitacao_debitos && result_sol_emitir_nota_fiscal &&
                        result_sol_exclusao_serasa && result_sol_exclusao_produtos_adicionais && result_sol_inclusao_produtos_adicionais &&
                        result_sol_iniciar_pausa_plano && result_sol_reembolso_saldo_cartao && result_sol_segunda_via_extrato && result_sol_veiculo_ativo &&
                        result_sol_representante_comercial && result_sol_registrar_sugestao && result_sol_inclusao_veiculo && result_sol_priorizacao && result_sol_contato_televendas && 
                        result_sol_reenvio_fatura_embarcador && result_sol_esclarecimento_duvidas && result_sol_incluir_promocao && 
                        result_sol_auxilio_localizador_transportador_vp && result_sol_auxilio_navegacao_site && result_sol_integracao_sistemica && 
                        result_sol_liberacao_credito_embarcador && result_sol_reembolso_transferencia_saldo && result_sol_representante_comercial_embarcador == true
                        #&& result_sol_bloqueio_veiculo_vendido  && result_sol_incluir_ocorrencias   && result_sol_reembolso_liberalidade  
                        puts "entrou true solicitar"
                            return true
                        else
                            puts "entrou false solicitar"
                            return false
            
                    end

            end


            when "PA Movida"
        
                case demanda


                    when "alterar"
                    
                        find(:xpath, "//*[@name='Demandas_1wlw-select_key:{actionForm.primeiroNivelSelecionado}']/option[@value='#{demanda}']").click

                        #Demandas que deve exibir para o perfil
                        if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_alterar_dadosCadastrais']")
                                result_alt_dados_cadastrais = true
                            else 
                                result_alt_dados_cadastrais = false
                        end

                        if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_alterar_dadosCadastraisVeiculo']")
                                result_alt_dados_veiculos = true
                            else 
                                result_alt_dados_veiculos = false
                        end

                        if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_alterar_formaReembolso']")
                                result_alt_forma_reembolso = true
                            else 
                                result_alt_forma_reembolso = false
                        end
                        
                        #Demandas que não deve exibir para o perfil
                        if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_alterar_dadosCadastraisEmbarcador']")
                                result_alt_dados_embarcador = true
                            else 
                                result_alt_dados_embarcador = false
                        end

                        if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1NIvel_alterar_plano']")
                                result_alt_plano = true
                            else 
                                result_alt_plano = false
                        end

                        if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_alterar_telefonesms']")
                                result_alt_telefone_sms = true
                            else 
                                result_alt_telefone_sms = false
                        end
                        
                        if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_alterar_atualizacaoCadastralAnual']")
                                result_alt_atualizacao_anual = true
                            else 
                                result_alt_atualizacao_anual = false
                        end

                        if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_alterar_alterarDadosCartaoCredito']")
                                result_alt_cartao_credito = true
                            else 
                                result_alt_cartao_credito = false
                        end

                        if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_alterar_alterarDadosContaCorrente']")
                                result_alt_conta_corrente = true
                            else 
                                result_alt_conta_corrente = false
                        end
                        
                        if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_alterar_alterarDataVencimento']")
                                result_alt_data_vencimento = true
                            else 
                                result_alt_data_vencimento = false
                        end

                        if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_alterar_formaPagamento']")
                                result_alt_forma_pagamento = true
                            else 
                                result_alt_forma_pagamento = false
                        end

                        if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_alterar_alterarValorPeriodico']")
                                result_alt_valor_periodico = true
                            else 
                                result_alt_valor_periodico = false
                        end


                        if result_alt_dados_cadastrais && result_alt_conta_corrente && result_alt_cartao_credito && result_alt_dados_veiculos && result_alt_data_vencimento &&
                            result_alt_telefone_sms && result_alt_forma_pagamento && result_alt_forma_reembolso && result_alt_valor_periodico && result_alt_atualizacao_anual && result_alt_dados_embarcador == true 
                                
                                puts "entrou true alterar"    
                                return true
                            else
                                puts "entrou false alterar"  
                                return false
                        end 



                    when "consultar"

                        find(:xpath, "//*[@name='Demandas_1wlw-select_key:{actionForm.primeiroNivelSelecionado}']/option[@value='#{demanda}']").click
                                    
                        #Demandas que deve exibir para o perfil
                        if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_historicoAtendimentos']")
                                result_cons_historico_atendimento = true
                            else 
                                result_cons_historico_atendimento = false
                        end

                        if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_dadosDeCobranca']")
                                result_cons_dados_cobranca = true
                            else 
                                result_cons_dados_cobranca = false
                        end

                        if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_dadosCadastrais']")
                                result_cons_dados_cadastrais = true
                            else 
                                result_cons_dados_cadastrais = false
                        end

                        if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_historicoBloqueios']")
                                result_cons_historico_bloqueio = true
                            else 
                                result_cons_historico_bloqueio = false
                        end

                        if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consultar_credito']")
                                result_cons_credito = true
                            else 
                                result_cons_credito = false
                        end

                        if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_historicoAlteracoes']")
                                result_cons_historico_alteracoes = true
                            else 
                                result_cons_historico_alteracoes = false
                        end

                        if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_consultaHistoricoInadimplencia']")
                                result_cons_historico_inadimplencia = true
                            else 
                                result_cons_historico_inadimplencia = false
                        end

                        if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_veiculos']")
                                result_cons_veiculos = true
                            else 
                                result_cons_veiculos = false
                        end

                        if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_utilizacao']")
                                result_cons_utilizacao = true
                            else 
                                result_cons_utilizacao = false
                        end

                        #Demandas que não deve exibir para o perfil
                        if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_cobrancaExternaJudicial']")
                                result_cons_cobranca_judicial= true
                            else 
                                result_cons_cobranca_judicial = false
                        end

                        if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_dispositivosVirtuais']")
                                result_cons_dispositivo_virtual = true
                            else 
                                result_cons_dispositivo_virtual = false
                        end

                        if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_consultarFatura']")
                                result_cons_faturas = true
                            else 
                                result_cons_faturas = false
                        end

                        if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_consultarLancamentoClienteCartao']")
                                result_cons_lancamento_cartao = true
                            else 
                                result_cons_lancamento_cartao = false
                        end

                        if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_procedimento']")
                                result_cons_procedimento = true
                            else 
                                result_cons_procedimento = false
                        end
                        
                        if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_situacaoTag']")
                                result_cons_situacao_tag = true
                            else 
                                result_cons_situacao_tag = false
                        end

                        
                        
                        if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_consultarViagemEmbarcador']")
                                result_cons_viagem_embarcador = true
                            else 
                                result_cons_viagem_embarcador = false
                        end

                        #DEV PRECISA CORRIGIR - NAO ESTÁ EXIBINDO, MAS DEVERIA EXIBIR
                        if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_limite_abastece']")
                                result_cons_limite_abastece = true
                            else 
                                result_cons_limite_abastece = false
                        end
                        
                        if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_dadosCadastraisEmbarcador']")
                                result_cons_dados_embarcador = true
                            else 
                                result_cons_dados_embarcador = false
                        end

                        if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_consultarExtratoEmbarcador']")
                                result_cons_extrato_embarcador = true
                            else 
                                result_cons_extrato_embarcador = false
                        end

                        if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_faturaEmbarcador']")
                                result_cons_fatura_embarcador = true
                            else 
                                result_cons_fatura_embarcador = false
                        end

                        if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_promocao']")
                                result_cons_promocao = true
                            else 
                                result_cons_promocao = false
                        end
                        
                        if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consultar_produtos_suplementares']")
                                result_cons_produto_suplementar = true
                            else 
                                result_cons_produto_suplementar = false
                        end

                        if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_consultarReembolsos']")
                                result_cons_reembolso = true
                            else 
                                result_cons_reembolso = false
                        end

                        if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_historicoAnaliseCredito']")
                                result_cons_historico_analise_credito = true
                            else 
                                result_cons_historico_analise_credito = false
                        end


                        if  result_cons_historico_atendimento && result_cons_historico_bloqueio && result_cons_cobranca_judicial && result_cons_credito && result_cons_dados_cadastrais &&
                            result_cons_dados_cobranca && result_cons_dispositivo_virtual && result_cons_faturas && result_cons_historico_alteracoes && result_cons_historico_inadimplencia &&
                            result_cons_lancamento_cartao && result_cons_procedimento && result_cons_produto_suplementar && result_cons_promocao && result_cons_reembolso && 
                            result_cons_historico_analise_credito && result_cons_situacao_tag && result_cons_utilizacao && result_cons_veiculos && result_cons_viagem_embarcador &&
                            result_cons_dados_embarcador && result_cons_extrato_embarcador && result_cons_fatura_embarcador && result_cons_limite_abastece == true  
                                puts "entrou true consultar"    
                                return true
                            else
                                puts "entrou false consultar"    
                                return false
                        end 

                    when "contestar"
                        contestar_default(demanda)
                        

                    when "localizar"

                        find(:xpath, "//*[@name='Demandas_1wlw-select_key:{actionForm.primeiroNivelSelecionado}']/option[@value='#{demanda}']").click

                        #Demandas que deve exibir para o perfil
                        if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_localizar_baixapagamento']")
                                result_loc_baixa_pagamento = true
                            else 
                                result_loc_baixa_pagamento = false
                        end
                        
                        #Demandas que não deve exibir para o perfil
                        if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_localizar_tagdevolvido']")
                                result_const_tag_devolvido = true
                            else 
                                result_const_tag_devolvido = false
                        end
                    
                        
                        if result_loc_baixa_pagamento && result_const_tag_devolvido == true
                                puts "entrou true localizar"    
                                return true
                            else
                                puts "entrou false localizar" 
                                return false
                        end
                    

                    when "reclamar"

                        find(:xpath, "//*[@name='Demandas_1wlw-select_key:{actionForm.primeiroNivelSelecionado}']/option[@value='#{demanda}']").click
            
                        #Demandas que deve exibir para o perfil
                        if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_reclamar_acidenteComCancela']")
                                result_rec_acidente_cancela = true
                            else 
                                result_rec_acidente_cancela = false
                        end

                        if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_reclamar_cancelanaoabriu']")
                                result_rec_cancela_nao_abriu = true
                            else 
                                result_rec_cancela_nao_abriu = false
                        end

                        if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_reclamar_ausenciaDebito']")
                                result_rec_ausencia_debito = true
                            else 
                                result_rec_ausencia_debito = false
                        end

                        if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_reclamar_creditoNaoRecebido']")
                                result_rec_credito_nao_recebido = true
                            else 
                                result_rec_credito_nao_recebido = false
                        end

                        
                        #Demandas que não deve exibir para o perfil
                        if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_reclamar_financiamento']")
                                result_rec_financiamento = true
                            else 
                                result_rec_financiamento = false
                        end

                        if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_reclamar_acidenteloja']")
                                result_rec_acidente_loja = true
                            else 
                                result_rec_acidente_loja = false
                        end

                        if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_reclamar_tagNaoRecebido']")
                                result_rec_tag_nao_recebido = true
                            else 
                                result_rec_tag_nao_recebido = false
                        end

                        if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_reclamar_mauatendimento']")
                                result_rec_mau_atendimento = true
                            else 
                                result_rec_mau_atendimento = false
                        end

                        if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_reclamar_naoconsegueabastecer']")
                                result_rec_nao_consegue_abastecer = true
                            else 
                                result_rec_nao_consegue_abastecer = false
                        end
                        
                        if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_reclamar_tagSemCliente']")
                                result_rec_tag_sem_cliente = true
                            else 
                                result_rec_tag_sem_cliente = false
                        end

                        if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_reclamar_mauatendimentoEmbarcador']")
                                result_rec_mau_atendimento_embarcador = true
                            else 
                                result_rec_mau_atendimento_embarcador = false
                        end

                        if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_reclamar_siteWebServiceEmbarcador']")
                                result_rec_site_service_embarcador = true
                            else 
                                result_rec_site_service_embarcador = false
                        end
                        
                        
                        if result_rec_acidente_cancela && result_rec_acidente_loja && result_rec_cancela_nao_abriu && result_rec_ausencia_debito && result_rec_tag_nao_recebido &&
                        result_rec_mau_atendimento && result_rec_nao_consegue_abastecer && result_rec_tag_sem_cliente && result_rec_credito_nao_recebido && result_rec_financiamento &&
                        result_rec_mau_atendimento_embarcador && result_rec_site_service_embarcador == true
                                puts "entrou true reclamar"
                                return true
                            else
                                puts "entrou false reclamar"
                                return false

                        end



                    when "solicitar"

                        find(:xpath, "//*[@name='Demandas_1wlw-select_key:{actionForm.primeiroNivelSelecionado}']/option[@value='#{demanda}']").click
                
                        #Demandas que deve exibir para o perfil
                        if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_bloqueioRouboExtravio']")
                                result_sol_bloqueio_extravio = true
                            else 
                                result_sol_bloqueio_extravio = false
                        end

                        if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_bloqueioVeiculoVendido']")
                                result_sol_bloqueio_veiculo_vendido = true
                            else 
                                result_sol_bloqueio_veiculo_vendido = false
                        end

                        if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_declaracaoQuitacaoDebitos']")
                                result_sol_declaracao_quitacao_debitos = true
                            else 
                                result_sol_declaracao_quitacao_debitos = false
                        end

                        if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitar_incluirocorrencia']")
                                result_sol_incluir_ocorrencias = true
                            else 
                                result_sol_incluir_ocorrencias = false
                        end

                        if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_segundaViaDeExtrato']")
                                result_sol_segunda_via_extrato = true
                            else 
                                result_sol_segunda_via_extrato = false
                        end

                        #Demandas que não deve exibir para o perfil
                        if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_contatoTelevendas']")
                                result_sol_contato_televendas = true
                            else 
                                result_sol_contato_televendas = false
                        end

                        if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_encerramentoTag']")
                                result_sol_encerramento_tag = true
                            else 
                                result_sol_encerramento_tag = false
                        end

                        if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_gravacaoatendimento']")
                                result_sol_gravacao_atendimento = true
                            else 
                                result_sol_gravacao_atendimento = false
                        end

                        if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_historicoatendimento']")
                                result_sol_historico_atendimento = true
                            else 
                                result_sol_historico_atendimento = false
                        end

                        if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_solicitarTermoDeAdesao']")
                                result_sol_termo_adesao = true
                            else 
                                result_sol_termo_adesao = false
                        end

                        if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_emitirNotaFiscalEletronica']")
                                result_sol_emitir_nota_fiscal = true
                            else 
                                result_sol_emitir_nota_fiscal = false
                        end

                        if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_exclusaoSerasa']")
                                result_sol_exclusao_serasa = true
                            else 
                                result_sol_exclusao_serasa = false
                        end

                        if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_exclusaoProdutosAdicionais']")
                                result_sol_exclusao_produtos_adicionais = true
                            else 
                                result_sol_exclusao_produtos_adicionais = false
                        end

                        if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_inclusaoProdutosAdicionais']")
                                result_sol_inclusao_produtos_adicionais = true
                            else 
                                result_sol_inclusao_produtos_adicionais = false
                        end

                        if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_reembolso_reembolsoPorSaldoCartao']")
                                result_sol_reembolso_saldo_cartao = true
                            else 
                                result_sol_reembolso_saldo_cartao = false
                        end

                        if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_veiculoAtivo']")
                                result_sol_veiculo_ativo = true
                            else 
                                result_sol_veiculo_ativo = false
                        end

                        if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_representanteComercial']")
                                result_sol_representante_comercial = true
                            else 
                                result_sol_representante_comercial = false
                        end

                        if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_registrarSugestao']")
                                result_sol_registrar_sugestao = true
                            else 
                                result_sol_registrar_sugestao = false
                        end

                        if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_inclusaoVeiculo']")
                                result_sol_inclusao_veiculo = true
                            else 
                                result_sol_inclusao_veiculo = false
                        end

                        if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_priorizacao']")
                                result_sol_priorizacao = true
                            else 
                                result_sol_priorizacao = false
                        end

                        if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_reenvioFaturaEmbarcador']")
                                result_sol_reenvio_fatura_embarcador = true
                            else 
                                result_sol_reenvio_fatura_embarcador = false
                        end
                    
                        if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_solicitarEsclarecimentoDuvidas']")
                                result_sol_esclarecimento_duvidas = true
                            else 
                                result_sol_esclarecimento_duvidas = false
                        end

                        if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_auxilioLocalizarTransportadorEmbarcador']")
                                result_sol_auxilio_localizador_transportador_vp = true
                            else 
                                result_sol_auxilio_localizador_transportador_vp = false
                        end
                        
                        if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_auxilionavegacaosite']")
                                result_sol_auxilio_navegacao_site = true
                            else 
                                result_sol_auxilio_navegacao_site = false
                        end

                        if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_integracaosistemica']")
                                result_sol_integracao_sistemica = true
                            else 
                                result_sol_integracao_sistemica = false
                        end        

                        if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_liberacaocreditohomologacaoembarcador']")
                                result_sol_liberacao_credito_embarcador = true
                            else 
                                result_sol_liberacao_credito_embarcador = false
                        end            

                        if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_reembolsoTransferenciaSaldo']")
                                result_sol_reembolso_transferencia_saldo = true
                            else 
                                result_sol_reembolso_transferencia_saldo = false
                        end            

                        if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_representanteComercialEmbarcador']")
                                result_sol_representante_comercial_embarcador = true
                            else 
                                result_sol_representante_comercial_embarcador = false
                        end  

                        if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_reembolsoLiberalidade']")
                                result_sol_reembolso_liberalidade = true
                            else 
                                result_sol_reembolso_liberalidade = false
                        end

                        if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitar_incluirpromocao']")
                                result_sol_incluir_promocao = true
                            else 
                                result_sol_incluir_promocao = false
                        end

                        if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_iniciarPausaPlano']")
                                result_sol_iniciar_pausa_plano = true
                            else 
                                result_sol_iniciar_pausa_plano = false
                        end



                        if  result_sol_bloqueio_extravio && result_sol_encerramento_tag && result_sol_gravacao_atendimento &&
                            result_sol_historico_atendimento && result_sol_termo_adesao && result_sol_declaracao_quitacao_debitos && result_sol_emitir_nota_fiscal &&
                            result_sol_exclusao_serasa && result_sol_exclusao_produtos_adicionais && result_sol_inclusao_produtos_adicionais &&
                            result_sol_iniciar_pausa_plano && result_sol_reembolso_saldo_cartao && result_sol_segunda_via_extrato && result_sol_veiculo_ativo &&
                            result_sol_representante_comercial && result_sol_registrar_sugestao && result_sol_inclusao_veiculo && result_sol_priorizacao && result_sol_contato_televendas && 
                            result_sol_reenvio_fatura_embarcador && result_sol_esclarecimento_duvidas && result_sol_incluir_promocao && 
                            result_sol_auxilio_localizador_transportador_vp && result_sol_auxilio_navegacao_site && result_sol_integracao_sistemica && 
                            result_sol_liberacao_credito_embarcador && result_sol_reembolso_transferencia_saldo && result_sol_representante_comercial_embarcador &&
                            result_sol_bloqueio_veiculo_vendido  && result_sol_incluir_ocorrencias   && result_sol_reembolso_liberalidade  == true
                            puts "entrou true solicitar"
                                return true
                            else
                                puts "entrou false solicitar"
                                return false
                
                        end

                end


            when "Movida RAC"
        
                case demanda


                    when "alterar"
                    
                        find(:xpath, "//*[@name='Demandas_1wlw-select_key:{actionForm.primeiroNivelSelecionado}']/option[@value='#{demanda}']").click

                        #Demandas que deve exibir para o perfil
                        if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_alterar_dadosCadastrais']")
                                result_alt_dados_cadastrais = true
                            else 
                                result_alt_dados_cadastrais = false
                        end

                        if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_alterar_dadosCadastraisVeiculo']")
                                result_alt_dados_veiculos = true
                            else 
                                result_alt_dados_veiculos = false
                        end
                        
                        #Demandas que não deve exibir para o perfil
                        if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_alterar_formaReembolso']")
                                result_alt_forma_reembolso = true
                            else 
                                result_alt_forma_reembolso = false
                        end

                        if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_alterar_dadosCadastraisEmbarcador']")
                                result_alt_dados_embarcador = true
                            else 
                                result_alt_dados_embarcador = false
                        end

                        if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1NIvel_alterar_plano']")
                                result_alt_plano = true
                            else 
                                result_alt_plano = false
                        end

                        if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_alterar_telefonesms']")
                                result_alt_telefone_sms = true
                            else 
                                result_alt_telefone_sms = false
                        end
                        
                        if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_alterar_atualizacaoCadastralAnual']")
                                result_alt_atualizacao_anual = true
                            else 
                                result_alt_atualizacao_anual = false
                        end

                        if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_alterar_alterarDadosCartaoCredito']")
                                result_alt_cartao_credito = true
                            else 
                                result_alt_cartao_credito = false
                        end

                        if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_alterar_alterarDadosContaCorrente']")
                                result_alt_conta_corrente = true
                            else 
                                result_alt_conta_corrente = false
                        end
                        
                        if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_alterar_alterarDataVencimento']")
                                result_alt_data_vencimento = true
                            else 
                                result_alt_data_vencimento = false
                        end

                        if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_alterar_formaPagamento']")
                                result_alt_forma_pagamento = true
                            else 
                                result_alt_forma_pagamento = false
                        end

                        if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_alterar_alterarValorPeriodico']")
                                result_alt_valor_periodico = true
                            else 
                                result_alt_valor_periodico = false
                        end


                        if result_alt_dados_cadastrais && result_alt_conta_corrente && result_alt_cartao_credito && result_alt_dados_veiculos && result_alt_data_vencimento &&
                            result_alt_telefone_sms && result_alt_forma_pagamento && result_alt_forma_reembolso && result_alt_valor_periodico && result_alt_atualizacao_anual && result_alt_dados_embarcador == true 
                                
                                puts "entrou true alterar"    
                                return true
                            else
                                puts "entrou false alterar"  
                                return false
                        end 



                    when "consultar"

                        find(:xpath, "//*[@name='Demandas_1wlw-select_key:{actionForm.primeiroNivelSelecionado}']/option[@value='#{demanda}']").click
                                    
                        #Demandas que deve exibir para o perfil
                        if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_historicoAtendimentos']")
                                result_cons_historico_atendimento = true
                            else 
                                result_cons_historico_atendimento = false
                        end

                        if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_dadosDeCobranca']")
                                result_cons_dados_cobranca = true
                            else 
                                result_cons_dados_cobranca = false
                        end

                        if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_dadosCadastrais']")
                                result_cons_dados_cadastrais = true
                            else 
                                result_cons_dados_cadastrais = false
                        end

                        if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consultar_credito']")
                                result_cons_credito = true
                            else 
                                result_cons_credito = false
                        end

                        if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_veiculos']")
                                result_cons_veiculos = true
                            else 
                                result_cons_veiculos = false
                        end

                        if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_utilizacao']")
                                result_cons_utilizacao = true
                            else 
                                result_cons_utilizacao = false
                        end

                        #Demandas que não deve exibir para o perfil
                        if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_historicoBloqueios']")
                                result_cons_historico_bloqueio = true
                            else 
                                result_cons_historico_bloqueio = false
                        end

                        if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_historicoAlteracoes']")
                                result_cons_historico_alteracoes = true
                            else 
                                result_cons_historico_alteracoes = false
                        end

                        if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_consultaHistoricoInadimplencia']")
                                result_cons_historico_inadimplencia = true
                            else 
                                result_cons_historico_inadimplencia = false
                        end

                        if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_cobrancaExternaJudicial']")
                                result_cons_cobranca_judicial= true
                            else 
                                result_cons_cobranca_judicial = false
                        end

                        if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_dispositivosVirtuais']")
                                result_cons_dispositivo_virtual = true
                            else 
                                result_cons_dispositivo_virtual = false
                        end

                        if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_consultarFatura']")
                                result_cons_faturas = true
                            else 
                                result_cons_faturas = false
                        end

                        if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_consultarLancamentoClienteCartao']")
                                result_cons_lancamento_cartao = true
                            else 
                                result_cons_lancamento_cartao = false
                        end

                        if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_procedimento']")
                                result_cons_procedimento = true
                            else 
                                result_cons_procedimento = false
                        end
                        
                        if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_situacaoTag']")
                                result_cons_situacao_tag = true
                            else 
                                result_cons_situacao_tag = false
                        end

                        
                        
                        if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_consultarViagemEmbarcador']")
                                result_cons_viagem_embarcador = true
                            else 
                                result_cons_viagem_embarcador = false
                        end

                        #DEV PRECISA CORRIGIR - NAO ESTÁ EXIBINDO, MAS DEVERIA EXIBIR
                        if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_limite_abastece']")
                                result_cons_limite_abastece = true
                            else 
                                result_cons_limite_abastece = false
                        end
                        
                        if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_dadosCadastraisEmbarcador']")
                                result_cons_dados_embarcador = true
                            else 
                                result_cons_dados_embarcador = false
                        end

                        if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_consultarExtratoEmbarcador']")
                                result_cons_extrato_embarcador = true
                            else 
                                result_cons_extrato_embarcador = false
                        end

                        if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_faturaEmbarcador']")
                                result_cons_fatura_embarcador = true
                            else 
                                result_cons_fatura_embarcador = false
                        end

                        if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_promocao']")
                                result_cons_promocao = true
                            else 
                                result_cons_promocao = false
                        end
                        
                        if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consultar_produtos_suplementares']")
                                result_cons_produto_suplementar = true
                            else 
                                result_cons_produto_suplementar = false
                        end

                        if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_consultarReembolsos']")
                                result_cons_reembolso = true
                            else 
                                result_cons_reembolso = false
                        end

                        if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_historicoAnaliseCredito']")
                                result_cons_historico_analise_credito = true
                            else 
                                result_cons_historico_analise_credito = false
                        end


                        if  result_cons_historico_atendimento && result_cons_historico_bloqueio && result_cons_cobranca_judicial && result_cons_credito && result_cons_dados_cadastrais &&
                            result_cons_dados_cobranca && result_cons_dispositivo_virtual && result_cons_faturas && result_cons_historico_alteracoes && result_cons_historico_inadimplencia &&
                            result_cons_lancamento_cartao && result_cons_procedimento && result_cons_produto_suplementar && result_cons_promocao && result_cons_reembolso && 
                            result_cons_historico_analise_credito && result_cons_situacao_tag && result_cons_utilizacao && result_cons_veiculos && result_cons_viagem_embarcador &&
                            result_cons_dados_embarcador && result_cons_extrato_embarcador && result_cons_fatura_embarcador && result_cons_limite_abastece == true  
                                puts "entrou true consultar"    
                                return true
                            else
                                puts "entrou false consultar"    
                                return false
                        end 

                    when "contestar"
                        
                        find(:xpath, "//*[@name='Demandas_1wlw-select_key:{actionForm.primeiroNivelSelecionado}']/option[@value='#{demanda}']").click

                        #Demandas que deve exibir para o perfil
                        if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_contestar_multaEvasao']")
                                result_const_multa_evasao = true
                            else 
                                result_const_multa_evasao = false
                        end

                        if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_contestar_placa']")
                                result_const_placa = true
                            else 
                                result_const_placa = false
                        end

                        if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_contestar_passagempedagio']")
                                result_const_passagem_pedagio = true
                            else 
                                result_const_passagem_pedagio = false
                        end

                        if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_contestar_taxaExtravio']")
                                result_const_taxa = true
                            else 
                                result_const_taxa = false
                        end

                        #Demandas que não deve exibir para o perfil
                        if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_contestar_pagamentoIndevido']")
                                result_const_pagamento_indevido = true
                            else 
                                result_const_pagamento_indevido = false
                        end

                        if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_contestar_credito_indisponivel_embarcador']")
                                result_const_credito_indisponivel_embarcador = true
                            else 
                                result_const_credito_indisponivel_embarcador = false
                        end

                        if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_contestar_multaValePedagioEmbarcador']")
                                result_const_multa_vale_pedagio_embarcador = true
                            else 
                                result_const_multa_vale_pedagio_embarcador = false
                        end

                        if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_contestar_viagemtransportadorvp']")
                                result_const_viagem_transportador_vp = true
                            else 
                                result_const_viagem_transportador_vp = false
                        end
                    
                        if  result_const_multa_evasao && result_const_pagamento_indevido && result_const_placa && result_const_passagem_pedagio && result_const_taxa &&
                            result_const_credito_indisponivel_embarcador && result_const_multa_vale_pedagio_embarcador && result_const_viagem_transportador_vp == true
                            puts "entrou true contestar"        
                                return true
                            else
                                puts "entrou false contestar"
                                return false
                        end 

                        

                    when "localizar"

                        find(:xpath, "//*[@name='Demandas_1wlw-select_key:{actionForm.primeiroNivelSelecionado}']/option[@value='#{demanda}']").click

                        #Demandas que deve exibir para o perfil
                        if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_localizar_baixapagamento']")
                                result_loc_baixa_pagamento = true
                            else 
                                result_loc_baixa_pagamento = false
                        end
                        
                        #Demandas que não deve exibir para o perfil
                        if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_localizar_tagdevolvido']")
                                result_const_tag_devolvido = true
                            else 
                                result_const_tag_devolvido = false
                        end
                    
                        
                        if result_loc_baixa_pagamento && result_const_tag_devolvido == true
                                puts "entrou true localizar"    
                                return true
                            else
                                puts "entrou false localizar" 
                                return false
                        end
                    

                    when "reclamar"

                        find(:xpath, "//*[@name='Demandas_1wlw-select_key:{actionForm.primeiroNivelSelecionado}']/option[@value='#{demanda}']").click
            
                        #Demandas que deve exibir para o perfil
                        if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_reclamar_acidenteComCancela']")
                                result_rec_acidente_cancela = true
                            else 
                                result_rec_acidente_cancela = false
                        end

                        if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_reclamar_cancelanaoabriu']")
                                result_rec_cancela_nao_abriu = true
                            else 
                                result_rec_cancela_nao_abriu = false
                        end

                        
                        #Demandas que não deve exibir para o perfil
                        if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_reclamar_ausenciaDebito']")
                                result_rec_ausencia_debito = true
                            else 
                                result_rec_ausencia_debito = false
                        end

                        if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_reclamar_creditoNaoRecebido']")
                                result_rec_credito_nao_recebido = true
                            else 
                                result_rec_credito_nao_recebido = false
                        end

                        if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_reclamar_financiamento']")
                                result_rec_financiamento = true
                            else 
                                result_rec_financiamento = false
                        end

                        if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_reclamar_acidenteloja']")
                                result_rec_acidente_loja = true
                            else 
                                result_rec_acidente_loja = false
                        end

                        if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_reclamar_tagNaoRecebido']")
                                result_rec_tag_nao_recebido = true
                            else 
                                result_rec_tag_nao_recebido = false
                        end

                        if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_reclamar_mauatendimento']")
                                result_rec_mau_atendimento = true
                            else 
                                result_rec_mau_atendimento = false
                        end

                        if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_reclamar_naoconsegueabastecer']")
                                result_rec_nao_consegue_abastecer = true
                            else 
                                result_rec_nao_consegue_abastecer = false
                        end
                        
                        if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_reclamar_tagSemCliente']")
                                result_rec_tag_sem_cliente = true
                            else 
                                result_rec_tag_sem_cliente = false
                        end

                        if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_reclamar_mauatendimentoEmbarcador']")
                                result_rec_mau_atendimento_embarcador = true
                            else 
                                result_rec_mau_atendimento_embarcador = false
                        end

                        if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_reclamar_siteWebServiceEmbarcador']")
                                result_rec_site_service_embarcador = true
                            else 
                                result_rec_site_service_embarcador = false
                        end
                        
                        
                        if result_rec_acidente_cancela && result_rec_acidente_loja && result_rec_cancela_nao_abriu && result_rec_ausencia_debito && result_rec_tag_nao_recebido &&
                        result_rec_mau_atendimento && result_rec_nao_consegue_abastecer && result_rec_tag_sem_cliente && result_rec_credito_nao_recebido && result_rec_financiamento &&
                        result_rec_mau_atendimento_embarcador && result_rec_site_service_embarcador == true
                                puts "entrou true reclamar"
                                return true
                            else
                                puts "entrou false reclamar"
                                return false

                        end



                    
                    when "solicitar"

                        find(:xpath, "//*[@name='Demandas_1wlw-select_key:{actionForm.primeiroNivelSelecionado}']/option[@value='#{demanda}']").click
                
                        #Demandas que deve exibir para o perfil
                        if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_bloqueioRouboExtravio']")
                                result_sol_bloqueio_extravio = true
                            else 
                                result_sol_bloqueio_extravio = false
                        end

                        if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_declaracaoQuitacaoDebitos']")
                                result_sol_declaracao_quitacao_debitos = true
                            else 
                                result_sol_declaracao_quitacao_debitos = false
                        end

                        if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_segundaViaDeExtrato']")
                                result_sol_segunda_via_extrato = true
                            else 
                                result_sol_segunda_via_extrato = false
                        end

                        #Demandas que não deve exibir para o perfil
                        if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_bloqueioVeiculoVendido']")
                                result_sol_bloqueio_veiculo_vendido = true
                            else 
                                result_sol_bloqueio_veiculo_vendido = false
                        end

                        if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitar_incluirocorrencia']")
                                result_sol_incluir_ocorrencias = true
                            else 
                                result_sol_incluir_ocorrencias = false
                        end
                        
                        if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_contatoTelevendas']")
                                result_sol_contato_televendas = true
                            else 
                                result_sol_contato_televendas = false
                        end

                        if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_encerramentoTag']")
                                result_sol_encerramento_tag = true
                            else 
                                result_sol_encerramento_tag = false
                        end

                        if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_gravacaoatendimento']")
                                result_sol_gravacao_atendimento = true
                            else 
                                result_sol_gravacao_atendimento = false
                        end

                        if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_historicoatendimento']")
                                result_sol_historico_atendimento = true
                            else 
                                result_sol_historico_atendimento = false
                        end

                        if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_solicitarTermoDeAdesao']")
                                result_sol_termo_adesao = true
                            else 
                                result_sol_termo_adesao = false
                        end

                        if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_emitirNotaFiscalEletronica']")
                                result_sol_emitir_nota_fiscal = true
                            else 
                                result_sol_emitir_nota_fiscal = false
                        end

                        if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_exclusaoSerasa']")
                                result_sol_exclusao_serasa = true
                            else 
                                result_sol_exclusao_serasa = false
                        end

                        if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_exclusaoProdutosAdicionais']")
                                result_sol_exclusao_produtos_adicionais = true
                            else 
                                result_sol_exclusao_produtos_adicionais = false
                        end

                        if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_inclusaoProdutosAdicionais']")
                                result_sol_inclusao_produtos_adicionais = true
                            else 
                                result_sol_inclusao_produtos_adicionais = false
                        end

                        if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_reembolso_reembolsoPorSaldoCartao']")
                                result_sol_reembolso_saldo_cartao = true
                            else 
                                result_sol_reembolso_saldo_cartao = false
                        end

                        if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_veiculoAtivo']")
                                result_sol_veiculo_ativo = true
                            else 
                                result_sol_veiculo_ativo = false
                        end

                        if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_representanteComercial']")
                                result_sol_representante_comercial = true
                            else 
                                result_sol_representante_comercial = false
                        end

                        if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_registrarSugestao']")
                                result_sol_registrar_sugestao = true
                            else 
                                result_sol_registrar_sugestao = false
                        end

                        if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_inclusaoVeiculo']")
                                result_sol_inclusao_veiculo = true
                            else 
                                result_sol_inclusao_veiculo = false
                        end

                        if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_priorizacao']")
                                result_sol_priorizacao = true
                            else 
                                result_sol_priorizacao = false
                        end

                        if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_reenvioFaturaEmbarcador']")
                                result_sol_reenvio_fatura_embarcador = true
                            else 
                                result_sol_reenvio_fatura_embarcador = false
                        end
                    
                        if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_solicitarEsclarecimentoDuvidas']")
                                result_sol_esclarecimento_duvidas = true
                            else 
                                result_sol_esclarecimento_duvidas = false
                        end

                        if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_auxilioLocalizarTransportadorEmbarcador']")
                                result_sol_auxilio_localizador_transportador_vp = true
                            else 
                                result_sol_auxilio_localizador_transportador_vp = false
                        end
                        
                        if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_auxilionavegacaosite']")
                                result_sol_auxilio_navegacao_site = true
                            else 
                                result_sol_auxilio_navegacao_site = false
                        end

                        if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_integracaosistemica']")
                                result_sol_integracao_sistemica = true
                            else 
                                result_sol_integracao_sistemica = false
                        end        

                        if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_liberacaocreditohomologacaoembarcador']")
                                result_sol_liberacao_credito_embarcador = true
                            else 
                                result_sol_liberacao_credito_embarcador = false
                        end            

                        if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_reembolsoTransferenciaSaldo']")
                                result_sol_reembolso_transferencia_saldo = true
                            else 
                                result_sol_reembolso_transferencia_saldo = false
                        end            

                        if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_representanteComercialEmbarcador']")
                                result_sol_representante_comercial_embarcador = true
                            else 
                                result_sol_representante_comercial_embarcador = false
                        end  

                        if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_reembolsoLiberalidade']")
                                result_sol_reembolso_liberalidade = true
                            else 
                                result_sol_reembolso_liberalidade = false
                        end

                        if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitar_incluirpromocao']")
                                result_sol_incluir_promocao = true
                            else 
                                result_sol_incluir_promocao = false
                        end

                        if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_iniciarPausaPlano']")
                                result_sol_iniciar_pausa_plano = true
                            else 
                                result_sol_iniciar_pausa_plano = false
                        end



                        if  result_sol_bloqueio_extravio && result_sol_encerramento_tag && result_sol_gravacao_atendimento &&
                            result_sol_historico_atendimento && result_sol_termo_adesao && result_sol_declaracao_quitacao_debitos && result_sol_emitir_nota_fiscal &&
                            result_sol_exclusao_serasa && result_sol_exclusao_produtos_adicionais && result_sol_inclusao_produtos_adicionais &&
                            result_sol_iniciar_pausa_plano && result_sol_reembolso_saldo_cartao && result_sol_segunda_via_extrato && result_sol_veiculo_ativo &&
                            result_sol_representante_comercial && result_sol_registrar_sugestao && result_sol_inclusao_veiculo && result_sol_priorizacao && result_sol_contato_televendas && 
                            result_sol_reenvio_fatura_embarcador && result_sol_esclarecimento_duvidas && result_sol_incluir_promocao && 
                            result_sol_auxilio_localizador_transportador_vp && result_sol_auxilio_navegacao_site && result_sol_integracao_sistemica && 
                            result_sol_liberacao_credito_embarcador && result_sol_reembolso_transferencia_saldo && result_sol_representante_comercial_embarcador &&
                            result_sol_bloqueio_veiculo_vendido  && result_sol_incluir_ocorrencias   && result_sol_reembolso_liberalidade  == true
                            puts "entrou true solicitar"
                                return true
                            else
                                puts "entrou false solicitar"
                                return false
                
                        end

                end

            when "Admin Vendas"

                case demanda
                
                when "alterar"
                    alterar_default(demanda)
                    

                when "confirmar"
                    confirmar_default(demanda)
                    

                when "consultar"

                    find(:xpath, "//*[@name='Demandas_1wlw-select_key:{actionForm.primeiroNivelSelecionado}']/option[@value='#{demanda}']").click

                    #Demandas que deve exibir para o perfil
                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_historicoAtendimentos']")
                            result_cons_historico_atendimento = true
                        else 
                            result_cons_historico_atendimento = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_historicoBloqueios']")
                            result_cons_historico_bloqueio = true
                        else 
                            result_cons_historico_bloqueio = false
                    end
                    
                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_cobrancaExternaJudicial']")
                            result_cons_cobranca_judicial= true
                        else 
                            result_cons_cobranca_judicial = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consultar_credito']")
                            result_cons_credito = true
                        else 
                            result_cons_credito = false
                    end
                
                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_dadosCadastrais']")
                            result_cons_dados_cadastrais = true
                        else 
                            result_cons_dados_cadastrais = false
                    end
                    
                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_dadosDeCobranca']")
                            result_cons_dados_cobranca = true
                        else 
                            result_cons_dados_cobranca = false
                    end
                
                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_dispositivosVirtuais']")
                            result_cons_dispositivo_virtual = true
                        else 
                            result_cons_dispositivo_virtual = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_consultarFatura']")
                            result_cons_faturas = true
                        else 
                            result_cons_faturas = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_historicoAlteracoes']")
                            result_cons_historico_alteracoes = true
                        else 
                            result_cons_historico_alteracoes = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_consultaHistoricoInadimplencia']")
                            result_cons_historico_inadimplencia = true
                        else 
                            result_cons_historico_inadimplencia = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_consultarLancamentoClienteCartao']")
                            result_cons_lancamento_cartao = true
                        else 
                            result_cons_lancamento_cartao = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_procedimento']")
                            result_cons_procedimento = true
                        else 
                            result_cons_procedimento = false
                    end
                    
                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consultar_produtos_suplementares']")
                            result_cons_produto_suplementar = true
                        else 
                            result_cons_produto_suplementar = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_promocao']")
                            result_cons_promocao = true
                        else 
                            result_cons_promocao = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_consultarReembolsos']")
                            result_cons_reembolso = true
                        else 
                            result_cons_reembolso = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_historicoAnaliseCredito']")
                            result_cons_historico_analise_credito = true
                        else 
                            result_cons_historico_analise_credito = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_situacaoTag']")
                            result_cons_situacao_tag = true
                        else 
                            result_cons_situacao_tag = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_utilizacao']")
                            result_cons_utilizacao = true
                        else 
                            result_cons_utilizacao = false
                    end

                    
                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_veiculos']")
                            result_cons_veiculos = true
                        else 
                            result_cons_veiculos = false
                    end
                    
                            
                    #DEV PRECISA CORRIGIR
                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_limite_abastece']")
                            result_cons_limite_abastece = true
                        else 
                            result_cons_limite_abastece = false
                    end
                
                
                    #Demandas que não deve exibir para o perfil
                    if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_consultarViagemEmbarcador']")
                            result_cons_viagem_embarcador = true
                        else 
                            result_cons_viagem_embarcador = false
                    end

                    if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_dadosCadastraisEmbarcador']")
                            result_cons_dados_embarcador = true
                        else 
                            result_cons_dados_embarcador = false
                    end

                    if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_consultarExtratoEmbarcador']")
                            result_cons_extrato_embarcador = true
                        else 
                            result_cons_extrato_embarcador = false
                    end

                    if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_faturaEmbarcador']")
                            result_cons_fatura_embarcador = true
                        else 
                            result_cons_fatura_embarcador = false
                    end

                    if  result_cons_historico_atendimento && result_cons_historico_bloqueio && result_cons_cobranca_judicial && result_cons_credito && result_cons_dados_cadastrais &&
                        result_cons_dados_cobranca && result_cons_dispositivo_virtual && result_cons_faturas && result_cons_historico_alteracoes && result_cons_historico_inadimplencia &&
                        result_cons_lancamento_cartao && result_cons_procedimento && result_cons_produto_suplementar && result_cons_promocao && result_cons_reembolso && 
                        result_cons_historico_analise_credito && result_cons_situacao_tag && result_cons_utilizacao && result_cons_veiculos && result_cons_viagem_embarcador &&
                        result_cons_dados_embarcador && result_cons_extrato_embarcador && result_cons_fatura_embarcador && result_cons_limite_abastece == true 
                            puts "entrou true consultar"    
                            return true
                        else
                            puts "entrou false consultar"    
                            return false
                    end 
                   

                when "contestar"
                    contestar_default(demanda)


                when "localizar"
                    localizar_default(demanda)
                    

                when "reclamar"
                    
                    find(:xpath, "//*[@name='Demandas_1wlw-select_key:{actionForm.primeiroNivelSelecionado}']/option[@value='#{demanda}']").click
        
                    #Demandas que deve exibir para o perfil
                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_reclamar_acidenteComCancela']")
                            result_rec_acidente_cancela = true
                        else 
                            result_rec_acidente_cancela = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_reclamar_acidenteloja']")
                            result_rec_acidente_loja = true
                        else 
                            result_rec_acidente_loja = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_reclamar_cancelanaoabriu']")
                            result_rec_cancela_nao_abriu = true
                        else 
                            result_rec_cancela_nao_abriu = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_reclamar_ausenciaDebito']")
                            result_rec_ausencia_debito = true
                        else 
                            result_rec_ausencia_debito = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_reclamar_mauatendimento']")
                            result_rec_mau_atendimento = true
                        else 
                            result_rec_mau_atendimento = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_reclamar_naoconsegueabastecer']")
                            result_rec_nao_consegue_abastecer = true
                        else 
                            result_rec_nao_consegue_abastecer = false
                    end
                    
                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_reclamar_tagSemCliente']")
                            result_rec_tag_sem_cliente = true
                        else 
                            result_rec_tag_sem_cliente = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_reclamar_creditoNaoRecebido']")
                            result_rec_credito_nao_recebido = true
                        else 
                            result_rec_credito_nao_recebido = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_reclamar_financiamento']")
                            result_rec_financiamento = true
                        else 
                            result_rec_financiamento = false
                    end

                    #Demandas que não deve exibir para o perfil
                    if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_reclamar_mauatendimentoEmbarcador']")
                            result_rec_mau_atendimento_embarcador = true
                        else 
                            result_rec_mau_atendimento_embarcador = false
                    end

                    if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_reclamar_siteWebServiceEmbarcador']")
                            result_rec_site_service_embarcador = true
                        else 
                            result_rec_site_service_embarcador = false
                    end

                    # DEV PRECISA CORRIGIR, ESTA EXIBINDO MAS NAO DEVERIA
                    # if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_reclamar_tagNaoRecebido']")
                    #         result_rec_tag_nao_recebido = true
                    #     else 
                    #         result_rec_tag_nao_recebido = false
                    # end


                    if result_rec_acidente_cancela && result_rec_acidente_loja && result_rec_cancela_nao_abriu && result_rec_ausencia_debito && 
                    result_rec_mau_atendimento && result_rec_nao_consegue_abastecer && result_rec_tag_sem_cliente && result_rec_credito_nao_recebido && result_rec_financiamento &&
                    result_rec_mau_atendimento_embarcador && result_rec_site_service_embarcador == true # result_rec_tag_nao_recebido &&
                            puts "entrou true reclamar"
                            return true
                        else
                            puts "entrou false reclamar"
                            return false

                    end
                    

                when "solicitar"

                    find(:xpath, "//*[@name='Demandas_1wlw-select_key:{actionForm.primeiroNivelSelecionado}']/option[@value='#{demanda}']").click
            
                    #Demandas que deve exibir para o perfil
                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_bloqueioRouboExtravio']")
                            result_sol_bloqueio_extravio = true
                        else 
                            result_sol_bloqueio_extravio = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_bloqueioVeiculoVendido']")
                            result_sol_bloqueio_veiculo_vendido = true
                        else 
                            result_sol_bloqueio_veiculo_vendido = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_contatoTelevendas']")
                            result_sol_contato_televendas = true
                        else 
                            result_sol_contato_televendas = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_encerramentoTag']")
                            result_sol_encerramento_tag = true
                        else 
                            result_sol_encerramento_tag = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_historicoatendimento']")
                            result_sol_historico_atendimento = true
                        else 
                            result_sol_historico_atendimento = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_solicitarTermoDeAdesao']")
                            result_sol_termo_adesao = true
                        else 
                            result_sol_termo_adesao = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_declaracaoQuitacaoDebitos']")
                            result_sol_declaracao_quitacao_debitos = true
                        else 
                            result_sol_declaracao_quitacao_debitos = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_emitirNotaFiscalEletronica']")
                            result_sol_emitir_nota_fiscal = true
                        else 
                            result_sol_emitir_nota_fiscal = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_exclusaoSerasa']")
                            result_sol_exclusao_serasa = true
                        else 
                            result_sol_exclusao_serasa = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_exclusaoProdutosAdicionais']")
                            result_sol_exclusao_produtos_adicionais = true
                        else 
                            result_sol_exclusao_produtos_adicionais = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_inclusaoProdutosAdicionais']")
                            result_sol_inclusao_produtos_adicionais = true
                        else 
                            result_sol_inclusao_produtos_adicionais = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitar_incluirocorrencia']")
                            result_sol_incluir_ocorrencias = true
                        else 
                            result_sol_incluir_ocorrencias = false
                    end
                
                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_iniciarPausaPlano']")
                            result_sol_iniciar_pausa_plano = true
                        else 
                            result_sol_iniciar_pausa_plano = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_reembolso_reembolsoPorSaldoCartao']")
                            result_sol_reembolso_saldo_cartao = true
                        else 
                            result_sol_reembolso_saldo_cartao = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_segundaViaDeExtrato']")
                            result_sol_segunda_via_extrato = true
                        else 
                            result_sol_segunda_via_extrato = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_veiculoAtivo']")
                            result_sol_veiculo_ativo = true
                        else 
                            result_sol_veiculo_ativo = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_representanteComercial']")
                            result_sol_representante_comercial = true
                        else 
                            result_sol_representante_comercial = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_registrarSugestao']")
                            result_sol_registrar_sugestao = true
                        else 
                            result_sol_registrar_sugestao = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_inclusaoVeiculo']")
                            result_sol_inclusao_veiculo = true
                        else 
                            result_sol_inclusao_veiculo = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_priorizacao']")
                            result_sol_priorizacao = true
                        else 
                            result_sol_priorizacao = false
                    end

                    if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_reenvioFaturaEmbarcador']")
                            result_sol_reenvio_fatura_embarcador = true
                        else 
                            result_sol_reenvio_fatura_embarcador = false
                    end
                
                    
                    #Demandas que não deve exibir para o perfil
                    if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_solicitarEsclarecimentoDuvidas']")
                            result_sol_esclarecimento_duvidas = true
                        else 
                            result_sol_esclarecimento_duvidas = false
                    end

                    if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_gravacaoatendimento']")
                            result_sol_gravacao_atendimento = true
                        else 
                            result_sol_gravacao_atendimento = false
                    end

                    if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_auxilioLocalizarTransportadorEmbarcador']")
                            result_sol_auxilio_localizador_transportador_vp = true
                        else 
                            result_sol_auxilio_localizador_transportador_vp = false
                    end
                    
                    if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_auxilionavegacaosite']")
                            result_sol_auxilio_navegacao_site = true
                        else 
                            result_sol_auxilio_navegacao_site = false
                    end

                    if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_integracaosistemica']")
                            result_sol_integracao_sistemica = true
                        else 
                            result_sol_integracao_sistemica = false
                    end        

                    if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_liberacaocreditohomologacaoembarcador']")
                            result_sol_liberacao_credito_embarcador = true
                        else 
                            result_sol_liberacao_credito_embarcador = false
                    end            

                    if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_reembolsoTransferenciaSaldo']")
                            result_sol_reembolso_transferencia_saldo = true
                        else 
                            result_sol_reembolso_transferencia_saldo = false
                    end            

                    if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_representanteComercialEmbarcador']")
                            result_sol_representante_comercial_embarcador = true
                        else 
                            result_sol_representante_comercial_embarcador = false
                    end  
                    
                    if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitar_incluirpromocao']")
                            result_sol_incluir_promocao = true
                        else 
                            result_sol_incluir_promocao = false
                    end

                    if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_reembolsoLiberalidade']")
                            result_sol_reembolso_liberalidade = true
                        else 
                            result_sol_reembolso_liberalidade = false
                    end



                    if  result_sol_bloqueio_extravio && result_sol_bloqueio_veiculo_vendido && result_sol_encerramento_tag && result_sol_gravacao_atendimento &&
                        result_sol_historico_atendimento && result_sol_termo_adesao && result_sol_declaracao_quitacao_debitos && result_sol_emitir_nota_fiscal &&
                        result_sol_exclusao_serasa && result_sol_exclusao_produtos_adicionais && result_sol_inclusao_produtos_adicionais && result_sol_incluir_ocorrencias &&
                        result_sol_iniciar_pausa_plano && result_sol_reembolso_saldo_cartao && result_sol_segunda_via_extrato && result_sol_veiculo_ativo &&
                        result_sol_representante_comercial && result_sol_registrar_sugestao && result_sol_inclusao_veiculo && result_sol_priorizacao && result_sol_contato_televendas && 
                        result_sol_reenvio_fatura_embarcador && result_sol_esclarecimento_duvidas && result_sol_reembolso_liberalidade && result_sol_incluir_promocao && 
                        result_sol_auxilio_localizador_transportador_vp && result_sol_auxilio_navegacao_site && result_sol_integracao_sistemica && 
                        result_sol_liberacao_credito_embarcador && result_sol_reembolso_transferencia_saldo && result_sol_representante_comercial_embarcador == true
                            puts "entrou true solicitar"
                            return true
                        else
                            puts "entrou false solicitar"
                            return false
            
                    end


            end

        when "Televendas"

            case demanda
            
            when "alterar"
                alterar_default(demanda)
                

            when "consultar"

                find(:xpath, "//*[@name='Demandas_1wlw-select_key:{actionForm.primeiroNivelSelecionado}']/option[@value='#{demanda}']").click

                #Demandas que deve exibir para o perfil
                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_historicoAtendimentos']")
                        result_cons_historico_atendimento = true
                    else 
                        result_cons_historico_atendimento = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_historicoBloqueios']")
                        result_cons_historico_bloqueio = true
                    else 
                        result_cons_historico_bloqueio = false
                end
                
                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_cobrancaExternaJudicial']")
                        result_cons_cobranca_judicial= true
                    else 
                        result_cons_cobranca_judicial = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consultar_credito']")
                        result_cons_credito = true
                    else 
                        result_cons_credito = false
                end
            
                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_dadosCadastrais']")
                        result_cons_dados_cadastrais = true
                    else 
                        result_cons_dados_cadastrais = false
                end
                
                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_dadosDeCobranca']")
                        result_cons_dados_cobranca = true
                    else 
                        result_cons_dados_cobranca = false
                end
            
                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_dispositivosVirtuais']")
                        result_cons_dispositivo_virtual = true
                    else 
                        result_cons_dispositivo_virtual = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_consultarFatura']")
                        result_cons_faturas = true
                    else 
                        result_cons_faturas = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_historicoAlteracoes']")
                        result_cons_historico_alteracoes = true
                    else 
                        result_cons_historico_alteracoes = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_consultaHistoricoInadimplencia']")
                        result_cons_historico_inadimplencia = true
                    else 
                        result_cons_historico_inadimplencia = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_consultarLancamentoClienteCartao']")
                        result_cons_lancamento_cartao = true
                    else 
                        result_cons_lancamento_cartao = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_procedimento']")
                        result_cons_procedimento = true
                    else 
                        result_cons_procedimento = false
                end
                
                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consultar_produtos_suplementares']")
                        result_cons_produto_suplementar = true
                    else 
                        result_cons_produto_suplementar = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_promocao']")
                        result_cons_promocao = true
                    else 
                        result_cons_promocao = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_consultarReembolsos']")
                        result_cons_reembolso = true
                    else 
                        result_cons_reembolso = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_historicoAnaliseCredito']")
                        result_cons_historico_analise_credito = true
                    else 
                        result_cons_historico_analise_credito = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_situacaoTag']")
                        result_cons_situacao_tag = true
                    else 
                        result_cons_situacao_tag = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_utilizacao']")
                        result_cons_utilizacao = true
                    else 
                        result_cons_utilizacao = false
                end

                
                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_veiculos']")
                        result_cons_veiculos = true
                    else 
                        result_cons_veiculos = false
                end
               
                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_faturaEmbarcador']")
                        result_cons_fatura_embarcador = true
                    else 
                        result_cons_fatura_embarcador = false
                end
                
                #DEV PRECISA CORRIGIR
                # if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_limite_abastece']")
                #         result_cons_limite_abastece = true
                #     else 
                #         result_cons_limite_abastece = false
                # end
            
            
                #Demandas que não deve exibir para o perfil
                if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_consultarViagemEmbarcador']")
                        result_cons_viagem_embarcador = true
                    else 
                        result_cons_viagem_embarcador = false
                end

                if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_dadosCadastraisEmbarcador']")
                        result_cons_dados_embarcador = true
                    else 
                        result_cons_dados_embarcador = false
                end

                if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_consultarExtratoEmbarcador']")
                        result_cons_extrato_embarcador = true
                    else 
                        result_cons_extrato_embarcador = false
                end

                

                if  result_cons_historico_atendimento && result_cons_historico_bloqueio && result_cons_cobranca_judicial && result_cons_credito && result_cons_dados_cadastrais &&
                    result_cons_dados_cobranca && result_cons_dispositivo_virtual && result_cons_faturas && result_cons_historico_alteracoes && result_cons_historico_inadimplencia &&
                    result_cons_lancamento_cartao && result_cons_procedimento && result_cons_produto_suplementar && result_cons_promocao && result_cons_reembolso && 
                    result_cons_historico_analise_credito && result_cons_situacao_tag && result_cons_utilizacao && result_cons_veiculos && result_cons_viagem_embarcador &&
                    result_cons_dados_embarcador && result_cons_extrato_embarcador && result_cons_fatura_embarcador == true  #&& result_cons_limite_abastece
                        puts "entrou true consultar"    
                        return true
                    else
                        puts "entrou false consultar"    
                        return false
                end 
               

            when "contestar"
                contestar_default(demanda)


            when "localizar"
                localizar_default(demanda)
                

            when "reclamar"
                reclamar_default(demanda)
                

            when "solicitar"

                find(:xpath, "//*[@name='Demandas_1wlw-select_key:{actionForm.primeiroNivelSelecionado}']/option[@value='#{demanda}']").click
        
                #Demandas que deve exibir para o perfil
                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_bloqueioRouboExtravio']")
                        result_sol_bloqueio_extravio = true
                    else 
                        result_sol_bloqueio_extravio = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_bloqueioVeiculoVendido']")
                        result_sol_bloqueio_veiculo_vendido = true
                    else 
                        result_sol_bloqueio_veiculo_vendido = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_contatoTelevendas']")
                        result_sol_contato_televendas = true
                    else 
                        result_sol_contato_televendas = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_historicoatendimento']")
                        result_sol_historico_atendimento = true
                    else 
                        result_sol_historico_atendimento = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_solicitarTermoDeAdesao']")
                        result_sol_termo_adesao = true
                    else 
                        result_sol_termo_adesao = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_declaracaoQuitacaoDebitos']")
                        result_sol_declaracao_quitacao_debitos = true
                    else 
                        result_sol_declaracao_quitacao_debitos = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_emitirNotaFiscalEletronica']")
                        result_sol_emitir_nota_fiscal = true
                    else 
                        result_sol_emitir_nota_fiscal = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_exclusaoSerasa']")
                        result_sol_exclusao_serasa = true
                    else 
                        result_sol_exclusao_serasa = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_exclusaoProdutosAdicionais']")
                        result_sol_exclusao_produtos_adicionais = true
                    else 
                        result_sol_exclusao_produtos_adicionais = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_inclusaoProdutosAdicionais']")
                        result_sol_inclusao_produtos_adicionais = true
                    else 
                        result_sol_inclusao_produtos_adicionais = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitar_incluirocorrencia']")
                        result_sol_incluir_ocorrencias = true
                    else 
                        result_sol_incluir_ocorrencias = false
                end
            
                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_iniciarPausaPlano']")
                        result_sol_iniciar_pausa_plano = true
                    else 
                        result_sol_iniciar_pausa_plano = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_reembolso_reembolsoPorSaldoCartao']")
                        result_sol_reembolso_saldo_cartao = true
                    else 
                        result_sol_reembolso_saldo_cartao = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_segundaViaDeExtrato']")
                        result_sol_segunda_via_extrato = true
                    else 
                        result_sol_segunda_via_extrato = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_veiculoAtivo']")
                        result_sol_veiculo_ativo = true
                    else 
                        result_sol_veiculo_ativo = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_representanteComercial']")
                        result_sol_representante_comercial = true
                    else 
                        result_sol_representante_comercial = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_registrarSugestao']")
                        result_sol_registrar_sugestao = true
                    else 
                        result_sol_registrar_sugestao = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_inclusaoVeiculo']")
                        result_sol_inclusao_veiculo = true
                    else 
                        result_sol_inclusao_veiculo = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_priorizacao']")
                        result_sol_priorizacao = true
                    else 
                        result_sol_priorizacao = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_reenvioFaturaEmbarcador']")
                        result_sol_reenvio_fatura_embarcador = true
                    else 
                        result_sol_reenvio_fatura_embarcador = false
                end
            
                
                #Demandas que não deve exibir para o perfil
                if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_encerramentoTag']")
                        result_sol_encerramento_tag = true
                    else 
                        result_sol_encerramento_tag = false
                end

                if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_solicitarEsclarecimentoDuvidas']")
                        result_sol_esclarecimento_duvidas = true
                    else 
                        result_sol_esclarecimento_duvidas = false
                end

                if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_gravacaoatendimento']")
                        result_sol_gravacao_atendimento = true
                    else 
                        result_sol_gravacao_atendimento = false
                end

                if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_auxilioLocalizarTransportadorEmbarcador']")
                        result_sol_auxilio_localizador_transportador_vp = true
                    else 
                        result_sol_auxilio_localizador_transportador_vp = false
                end
                
                if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_auxilionavegacaosite']")
                        result_sol_auxilio_navegacao_site = true
                    else 
                        result_sol_auxilio_navegacao_site = false
                end

                if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_integracaosistemica']")
                        result_sol_integracao_sistemica = true
                    else 
                        result_sol_integracao_sistemica = false
                end        

                if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_liberacaocreditohomologacaoembarcador']")
                        result_sol_liberacao_credito_embarcador = true
                    else 
                        result_sol_liberacao_credito_embarcador = false
                end            

                if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_reembolsoTransferenciaSaldo']")
                        result_sol_reembolso_transferencia_saldo = true
                    else 
                        result_sol_reembolso_transferencia_saldo = false
                end            

                if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_representanteComercialEmbarcador']")
                        result_sol_representante_comercial_embarcador = true
                    else 
                        result_sol_representante_comercial_embarcador = false
                end  
                
                if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitar_incluirpromocao']")
                        result_sol_incluir_promocao = true
                    else 
                        result_sol_incluir_promocao = false
                end

                if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_reembolsoLiberalidade']")
                        result_sol_reembolso_liberalidade = true
                    else 
                        result_sol_reembolso_liberalidade = false
                end



                if  result_sol_bloqueio_extravio && result_sol_bloqueio_veiculo_vendido && result_sol_encerramento_tag && result_sol_gravacao_atendimento &&
                    result_sol_historico_atendimento && result_sol_termo_adesao && result_sol_declaracao_quitacao_debitos && result_sol_emitir_nota_fiscal &&
                    result_sol_exclusao_serasa && result_sol_exclusao_produtos_adicionais && result_sol_inclusao_produtos_adicionais && result_sol_incluir_ocorrencias &&
                    result_sol_iniciar_pausa_plano && result_sol_reembolso_saldo_cartao && result_sol_segunda_via_extrato && result_sol_veiculo_ativo &&
                    result_sol_representante_comercial && result_sol_registrar_sugestao && result_sol_inclusao_veiculo && result_sol_priorizacao && result_sol_contato_televendas && 
                    result_sol_reenvio_fatura_embarcador && result_sol_esclarecimento_duvidas && result_sol_reembolso_liberalidade && result_sol_incluir_promocao && 
                    result_sol_auxilio_localizador_transportador_vp && result_sol_auxilio_navegacao_site && result_sol_integracao_sistemica && 
                    result_sol_liberacao_credito_embarcador && result_sol_reembolso_transferencia_saldo && result_sol_representante_comercial_embarcador == true
                        puts "entrou true solicitar"
                        return true
                    else
                        puts "entrou false solicitar"
                        return false
        
                end
            end

        when "Fraude"

            case demanda
            
            when "alterar"
                alterar_default(demanda)
                

            when "confirmar"
                confirmar_default(demanda)
                

            when "consultar"
                consultar_default(demanda)
               

            when "contestar"
                contestar_default(demanda)


            when "localizar"
                localizar_default(demanda)
                

            when "reclamar"
                find(:xpath, "//*[@name='Demandas_1wlw-select_key:{actionForm.primeiroNivelSelecionado}']/option[@value='#{demanda}']").click
        
                #Demandas que deve exibir para o perfil
                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_reclamar_acidenteComCancela']")
                        result_rec_acidente_cancela = true
                    else 
                        result_rec_acidente_cancela = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_reclamar_acidenteloja']")
                        result_rec_acidente_loja = true
                    else 
                        result_rec_acidente_loja = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_reclamar_cancelanaoabriu']")
                        result_rec_cancela_nao_abriu = true
                    else 
                        result_rec_cancela_nao_abriu = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_reclamar_ausenciaDebito']")
                        result_rec_ausencia_debito = true
                    else 
                        result_rec_ausencia_debito = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_reclamar_mauatendimento']")
                        result_rec_mau_atendimento = true
                    else 
                        result_rec_mau_atendimento = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_reclamar_naoconsegueabastecer']")
                        result_rec_nao_consegue_abastecer = true
                    else 
                        result_rec_nao_consegue_abastecer = false
                end
                
                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_reclamar_tagSemCliente']")
                        result_rec_tag_sem_cliente = true
                    else 
                        result_rec_tag_sem_cliente = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_reclamar_creditoNaoRecebido']")
                        result_rec_credito_nao_recebido = true
                    else 
                        result_rec_credito_nao_recebido = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_reclamar_financiamento']")
                        result_rec_financiamento = true
                    else 
                        result_rec_financiamento = false
                end

                #Demandas que não deve exibir para o perfil
                if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_reclamar_mauatendimentoEmbarcador']")
                        result_rec_mau_atendimento_embarcador = true
                    else 
                        result_rec_mau_atendimento_embarcador = false
                end

                if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_reclamar_siteWebServiceEmbarcador']")
                        result_rec_site_service_embarcador = true
                    else 
                        result_rec_site_service_embarcador = false
                end
                # DEV PRECISAR CORRIGIR - EXIBE, MAS NAO DEVERIA EXIBIR
                # if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_reclamar_tagNaoRecebido']")
                #         result_rec_tag_nao_recebido = true
                #     else 
                #         result_rec_tag_nao_recebido = false
                # end


                if result_rec_acidente_cancela && result_rec_acidente_loja && result_rec_cancela_nao_abriu && result_rec_ausencia_debito && 
                result_rec_mau_atendimento && result_rec_nao_consegue_abastecer && result_rec_tag_sem_cliente && result_rec_credito_nao_recebido && result_rec_financiamento &&
                result_rec_mau_atendimento_embarcador && result_rec_site_service_embarcador == true #result_rec_tag_nao_recebido &&
                        puts "entrou true reclamar"
                        return true
                    else
                        puts "entrou false reclamar"
                        return false

                end
                

            when "solicitar"

                find(:xpath, "//*[@name='Demandas_1wlw-select_key:{actionForm.primeiroNivelSelecionado}']/option[@value='#{demanda}']").click
        
                #Demandas que deve exibir para o perfil
                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_bloqueioRouboExtravio']")
                        result_sol_bloqueio_extravio = true
                    else 
                        result_sol_bloqueio_extravio = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_bloqueioVeiculoVendido']")
                        result_sol_bloqueio_veiculo_vendido = true
                    else 
                        result_sol_bloqueio_veiculo_vendido = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_encerramentoTag']")
                        result_sol_encerramento_tag = true
                    else 
                        result_sol_encerramento_tag = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_gravacaoatendimento']")
                        result_sol_gravacao_atendimento = true
                    else 
                        result_sol_gravacao_atendimento = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_historicoatendimento']")
                        result_sol_historico_atendimento = true
                    else 
                        result_sol_historico_atendimento = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_solicitarTermoDeAdesao']")
                        result_sol_termo_adesao = true
                    else 
                        result_sol_termo_adesao = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_declaracaoQuitacaoDebitos']")
                        result_sol_declaracao_quitacao_debitos = true
                    else 
                        result_sol_declaracao_quitacao_debitos = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_emitirNotaFiscalEletronica']")
                        result_sol_emitir_nota_fiscal = true
                    else 
                        result_sol_emitir_nota_fiscal = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_exclusaoSerasa']")
                        result_sol_exclusao_serasa = true
                    else 
                        result_sol_exclusao_serasa = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_inclusaoProdutosAdicionais']")
                        result_sol_inclusao_produtos_adicionais = true
                    else 
                        result_sol_inclusao_produtos_adicionais = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitar_incluirocorrencia']")
                        result_sol_incluir_ocorrencias = true
                    else 
                        result_sol_incluir_ocorrencias = false
                end
            
                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_iniciarPausaPlano']")
                        result_sol_iniciar_pausa_plano = true
                    else 
                        result_sol_iniciar_pausa_plano = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_reembolso_reembolsoPorSaldoCartao']")
                        result_sol_reembolso_saldo_cartao = true
                    else 
                        result_sol_reembolso_saldo_cartao = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_segundaViaDeExtrato']")
                        result_sol_segunda_via_extrato = true
                    else 
                        result_sol_segunda_via_extrato = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_veiculoAtivo']")
                        result_sol_veiculo_ativo = true
                    else 
                        result_sol_veiculo_ativo = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_representanteComercial']")
                        result_sol_representante_comercial = true
                    else 
                        result_sol_representante_comercial = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_registrarSugestao']")
                        result_sol_registrar_sugestao = true
                    else 
                        result_sol_registrar_sugestao = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_inclusaoVeiculo']")
                        result_sol_inclusao_veiculo = true
                    else 
                        result_sol_inclusao_veiculo = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_priorizacao']")
                        result_sol_priorizacao = true
                    else 
                        result_sol_priorizacao = false
                end


                #Demandas que não deve exibir para o perfil
                if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_reenvioFaturaEmbarcador']")
                        result_sol_reenvio_fatura_embarcador = true
                    else 
                        result_sol_reenvio_fatura_embarcador = false
                end

                if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_solicitarEsclarecimentoDuvidas']")
                        result_sol_esclarecimento_duvidas = true
                    else 
                        result_sol_esclarecimento_duvidas = false
                end

                if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_contatoTelevendas']")
                        result_sol_contato_televendas = true
                    else 
                        result_sol_contato_televendas = false
                end

                if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_auxilioLocalizarTransportadorEmbarcador']")
                        result_sol_auxilio_localizador_transportador_vp = true
                    else 
                        result_sol_auxilio_localizador_transportador_vp = false
                end
                
                if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_auxilionavegacaosite']")
                        result_sol_auxilio_navegacao_site = true
                    else 
                        result_sol_auxilio_navegacao_site = false
                end

                if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_integracaosistemica']")
                        result_sol_integracao_sistemica = true
                    else 
                        result_sol_integracao_sistemica = false
                end        

                if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_liberacaocreditohomologacaoembarcador']")
                        result_sol_liberacao_credito_embarcador = true
                    else 
                        result_sol_liberacao_credito_embarcador = false
                end            

                if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_reembolsoTransferenciaSaldo']")
                        result_sol_reembolso_transferencia_saldo = true
                    else 
                        result_sol_reembolso_transferencia_saldo = false
                end            

                if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_representanteComercialEmbarcador']")
                        result_sol_representante_comercial_embarcador = true
                    else 
                        result_sol_representante_comercial_embarcador = false
                end  
                
                if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitar_incluirpromocao']")
                        result_sol_incluir_promocao = true
                    else 
                        result_sol_incluir_promocao = false
                end

                #DEV PRECISA CORRIGIR - ESTÁ EXIBINDO, MAS NAO DEVERIA EXIBIR
                # if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_reembolsoLiberalidade']")
                #         result_sol_reembolso_liberalidade = true
                #     else 
                #         result_sol_reembolso_liberalidade = false
                # end
                
                # if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_exclusaoProdutosAdicionais']")
                #         result_sol_exclusao_produtos_adicionais = true
                #     else 
                #         result_sol_exclusao_produtos_adicionais = false
                # end



                if  result_sol_bloqueio_extravio && result_sol_bloqueio_veiculo_vendido && result_sol_encerramento_tag && result_sol_gravacao_atendimento &&
                    result_sol_historico_atendimento && result_sol_termo_adesao && result_sol_declaracao_quitacao_debitos && result_sol_emitir_nota_fiscal &&
                    result_sol_exclusao_serasa && result_sol_inclusao_produtos_adicionais && result_sol_incluir_ocorrencias &&
                    result_sol_iniciar_pausa_plano && result_sol_reembolso_saldo_cartao && result_sol_segunda_via_extrato && result_sol_veiculo_ativo &&
                    result_sol_representante_comercial && result_sol_registrar_sugestao && result_sol_inclusao_veiculo && result_sol_priorizacao && result_sol_contato_televendas && 
                    result_sol_reenvio_fatura_embarcador && result_sol_esclarecimento_duvidas && result_sol_incluir_promocao && 
                    result_sol_auxilio_localizador_transportador_vp && result_sol_auxilio_navegacao_site && result_sol_integracao_sistemica && 
                    result_sol_liberacao_credito_embarcador && result_sol_reembolso_transferencia_saldo && result_sol_representante_comercial_embarcador == true
                    # && result_sol_exclusao_produtos_adicionais && result_sol_reembolso_liberalidade
                        puts "entrou true solicitar"
                        return true
                    else
                        puts "entrou false solicitar"
                        return false
        
                end
        end


        when "Atendimento Interno"

            case demanda
            
            when "alterar"
                alterar_default(demanda)
                

            when "confirmar"
                confirmar_default(demanda)
                

            when "consultar"
                consultar_default(demanda)
            

            when "contestar"
                contestar_default(demanda)


            when "localizar"
                localizar_default(demanda)
                

            when "reclamar"

                find(:xpath, "//*[@name='Demandas_1wlw-select_key:{actionForm.primeiroNivelSelecionado}']/option[@value='#{demanda}']").click
        
                #Demandas que deve exibir para o perfil
                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_reclamar_acidenteComCancela']")
                        result_rec_acidente_cancela = true
                    else 
                        result_rec_acidente_cancela = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_reclamar_acidenteloja']")
                        result_rec_acidente_loja = true
                    else 
                        result_rec_acidente_loja = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_reclamar_cancelanaoabriu']")
                        result_rec_cancela_nao_abriu = true
                    else 
                        result_rec_cancela_nao_abriu = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_reclamar_ausenciaDebito']")
                        result_rec_ausencia_debito = true
                    else 
                        result_rec_ausencia_debito = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_reclamar_mauatendimento']")
                        result_rec_mau_atendimento = true
                    else 
                        result_rec_mau_atendimento = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_reclamar_naoconsegueabastecer']")
                        result_rec_nao_consegue_abastecer = true
                    else 
                        result_rec_nao_consegue_abastecer = false
                end
                
                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_reclamar_tagSemCliente']")
                        result_rec_tag_sem_cliente = true
                    else 
                        result_rec_tag_sem_cliente = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_reclamar_creditoNaoRecebido']")
                        result_rec_credito_nao_recebido = true
                    else 
                        result_rec_credito_nao_recebido = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_reclamar_financiamento']")
                        result_rec_financiamento = true
                    else 
                        result_rec_financiamento = false
                end

                #Demandas que não deve exibir para o perfil
                if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_reclamar_mauatendimentoEmbarcador']")
                        result_rec_mau_atendimento_embarcador = true
                    else 
                        result_rec_mau_atendimento_embarcador = false
                end

                if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_reclamar_siteWebServiceEmbarcador']")
                        result_rec_site_service_embarcador = true
                    else 
                        result_rec_site_service_embarcador = false
                end

                # DEV PRECISA CORRIGIR - ESTÁ EXIBINDO, MAS NAO DEVERIA
                # if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_reclamar_tagNaoRecebido']")
                #         result_rec_tag_nao_recebido = true
                #     else 
                #         result_rec_tag_nao_recebido = false
                # end


                if result_rec_acidente_cancela && result_rec_acidente_loja && result_rec_cancela_nao_abriu && result_rec_ausencia_debito &&
                result_rec_mau_atendimento && result_rec_nao_consegue_abastecer && result_rec_tag_sem_cliente && result_rec_credito_nao_recebido && result_rec_financiamento &&
                result_rec_mau_atendimento_embarcador && result_rec_site_service_embarcador == true  # && result_rec_tag_nao_recebido
                        puts "entrou true reclamar"
                        return true
                    else
                        puts "entrou false reclamar"
                        return false

                end
                

            when "solicitar"

                find(:xpath, "//*[@name='Demandas_1wlw-select_key:{actionForm.primeiroNivelSelecionado}']/option[@value='#{demanda}']").click
        
                #Demandas que deve exibir para o perfil
                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_bloqueioRouboExtravio']")
                        result_sol_bloqueio_extravio = true
                    else 
                        result_sol_bloqueio_extravio = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_bloqueioVeiculoVendido']")
                        result_sol_bloqueio_veiculo_vendido = true
                    else 
                        result_sol_bloqueio_veiculo_vendido = false
                end

                #DEV PRECISA CORRIGIR, NAO EXIBE, MAS DEVERIA EXIBIR
                # if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_contatoTelevendas']")
                #         result_sol_contato_televendas = true
                #     else 
                #         result_sol_contato_televendas = false
                # end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_encerramentoTag']")
                        result_sol_encerramento_tag = true
                    else 
                        result_sol_encerramento_tag = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_historicoatendimento']")
                        result_sol_historico_atendimento = true
                    else 
                        result_sol_historico_atendimento = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_solicitarTermoDeAdesao']")
                        result_sol_termo_adesao = true
                    else 
                        result_sol_termo_adesao = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_declaracaoQuitacaoDebitos']")
                        result_sol_declaracao_quitacao_debitos = true
                    else 
                        result_sol_declaracao_quitacao_debitos = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_emitirNotaFiscalEletronica']")
                        result_sol_emitir_nota_fiscal = true
                    else 
                        result_sol_emitir_nota_fiscal = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_exclusaoSerasa']")
                        result_sol_exclusao_serasa = true
                    else 
                        result_sol_exclusao_serasa = false
                end

                #DEV PRECISA CORRIGIR, NAO EXIBE, MAS DEVERIA EXIBIR
                # if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_exclusaoProdutosAdicionais']")
                #         result_sol_exclusao_produtos_adicionais = true
                #     else 
                #         result_sol_exclusao_produtos_adicionais = false
                # end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_inclusaoProdutosAdicionais']")
                        result_sol_inclusao_produtos_adicionais = true
                    else 
                        result_sol_inclusao_produtos_adicionais = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitar_incluirocorrencia']")
                        result_sol_incluir_ocorrencias = true
                    else 
                        result_sol_incluir_ocorrencias = false
                end
            
                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_iniciarPausaPlano']")
                        result_sol_iniciar_pausa_plano = true
                    else 
                        result_sol_iniciar_pausa_plano = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_reembolso_reembolsoPorSaldoCartao']")
                        result_sol_reembolso_saldo_cartao = true
                    else 
                        result_sol_reembolso_saldo_cartao = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_segundaViaDeExtrato']")
                        result_sol_segunda_via_extrato = true
                    else 
                        result_sol_segunda_via_extrato = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_veiculoAtivo']")
                        result_sol_veiculo_ativo = true
                    else 
                        result_sol_veiculo_ativo = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_representanteComercial']")
                        result_sol_representante_comercial = true
                    else 
                        result_sol_representante_comercial = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_registrarSugestao']")
                        result_sol_registrar_sugestao = true
                    else 
                        result_sol_registrar_sugestao = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_inclusaoVeiculo']")
                        result_sol_inclusao_veiculo = true
                    else 
                        result_sol_inclusao_veiculo = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_priorizacao']")
                        result_sol_priorizacao = true
                    else 
                        result_sol_priorizacao = false
                end

                # DEV PRECISA CORRIGIR, NÃO EXIBE, MAS DEVERIA EXIBIR
                # if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_reenvioFaturaEmbarcador']")
                #         result_sol_reenvio_fatura_embarcador = true
                #     else 
                #         result_sol_reenvio_fatura_embarcador = false
                # end
            
                #Demandas que não deve exibir para o perfil
                if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_auxilioLocalizarTransportadorEmbarcador']")
                        result_sol_auxilio_localizador_transportador_vp = true
                    else 
                        result_sol_auxilio_localizador_transportador_vp = false
                end
                
                if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_auxilionavegacaosite']")
                        result_sol_auxilio_navegacao_site = true
                    else 
                        result_sol_auxilio_navegacao_site = false
                end

                if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_integracaosistemica']")
                        result_sol_integracao_sistemica = true
                    else 
                        result_sol_integracao_sistemica = false
                end        

                if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_liberacaocreditohomologacaoembarcador']")
                        result_sol_liberacao_credito_embarcador = true
                    else 
                        result_sol_liberacao_credito_embarcador = false
                end            

                if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_reembolsoTransferenciaSaldo']")
                        result_sol_reembolso_transferencia_saldo = true
                    else 
                        result_sol_reembolso_transferencia_saldo = false
                end            

                if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_representanteComercialEmbarcador']")
                        result_sol_representante_comercial_embarcador = true
                    else 
                        result_sol_representante_comercial_embarcador = false
                end  
                
                #DEV PRECISA CORRIGIR, ESTÁ EXIBINDO, MAS NAO DEVERIA EXIBIR
                # if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitar_incluirpromocao']")
                #         result_sol_incluir_promocao = true
                #     else 
                #         result_sol_incluir_promocao = false
                # end

                #DEV PRECISA CORRIGIR, ESTÁ EXIBINDO, MAS NAO DEVERIA EXIBIR
                # if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_reembolsoLiberalidade']")
                #         result_sol_reembolso_liberalidade = true
                #     else 
                #         result_sol_reembolso_liberalidade = false
                # end

                #DEV PRECISA CORRIGIR, ESTÁ EXIBINDO, MAS NAO DEVERIA EXIBIR
                # if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_gravacaoatendimento']")
                #         result_sol_gravacao_atendimento = true
                #     else 
                #         result_sol_gravacao_atendimento = false
                # end

                if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_solicitarEsclarecimentoDuvidas']")
                        result_sol_esclarecimento_duvidas = true
                    else 
                        result_sol_esclarecimento_duvidas = false
                end



                if  result_sol_bloqueio_extravio && result_sol_bloqueio_veiculo_vendido && result_sol_encerramento_tag &&
                    result_sol_historico_atendimento && result_sol_termo_adesao && result_sol_declaracao_quitacao_debitos && result_sol_emitir_nota_fiscal &&
                    result_sol_exclusao_serasa  && result_sol_inclusao_produtos_adicionais && result_sol_incluir_ocorrencias &&
                    result_sol_iniciar_pausa_plano && result_sol_reembolso_saldo_cartao && result_sol_segunda_via_extrato && result_sol_veiculo_ativo &&
                    result_sol_representante_comercial && result_sol_registrar_sugestao && result_sol_inclusao_veiculo && result_sol_priorizacao &&  
                    result_sol_esclarecimento_duvidas  && result_sol_auxilio_localizador_transportador_vp && result_sol_auxilio_navegacao_site &&
                    result_sol_integracao_sistemica &&  result_sol_liberacao_credito_embarcador && result_sol_reembolso_transferencia_saldo && result_sol_representante_comercial_embarcador == true
                    #&& result_sol_reenvio_fatura_embarcador && result_sol_gravacao_atendimento && result_sol_exclusao_produtos_adicionais 
                    #&& result_sol_contato_televendas && result_sol_reembolso_liberalidade result_sol_incluir_promocao && 
                        puts "entrou true solicitar"
                        return true
                    else
                        puts "entrou false solicitar"
                        return false
        
                end
        end



        when "Ouvidoria"

            case demanda
            
            when "alterar"
                alterar_default(demanda)
                

            when "confirmar"
                confirmar_default(demanda)
                

            when "consultar"
                consultar_default(demanda)
            

            when "contestar"
                contestar_default(demanda)


            when "localizar"
                localizar_default(demanda)
                

            when "reclamar"
                reclamar_default(demanda)
                

            when "solicitar"

                find(:xpath, "//*[@name='Demandas_1wlw-select_key:{actionForm.primeiroNivelSelecionado}']/option[@value='#{demanda}']").click
        
                #Demandas que deve exibir para o perfil
                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_bloqueioRouboExtravio']")
                        result_sol_bloqueio_extravio = true
                    else 
                        result_sol_bloqueio_extravio = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_bloqueioVeiculoVendido']")
                        result_sol_bloqueio_veiculo_vendido = true
                    else 
                        result_sol_bloqueio_veiculo_vendido = false
                end

                #DEV PRECISA CORRIGIR - NÃO EXIBE MAS DEVERIA EXIBIR
                # if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_contatoTelevendas']")
                #         result_sol_contato_televendas = true
                #     else 
                #         result_sol_contato_televendas = false
                # end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_encerramentoTag']")
                        result_sol_encerramento_tag = true
                    else 
                        result_sol_encerramento_tag = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_gravacaoatendimento']")
                        result_sol_gravacao_atendimento = true
                    else 
                        result_sol_gravacao_atendimento = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_historicoatendimento']")
                        result_sol_historico_atendimento = true
                    else 
                        result_sol_historico_atendimento = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_solicitarTermoDeAdesao']")
                        result_sol_termo_adesao = true
                    else 
                        result_sol_termo_adesao = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_declaracaoQuitacaoDebitos']")
                        result_sol_declaracao_quitacao_debitos = true
                    else 
                        result_sol_declaracao_quitacao_debitos = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_emitirNotaFiscalEletronica']")
                        result_sol_emitir_nota_fiscal = true
                    else 
                        result_sol_emitir_nota_fiscal = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_exclusaoSerasa']")
                        result_sol_exclusao_serasa = true
                    else 
                        result_sol_exclusao_serasa = false
                end

                #DEV PRECISA CORRIGIR - NÃO EXIBE MAS DEVERIA EXIBIR
                # if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_exclusaoProdutosAdicionais']")
                #         result_sol_exclusao_produtos_adicionais = true
                #     else 
                #         result_sol_exclusao_produtos_adicionais = false
                # end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_inclusaoProdutosAdicionais']")
                        result_sol_inclusao_produtos_adicionais = true
                    else 
                        result_sol_inclusao_produtos_adicionais = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitar_incluirocorrencia']")
                        result_sol_incluir_ocorrencias = true
                    else 
                        result_sol_incluir_ocorrencias = false
                end
            
                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_iniciarPausaPlano']")
                        result_sol_iniciar_pausa_plano = true
                    else 
                        result_sol_iniciar_pausa_plano = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_reembolso_reembolsoPorSaldoCartao']")
                        result_sol_reembolso_saldo_cartao = true
                    else 
                        result_sol_reembolso_saldo_cartao = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_segundaViaDeExtrato']")
                        result_sol_segunda_via_extrato = true
                    else 
                        result_sol_segunda_via_extrato = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_veiculoAtivo']")
                        result_sol_veiculo_ativo = true
                    else 
                        result_sol_veiculo_ativo = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_representanteComercial']")
                        result_sol_representante_comercial = true
                    else 
                        result_sol_representante_comercial = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_registrarSugestao']")
                        result_sol_registrar_sugestao = true
                    else 
                        result_sol_registrar_sugestao = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_inclusaoVeiculo']")
                        result_sol_inclusao_veiculo = true
                    else 
                        result_sol_inclusao_veiculo = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_priorizacao']")
                        result_sol_priorizacao = true
                    else 
                        result_sol_priorizacao = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_reembolsoLiberalidade']")
                        result_sol_reembolso_liberalidade = true
                    else 
                        result_sol_reembolso_liberalidade = false
                end


                #Demandas que não deve exibir para o perfil
                if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_auxilioLocalizarTransportadorEmbarcador']")
                        result_sol_auxilio_localizador_transportador_vp = true
                    else 
                        result_sol_auxilio_localizador_transportador_vp = false
                end
                
                if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_auxilionavegacaosite']")
                        result_sol_auxilio_navegacao_site = true
                    else 
                        result_sol_auxilio_navegacao_site = false
                end

                if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_integracaosistemica']")
                        result_sol_integracao_sistemica = true
                    else 
                        result_sol_integracao_sistemica = false
                end        

                if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_liberacaocreditohomologacaoembarcador']")
                        result_sol_liberacao_credito_embarcador = true
                    else 
                        result_sol_liberacao_credito_embarcador = false
                end            

                if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_reembolsoTransferenciaSaldo']")
                        result_sol_reembolso_transferencia_saldo = true
                    else 
                        result_sol_reembolso_transferencia_saldo = false
                end            

                if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_representanteComercialEmbarcador']")
                        result_sol_representante_comercial_embarcador = true
                    else 
                        result_sol_representante_comercial_embarcador = false
                end  
                
                if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitar_incluirpromocao']")
                        result_sol_incluir_promocao = true
                    else 
                        result_sol_incluir_promocao = false
                end

                if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_reenvioFaturaEmbarcador']")
                        result_sol_reenvio_fatura_embarcador = true
                    else 
                        result_sol_reenvio_fatura_embarcador = false
                end
            
                if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_solicitarEsclarecimentoDuvidas']")
                        result_sol_esclarecimento_duvidas = true
                    else 
                        result_sol_esclarecimento_duvidas = false
                end

                



                if  result_sol_bloqueio_extravio && result_sol_bloqueio_veiculo_vendido && result_sol_encerramento_tag && result_sol_gravacao_atendimento &&
                    result_sol_historico_atendimento && result_sol_termo_adesao && result_sol_declaracao_quitacao_debitos && result_sol_emitir_nota_fiscal &&
                    result_sol_exclusao_serasa && result_sol_inclusao_produtos_adicionais && result_sol_incluir_ocorrencias &&
                    result_sol_iniciar_pausa_plano && result_sol_reembolso_saldo_cartao && result_sol_segunda_via_extrato && result_sol_veiculo_ativo &&
                    result_sol_representante_comercial && result_sol_registrar_sugestao && result_sol_inclusao_veiculo && result_sol_priorizacao  && 
                    result_sol_reenvio_fatura_embarcador && result_sol_esclarecimento_duvidas && result_sol_reembolso_liberalidade && result_sol_incluir_promocao && 
                    result_sol_auxilio_localizador_transportador_vp && result_sol_auxilio_navegacao_site && result_sol_integracao_sistemica && 
                    result_sol_liberacao_credito_embarcador && result_sol_reembolso_transferencia_saldo && result_sol_representante_comercial_embarcador == true
                    #&& result_sol_contato_televendas && result_sol_exclusao_produtos_adicionais
                        puts "entrou true solicitar"
                        return true
                    else
                        puts "entrou false solicitar"
                        return false
        
                end
        end


        when "Qualidade de Cadastro"

            case demanda
            
            when "alterar"
                
                find(:xpath, "//*[@name='Demandas_1wlw-select_key:{actionForm.primeiroNivelSelecionado}']/option[@value='#{demanda}']").click
        
                #Demandas que deve exibir para o perfil
                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_alterar_alterarDadosCartaoCredito']")
                        result_alt_cartao_credito = true
                    else 
                        result_alt_cartao_credito = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_alterar_alterarDadosContaCorrente']")
                        result_alt_conta_corrente = true
                    else 
                        result_alt_conta_corrente = false
                end
                
                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_alterar_dadosCadastrais']")
                        result_alt_dados_cadastrais = true
                    else 
                        result_alt_dados_cadastrais = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_alterar_dadosCadastraisVeiculo']")
                        result_alt_dados_veiculos = true
                    else 
                        result_alt_dados_veiculos = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_alterar_alterarDataVencimento']")
                        result_alt_data_vencimento = true
                    else 
                        result_alt_data_vencimento = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_alterar_formaPagamento']")
                        result_alt_forma_pagamento = true
                    else 
                        result_alt_forma_pagamento = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_alterar_formaReembolso']")
                        result_alt_forma_reembolso = true
                    else 
                        result_alt_forma_reembolso = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1NIvel_alterar_plano']")
                        result_alt_plano = true
                    else 
                        result_alt_plano = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_alterar_alterarValorPeriodico']")
                        result_alt_valor_periodico = true
                    else 
                        result_alt_valor_periodico = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_alterar_atualizacaoCadastralAnual']")
                        result_alt_atualizacao_anual = true
                    else 
                        result_alt_atualizacao_anual = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_alterar_telefonesms']")
                        result_alt_telefone_sms = true
                    else 
                        result_alt_telefone_sms = false
                end
                
                
                #Demandas que não deve exibir para o perfil
                # DEV PRECISA CORRIGIR - ESTÁ EXIBINDO, MAS NAO DEVERIA EXIBIR
                # if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_alterar_dadosCadastraisEmbarcador']")
                #         result_alt_dados_embarcador = true
                #     else 
                #         result_alt_dados_embarcador = false
                # end
            
            
                if result_alt_dados_cadastrais && result_alt_conta_corrente && result_alt_cartao_credito && result_alt_dados_veiculos && result_alt_data_vencimento &&
                   result_alt_forma_pagamento && result_alt_forma_reembolso && result_alt_valor_periodico && result_alt_atualizacao_anual && result_alt_telefone_sms == true 
                   #result_alt_dados_embarcador && 
                        puts "entrou true alterar"    
                        return true
                    else
                        puts "entrou false alterar"  
                        return false
                end 
                

            when "confirmar"
                confirmar_default(demanda)
                

            when "consultar"
                consultar_default(demanda)
            

            when "contestar"
                contestar_default(demanda)


            when "localizar"
                localizar_default(demanda)
                

            when "reclamar"
                reclamar_default(demanda)
                

            when "solicitar"

                find(:xpath, "//*[@name='Demandas_1wlw-select_key:{actionForm.primeiroNivelSelecionado}']/option[@value='#{demanda}']").click
        
                #Demandas que deve exibir para o perfil
                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_bloqueioRouboExtravio']")
                        result_sol_bloqueio_extravio = true
                    else 
                        result_sol_bloqueio_extravio = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_bloqueioVeiculoVendido']")
                        result_sol_bloqueio_veiculo_vendido = true
                    else 
                        result_sol_bloqueio_veiculo_vendido = false
                end

                
                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_encerramentoTag']")
                        result_sol_encerramento_tag = true
                    else 
                        result_sol_encerramento_tag = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_gravacaoatendimento']")
                        result_sol_gravacao_atendimento = true
                    else 
                        result_sol_gravacao_atendimento = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_historicoatendimento']")
                        result_sol_historico_atendimento = true
                    else 
                        result_sol_historico_atendimento = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_solicitarTermoDeAdesao']")
                        result_sol_termo_adesao = true
                    else 
                        result_sol_termo_adesao = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_declaracaoQuitacaoDebitos']")
                        result_sol_declaracao_quitacao_debitos = true
                    else 
                        result_sol_declaracao_quitacao_debitos = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_emitirNotaFiscalEletronica']")
                        result_sol_emitir_nota_fiscal = true
                    else 
                        result_sol_emitir_nota_fiscal = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_exclusaoSerasa']")
                        result_sol_exclusao_serasa = true
                    else 
                        result_sol_exclusao_serasa = false
                end

                #DEV PRECISA CORRIGIR - NÃO EXIBE MAS DEVERIA EXIBIR
                # if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_exclusaoProdutosAdicionais']")
                #         result_sol_exclusao_produtos_adicionais = true
                #     else 
                #         result_sol_exclusao_produtos_adicionais = false
                # end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_inclusaoProdutosAdicionais']")
                        result_sol_inclusao_produtos_adicionais = true
                    else 
                        result_sol_inclusao_produtos_adicionais = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitar_incluirocorrencia']")
                        result_sol_incluir_ocorrencias = true
                    else 
                        result_sol_incluir_ocorrencias = false
                end
            
                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_iniciarPausaPlano']")
                        result_sol_iniciar_pausa_plano = true
                    else 
                        result_sol_iniciar_pausa_plano = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_reembolso_reembolsoPorSaldoCartao']")
                        result_sol_reembolso_saldo_cartao = true
                    else 
                        result_sol_reembolso_saldo_cartao = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_segundaViaDeExtrato']")
                        result_sol_segunda_via_extrato = true
                    else 
                        result_sol_segunda_via_extrato = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_veiculoAtivo']")
                        result_sol_veiculo_ativo = true
                    else 
                        result_sol_veiculo_ativo = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_representanteComercial']")
                        result_sol_representante_comercial = true
                    else 
                        result_sol_representante_comercial = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_registrarSugestao']")
                        result_sol_registrar_sugestao = true
                    else 
                        result_sol_registrar_sugestao = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_inclusaoVeiculo']")
                        result_sol_inclusao_veiculo = true
                    else 
                        result_sol_inclusao_veiculo = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_priorizacao']")
                        result_sol_priorizacao = true
                    else 
                        result_sol_priorizacao = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_reembolsoLiberalidade']")
                        result_sol_reembolso_liberalidade = true
                    else 
                        result_sol_reembolso_liberalidade = false
                end


                #Demandas que não deve exibir para o perfil
                if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_contatoTelevendas']")
                        result_sol_contato_televendas = true
                    else 
                        result_sol_contato_televendas = false
                end

                if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_auxilioLocalizarTransportadorEmbarcador']")
                        result_sol_auxilio_localizador_transportador_vp = true
                    else 
                        result_sol_auxilio_localizador_transportador_vp = false
                end
                
                if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_auxilionavegacaosite']")
                        result_sol_auxilio_navegacao_site = true
                    else 
                        result_sol_auxilio_navegacao_site = false
                end

                if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_integracaosistemica']")
                        result_sol_integracao_sistemica = true
                    else 
                        result_sol_integracao_sistemica = false
                end        

                if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_liberacaocreditohomologacaoembarcador']")
                        result_sol_liberacao_credito_embarcador = true
                    else 
                        result_sol_liberacao_credito_embarcador = false
                end            

                if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_reembolsoTransferenciaSaldo']")
                        result_sol_reembolso_transferencia_saldo = true
                    else 
                        result_sol_reembolso_transferencia_saldo = false
                end            

                if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_representanteComercialEmbarcador']")
                        result_sol_representante_comercial_embarcador = true
                    else 
                        result_sol_representante_comercial_embarcador = false
                end  
                
                if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitar_incluirpromocao']")
                        result_sol_incluir_promocao = true
                    else 
                        result_sol_incluir_promocao = false
                end

                if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_reenvioFaturaEmbarcador']")
                        result_sol_reenvio_fatura_embarcador = true
                    else 
                        result_sol_reenvio_fatura_embarcador = false
                end
            
                if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_solicitarEsclarecimentoDuvidas']")
                        result_sol_esclarecimento_duvidas = true
                    else 
                        result_sol_esclarecimento_duvidas = false
                end

                



                if  result_sol_bloqueio_extravio && result_sol_bloqueio_veiculo_vendido && result_sol_encerramento_tag && result_sol_gravacao_atendimento &&
                    result_sol_historico_atendimento && result_sol_termo_adesao && result_sol_declaracao_quitacao_debitos && result_sol_emitir_nota_fiscal &&
                    result_sol_exclusao_serasa && result_sol_inclusao_produtos_adicionais && result_sol_incluir_ocorrencias && result_sol_contato_televendas &&
                    result_sol_iniciar_pausa_plano && result_sol_reembolso_saldo_cartao && result_sol_segunda_via_extrato && result_sol_veiculo_ativo &&
                    result_sol_representante_comercial && result_sol_registrar_sugestao && result_sol_inclusao_veiculo && result_sol_priorizacao  && 
                    result_sol_reenvio_fatura_embarcador && result_sol_esclarecimento_duvidas && result_sol_reembolso_liberalidade && result_sol_incluir_promocao && 
                    result_sol_auxilio_localizador_transportador_vp && result_sol_auxilio_navegacao_site && result_sol_integracao_sistemica && 
                    result_sol_liberacao_credito_embarcador && result_sol_reembolso_transferencia_saldo && result_sol_representante_comercial_embarcador == true
                    #&& result_sol_exclusao_produtos_adicionais
                        puts "entrou true solicitar"
                        return true
                    else
                        puts "entrou false solicitar"
                        return false
        
                end
        end



        when "Chat"

            case demanda
            
            when "alterar"
                
                find(:xpath, "//*[@name='Demandas_1wlw-select_key:{actionForm.primeiroNivelSelecionado}']/option[@value='#{demanda}']").click
        
                #Demandas que deve exibir para o perfil
                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_alterar_dadosCadastrais']")
                        result_alt_dados_cadastrais = true
                    else 
                        result_alt_dados_cadastrais = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_alterar_dadosCadastraisVeiculo']")
                        result_alt_dados_veiculos = true
                    else 
                        result_alt_dados_veiculos = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_alterar_alterarDataVencimento']")
                        result_alt_data_vencimento = true
                    else 
                        result_alt_data_vencimento = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_alterar_formaReembolso']")
                        result_alt_forma_reembolso = true
                    else 
                        result_alt_forma_reembolso = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1NIvel_alterar_plano']")
                        result_alt_plano = true
                    else 
                        result_alt_plano = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_alterar_alterarValorPeriodico']")
                        result_alt_valor_periodico = true
                    else 
                        result_alt_valor_periodico = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_alterar_atualizacaoCadastralAnual']")
                        result_alt_atualizacao_anual = true
                    else 
                        result_alt_atualizacao_anual = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_alterar_telefonesms']")
                        result_alt_telefone_sms = true
                    else 
                        result_alt_telefone_sms = false
                end
                
                
                #Demandas que não deve exibir para o perfil
                if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_alterar_dadosCadastraisEmbarcador']")
                        result_alt_dados_embarcador = true
                    else 
                        result_alt_dados_embarcador = false
                end

                if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_alterar_alterarDadosCartaoCredito']")
                        result_alt_cartao_credito = true
                    else 
                        result_alt_cartao_credito = false
                end

                if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_alterar_alterarDadosContaCorrente']")
                        result_alt_conta_corrente = true
                    else 
                        result_alt_conta_corrente = false
                end

                if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_alterar_formaPagamento']")
                        result_alt_forma_pagamento = true
                    else 
                        result_alt_forma_pagamento = false
                end
            
            
                if result_alt_dados_cadastrais && result_alt_conta_corrente && result_alt_cartao_credito && result_alt_dados_veiculos && result_alt_data_vencimento &&
                result_alt_forma_pagamento && result_alt_forma_reembolso && result_alt_valor_periodico && result_alt_atualizacao_anual && result_alt_telefone_sms &&
                result_alt_dados_embarcador  == true 
                        puts "entrou true alterar"    
                        return true
                    else
                        puts "entrou false alterar"  
                        return false
                end 
                

            when "confirmar"
                confirmar_default(demanda)
                

            when "consultar"
                
                find(:xpath, "//*[@name='Demandas_1wlw-select_key:{actionForm.primeiroNivelSelecionado}']/option[@value='#{demanda}']").click

                #Demandas que deve exibir para o perfil
                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_historicoAtendimentos']")
                        result_cons_historico_atendimento = true
                    else 
                        result_cons_historico_atendimento = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_historicoBloqueios']")
                        result_cons_historico_bloqueio = true
                    else 
                        result_cons_historico_bloqueio = false
                end
                
                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_cobrancaExternaJudicial']")
                        result_cons_cobranca_judicial= true
                    else 
                        result_cons_cobranca_judicial = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consultar_credito']")
                        result_cons_credito = true
                    else 
                        result_cons_credito = false
                end
            
                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_dadosCadastrais']")
                        result_cons_dados_cadastrais = true
                    else 
                        result_cons_dados_cadastrais = false
                end
                
                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_dadosDeCobranca']")
                        result_cons_dados_cobranca = true
                    else 
                        result_cons_dados_cobranca = false
                end
            
                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_dispositivosVirtuais']")
                        result_cons_dispositivo_virtual = true
                    else 
                        result_cons_dispositivo_virtual = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_consultarFatura']")
                        result_cons_faturas = true
                    else 
                        result_cons_faturas = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_historicoAlteracoes']")
                        result_cons_historico_alteracoes = true
                    else 
                        result_cons_historico_alteracoes = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_consultaHistoricoInadimplencia']")
                        result_cons_historico_inadimplencia = true
                    else 
                        result_cons_historico_inadimplencia = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_consultarLancamentoClienteCartao']")
                        result_cons_lancamento_cartao = true
                    else 
                        result_cons_lancamento_cartao = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_procedimento']")
                        result_cons_procedimento = true
                    else 
                        result_cons_procedimento = false
                end
                
                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consultar_produtos_suplementares']")
                        result_cons_produto_suplementar = true
                    else 
                        result_cons_produto_suplementar = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_promocao']")
                        result_cons_promocao = true
                    else 
                        result_cons_promocao = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_consultarReembolsos']")
                        result_cons_reembolso = true
                    else 
                        result_cons_reembolso = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_historicoAnaliseCredito']")
                        result_cons_historico_analise_credito = true
                    else 
                        result_cons_historico_analise_credito = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_situacaoTag']")
                        result_cons_situacao_tag = true
                    else 
                        result_cons_situacao_tag = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_utilizacao']")
                        result_cons_utilizacao = true
                    else 
                        result_cons_utilizacao = false
                end

                
                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_veiculos']")
                        result_cons_veiculos = true
                    else 
                        result_cons_veiculos = false
                end
                
                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_consultarViagemEmbarcador']")
                        result_cons_viagem_embarcador = true
                    else 
                        result_cons_viagem_embarcador = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_limite_abastece']")
                        result_cons_limite_abastece = true
                    else 
                        result_cons_limite_abastece = false
                end

                # DEV PRECISA CORRIGIR, NAO EXIBE, MAS DEVERIA EXIBIR
                # if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_consultarExtratoEmbarcador']")
                #         result_cons_extrato_embarcador = true
                #     else 
                #         result_cons_extrato_embarcador = false
                # end
            
            
                #Demandas que não deve exibir para o perfil
                if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_dadosCadastraisEmbarcador']")
                        result_cons_dados_embarcador = true
                    else 
                        result_cons_dados_embarcador = false
                end

                if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_faturaEmbarcador']")
                        result_cons_fatura_embarcador = true
                    else 
                        result_cons_fatura_embarcador = false
                end

                if  result_cons_historico_atendimento && result_cons_historico_bloqueio && result_cons_cobranca_judicial && result_cons_credito && result_cons_dados_cadastrais &&
                    result_cons_dados_cobranca && result_cons_dispositivo_virtual && result_cons_faturas && result_cons_historico_alteracoes && result_cons_historico_inadimplencia &&
                    result_cons_lancamento_cartao && result_cons_procedimento && result_cons_produto_suplementar && result_cons_promocao && result_cons_reembolso && 
                    result_cons_historico_analise_credito && result_cons_situacao_tag && result_cons_utilizacao && result_cons_veiculos && result_cons_viagem_embarcador &&
                    result_cons_dados_embarcador  && result_cons_fatura_embarcador && result_cons_limite_abastece == true  # && result_cons_extrato_embarcador
                        puts "entrou true consultar"    
                        return true
                    else
                        puts "entrou false consultar"    
                        return false
                end 
            

            when "contestar"
                
                find(:xpath, "//*[@name='Demandas_1wlw-select_key:{actionForm.primeiroNivelSelecionado}']/option[@value='#{demanda}']").click

                #Demandas que deve exibir para o perfil
                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_contestar_multaEvasao']")
                        result_const_multa_evasao = true
                    else 
                        result_const_multa_evasao = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_contestar_pagamentoIndevido']")
                        result_const_pagamento_indevido = true
                    else 
                        result_const_pagamento_indevido = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_contestar_placa']")
                        result_const_placa = true
                    else 
                        result_const_placa = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_contestar_passagempedagio']")
                        result_const_passagem_pedagio = true
                    else 
                        result_const_passagem_pedagio = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_contestar_taxaExtravio']")
                        result_const_taxa = true
                    else 
                        result_const_taxa = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_contestar_credito_indisponivel_embarcador']")
                        result_const_credito_indisponivel_embarcador = true
                    else 
                        result_const_credito_indisponivel_embarcador = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_contestar_multaValePedagioEmbarcador']")
                        result_const_multa_vale_pedagio_embarcador = true
                    else 
                        result_const_multa_vale_pedagio_embarcador = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_contestar_viagemtransportadorvp']")
                        result_const_viagem_transportador_vp = true
                    else 
                        result_const_viagem_transportador_vp = false
                end
            
                if  result_const_multa_evasao && result_const_pagamento_indevido && result_const_placa && result_const_passagem_pedagio && result_const_taxa &&
                    result_const_credito_indisponivel_embarcador && result_const_multa_vale_pedagio_embarcador && result_const_viagem_transportador_vp == true
                    puts "entrou true contestar"        
                        return true
                    else
                        puts "entrou false contestar"
                        return false
                end 


            when "localizar"
                localizar_default(demanda)
                

            when "reclamar"
                
                find(:xpath, "//*[@name='Demandas_1wlw-select_key:{actionForm.primeiroNivelSelecionado}']/option[@value='#{demanda}']").click
        
                #Demandas que deve exibir para o perfil
                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_reclamar_acidenteComCancela']")
                        result_rec_acidente_cancela = true
                    else 
                        result_rec_acidente_cancela = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_reclamar_acidenteloja']")
                        result_rec_acidente_loja = true
                    else 
                        result_rec_acidente_loja = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_reclamar_cancelanaoabriu']")
                        result_rec_cancela_nao_abriu = true
                    else 
                        result_rec_cancela_nao_abriu = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_reclamar_ausenciaDebito']")
                        result_rec_ausencia_debito = true
                    else 
                        result_rec_ausencia_debito = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_reclamar_tagNaoRecebido']")
                        result_rec_tag_nao_recebido = true
                    else 
                        result_rec_tag_nao_recebido = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_reclamar_mauatendimento']")
                        result_rec_mau_atendimento = true
                    else 
                        result_rec_mau_atendimento = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_reclamar_tagSemCliente']")
                        result_rec_tag_sem_cliente = true
                    else 
                        result_rec_tag_sem_cliente = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_reclamar_creditoNaoRecebido']")
                        result_rec_credito_nao_recebido = true
                    else 
                        result_rec_credito_nao_recebido = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_reclamar_financiamento']")
                        result_rec_financiamento = true
                    else 
                        result_rec_financiamento = false
                end

                #Demandas que não deve exibir para o perfil
                if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_reclamar_mauatendimentoEmbarcador']")
                        result_rec_mau_atendimento_embarcador = true
                    else 
                        result_rec_mau_atendimento_embarcador = false
                end

                if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_reclamar_siteWebServiceEmbarcador']")
                        result_rec_site_service_embarcador = true
                    else 
                        result_rec_site_service_embarcador = false
                end

                if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_reclamar_naoconsegueabastecer']")
                        result_rec_nao_consegue_abastecer = true
                    else 
                        result_rec_nao_consegue_abastecer = false
                end


                if result_rec_acidente_cancela && result_rec_acidente_loja && result_rec_cancela_nao_abriu && result_rec_ausencia_debito && result_rec_tag_nao_recebido &&
                result_rec_mau_atendimento && result_rec_nao_consegue_abastecer && result_rec_tag_sem_cliente && result_rec_credito_nao_recebido && result_rec_financiamento &&
                result_rec_mau_atendimento_embarcador && result_rec_site_service_embarcador == true
                        puts "entrou true reclamar"
                        return true
                    else
                        puts "entrou false reclamar"
                        return false

                end
                

            when "solicitar"

                find(:xpath, "//*[@name='Demandas_1wlw-select_key:{actionForm.primeiroNivelSelecionado}']/option[@value='#{demanda}']").click
        
                #Demandas que deve exibir para o perfil
                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_bloqueioRouboExtravio']")
                        result_sol_bloqueio_extravio = true
                    else 
                        result_sol_bloqueio_extravio = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_bloqueioVeiculoVendido']")
                        result_sol_bloqueio_veiculo_vendido = true
                    else 
                        result_sol_bloqueio_veiculo_vendido = false
                end
                
                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_encerramentoTag']")
                        result_sol_encerramento_tag = true
                    else 
                        result_sol_encerramento_tag = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_gravacaoatendimento']")
                        result_sol_gravacao_atendimento = true
                    else 
                        result_sol_gravacao_atendimento = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_historicoatendimento']")
                        result_sol_historico_atendimento = true
                    else 
                        result_sol_historico_atendimento = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_solicitarTermoDeAdesao']")
                        result_sol_termo_adesao = true
                    else 
                        result_sol_termo_adesao = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_declaracaoQuitacaoDebitos']")
                        result_sol_declaracao_quitacao_debitos = true
                    else 
                        result_sol_declaracao_quitacao_debitos = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_emitirNotaFiscalEletronica']")
                        result_sol_emitir_nota_fiscal = true
                    else 
                        result_sol_emitir_nota_fiscal = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_exclusaoSerasa']")
                        result_sol_exclusao_serasa = true
                    else 
                        result_sol_exclusao_serasa = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_exclusaoProdutosAdicionais']")
                        result_sol_exclusao_produtos_adicionais = true
                    else 
                        result_sol_exclusao_produtos_adicionais = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_inclusaoProdutosAdicionais']")
                        result_sol_inclusao_produtos_adicionais = true
                    else 
                        result_sol_inclusao_produtos_adicionais = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitar_incluirocorrencia']")
                        result_sol_incluir_ocorrencias = true
                    else 
                        result_sol_incluir_ocorrencias = false
                end
            
                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_iniciarPausaPlano']")
                        result_sol_iniciar_pausa_plano = true
                    else 
                        result_sol_iniciar_pausa_plano = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_reembolso_reembolsoPorSaldoCartao']")
                        result_sol_reembolso_saldo_cartao = true
                    else 
                        result_sol_reembolso_saldo_cartao = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_segundaViaDeExtrato']")
                        result_sol_segunda_via_extrato = true
                    else 
                        result_sol_segunda_via_extrato = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_veiculoAtivo']")
                        result_sol_veiculo_ativo = true
                    else 
                        result_sol_veiculo_ativo = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_representanteComercial']")
                        result_sol_representante_comercial = true
                    else 
                        result_sol_representante_comercial = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_registrarSugestao']")
                        result_sol_registrar_sugestao = true
                    else 
                        result_sol_registrar_sugestao = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_inclusaoVeiculo']")
                        result_sol_inclusao_veiculo = true
                    else 
                        result_sol_inclusao_veiculo = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_priorizacao']")
                        result_sol_priorizacao = true
                    else 
                        result_sol_priorizacao = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_contatoTelevendas']")
                        result_sol_contato_televendas = true
                    else 
                        result_sol_contato_televendas = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_reenvioFaturaEmbarcador']")
                        result_sol_reenvio_fatura_embarcador = true
                    else 
                        result_sol_reenvio_fatura_embarcador = false
                end
            
                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_solicitarEsclarecimentoDuvidas']")
                        result_sol_esclarecimento_duvidas = true
                    else 
                        result_sol_esclarecimento_duvidas = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_reembolsoTransferenciaSaldo']")
                        result_sol_reembolso_transferencia_saldo = true
                    else 
                        result_sol_reembolso_transferencia_saldo = false
                end            

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_representanteComercialEmbarcador']")
                        result_sol_representante_comercial_embarcador = true
                    else 
                        result_sol_representante_comercial_embarcador = false
                end  

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitar_incluirpromocao']")
                        result_sol_incluir_promocao = true
                    else 
                        result_sol_incluir_promocao = false
                end

                
                #Demandas que não deve exibir para o perfil
                if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_reembolsoLiberalidade']")
                        result_sol_reembolso_liberalidade = true
                    else 
                        result_sol_reembolso_liberalidade = false
                end

                if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_auxilioLocalizarTransportadorEmbarcador']")
                        result_sol_auxilio_localizador_transportador_vp = true
                    else 
                        result_sol_auxilio_localizador_transportador_vp = false
                end
                
                if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_auxilionavegacaosite']")
                        result_sol_auxilio_navegacao_site = true
                    else 
                        result_sol_auxilio_navegacao_site = false
                end

                if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_integracaosistemica']")
                        result_sol_integracao_sistemica = true
                    else 
                        result_sol_integracao_sistemica = false
                end        

                if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_liberacaocreditohomologacaoembarcador']")
                        result_sol_liberacao_credito_embarcador = true
                    else 
                        result_sol_liberacao_credito_embarcador = false
                end            


                if  result_sol_bloqueio_extravio && result_sol_bloqueio_veiculo_vendido && result_sol_encerramento_tag && result_sol_gravacao_atendimento &&
                    result_sol_historico_atendimento && result_sol_termo_adesao && result_sol_declaracao_quitacao_debitos && result_sol_emitir_nota_fiscal &&
                    result_sol_exclusao_serasa && result_sol_inclusao_produtos_adicionais && result_sol_incluir_ocorrencias && result_sol_contato_televendas &&
                    result_sol_iniciar_pausa_plano && result_sol_reembolso_saldo_cartao && result_sol_segunda_via_extrato && result_sol_veiculo_ativo &&
                    result_sol_representante_comercial && result_sol_registrar_sugestao && result_sol_inclusao_veiculo && result_sol_priorizacao  && 
                    result_sol_reenvio_fatura_embarcador && result_sol_esclarecimento_duvidas && result_sol_reembolso_liberalidade && result_sol_incluir_promocao && 
                    result_sol_auxilio_localizador_transportador_vp && result_sol_auxilio_navegacao_site && result_sol_integracao_sistemica && result_sol_exclusao_produtos_adicionais &&
                    result_sol_liberacao_credito_embarcador && result_sol_reembolso_transferencia_saldo && result_sol_representante_comercial_embarcador == true
                    
                        puts "entrou true solicitar"
                        return true
                    else
                        puts "entrou false solicitar"
                        return false
        
                end
        end



        when "B2B"

            case demanda
            
            when "alterar"
                
                find(:xpath, "//*[@name='Demandas_1wlw-select_key:{actionForm.primeiroNivelSelecionado}']/option[@value='#{demanda}']").click
        
                #Demandas que deve exibir para o perfil
                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_alterar_dadosCadastrais']")
                        result_alt_dados_cadastrais = true
                    else 
                        result_alt_dados_cadastrais = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_alterar_dadosCadastraisVeiculo']")
                        result_alt_dados_veiculos = true
                    else 
                        result_alt_dados_veiculos = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_alterar_alterarDataVencimento']")
                        result_alt_data_vencimento = true
                    else 
                        result_alt_data_vencimento = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_alterar_formaReembolso']")
                        result_alt_forma_reembolso = true
                    else 
                        result_alt_forma_reembolso = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1NIvel_alterar_plano']")
                        result_alt_plano = true
                    else 
                        result_alt_plano = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_alterar_alterarValorPeriodico']")
                        result_alt_valor_periodico = true
                    else 
                        result_alt_valor_periodico = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_alterar_alterarDadosCartaoCredito']")
                        result_alt_cartao_credito = true
                    else 
                        result_alt_cartao_credito = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_alterar_alterarDadosContaCorrente']")
                        result_alt_conta_corrente = true
                    else 
                        result_alt_conta_corrente = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_alterar_formaPagamento']")
                        result_alt_forma_pagamento = true
                    else 
                        result_alt_forma_pagamento = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_alterar_telefonesms']")
                        result_alt_telefone_sms = true
                    else 
                        result_alt_telefone_sms = false
                end
                
                
                #Demandas que não deve exibir para o perfil

                if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_alterar_atualizacaoCadastralAnual']")
                        result_alt_atualizacao_anual = true
                    else 
                        result_alt_atualizacao_anual = false
                end

                #DEV PRECISA CORRIGIR, ESTÁ EXIBINDO MAS NAO DEVERIA EXIBIR
                # if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_alterar_dadosCadastraisEmbarcador']")
                #         result_alt_dados_embarcador = true
                #     else 
                #         result_alt_dados_embarcador = false
                # end

                
            
            
                if result_alt_dados_cadastrais && result_alt_conta_corrente && result_alt_cartao_credito && result_alt_dados_veiculos && result_alt_data_vencimento &&
                result_alt_forma_pagamento && result_alt_forma_reembolso && result_alt_valor_periodico && result_alt_atualizacao_anual && result_alt_telefone_sms == true 
                #result_alt_dados_embarcador  
                        puts "entrou true alterar"    
                        return true
                    else
                        puts "entrou false alterar"  
                        return false
                end 
                

            when "confirmar"
                confirmar_default(demanda)
                

            when "consultar"
                
                find(:xpath, "//*[@name='Demandas_1wlw-select_key:{actionForm.primeiroNivelSelecionado}']/option[@value='#{demanda}']").click

                #Demandas que deve exibir para o perfil
                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_historicoAtendimentos']")
                        result_cons_historico_atendimento = true
                    else 
                        result_cons_historico_atendimento = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_historicoBloqueios']")
                        result_cons_historico_bloqueio = true
                    else 
                        result_cons_historico_bloqueio = false
                end
                
                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_cobrancaExternaJudicial']")
                        result_cons_cobranca_judicial= true
                    else 
                        result_cons_cobranca_judicial = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consultar_credito']")
                        result_cons_credito = true
                    else 
                        result_cons_credito = false
                end
            
                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_dadosCadastrais']")
                        result_cons_dados_cadastrais = true
                    else 
                        result_cons_dados_cadastrais = false
                end
                
                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_dadosDeCobranca']")
                        result_cons_dados_cobranca = true
                    else 
                        result_cons_dados_cobranca = false
                end
            
                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_consultarFatura']")
                        result_cons_faturas = true
                    else 
                        result_cons_faturas = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_historicoAlteracoes']")
                        result_cons_historico_alteracoes = true
                    else 
                        result_cons_historico_alteracoes = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_consultaHistoricoInadimplencia']")
                        result_cons_historico_inadimplencia = true
                    else 
                        result_cons_historico_inadimplencia = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_consultarLancamentoClienteCartao']")
                        result_cons_lancamento_cartao = true
                    else 
                        result_cons_lancamento_cartao = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_procedimento']")
                        result_cons_procedimento = true
                    else 
                        result_cons_procedimento = false
                end
                
                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consultar_produtos_suplementares']")
                        result_cons_produto_suplementar = true
                    else 
                        result_cons_produto_suplementar = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_promocao']")
                        result_cons_promocao = true
                    else 
                        result_cons_promocao = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_consultarReembolsos']")
                        result_cons_reembolso = true
                    else 
                        result_cons_reembolso = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_historicoAnaliseCredito']")
                        result_cons_historico_analise_credito = true
                    else 
                        result_cons_historico_analise_credito = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_situacaoTag']")
                        result_cons_situacao_tag = true
                    else 
                        result_cons_situacao_tag = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_utilizacao']")
                        result_cons_utilizacao = true
                    else 
                        result_cons_utilizacao = false
                end

                
                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_veiculos']")
                        result_cons_veiculos = true
                    else 
                        result_cons_veiculos = false
                end
                
                

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_limite_abastece']")
                        result_cons_limite_abastece = true
                    else 
                        result_cons_limite_abastece = false
                end

                

                # DEV PRECISA CORRIGIR, EXIBE, MAS NAO DEVERIA EXIBIR
                # if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_consultarViagemEmbarcador']")
                #         result_cons_viagem_embarcador = true
                #     else 
                #         result_cons_viagem_embarcador = false
                # end
            
            
                #Demandas que não deve exibir para o perfil

                # DEV PRECISA CORRIGIR, EXIBE, MAS NAO DEVERIA EXIBIR
                # if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_dadosCadastraisEmbarcador']")
                #         result_cons_dados_embarcador = true
                #     else 
                #         result_cons_dados_embarcador = false
                # end

                # DEV PRECISA CORRIGIR, EXIBE, MAS NAO DEVERIA EXIBIR
                # if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_faturaEmbarcador']")
                #         result_cons_fatura_embarcador = true
                #     else 
                #         result_cons_fatura_embarcador = false
                # end
                
                # DEV PRECISA CORRIGIR, EXIBE, MAS NAO DEVERIA EXIBIR
                # if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_consultarExtratoEmbarcador']")
                #         result_cons_extrato_embarcador = true
                #     else 
                #         result_cons_extrato_embarcador = false
                # end

                if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_dispositivosVirtuais']")
                        result_cons_dispositivo_virtual = true
                    else 
                        result_cons_dispositivo_virtual = false
                end








                if  result_cons_historico_atendimento && result_cons_historico_bloqueio && result_cons_cobranca_judicial && result_cons_credito && result_cons_dados_cadastrais &&
                    result_cons_dados_cobranca && result_cons_dispositivo_virtual && result_cons_faturas && result_cons_historico_alteracoes && result_cons_historico_inadimplencia &&
                    result_cons_lancamento_cartao && result_cons_procedimento && result_cons_produto_suplementar && result_cons_promocao && result_cons_reembolso && 
                    result_cons_historico_analise_credito && result_cons_situacao_tag && result_cons_utilizacao && result_cons_veiculos && 
                    result_cons_limite_abastece == true  
                    # && result_cons_extrato_embarcador && result_cons_viagem_embarcador && result_cons_fatura_embarcador && result_cons_dados_embarcador &&
                        puts "entrou true consultar"    
                        return true
                    else
                        puts "entrou false consultar"    
                        return false
                end 
            

            when "contestar"
                
                find(:xpath, "//*[@name='Demandas_1wlw-select_key:{actionForm.primeiroNivelSelecionado}']/option[@value='#{demanda}']").click

                #Demandas que deve exibir para o perfil
                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_contestar_multaEvasao']")
                        result_const_multa_evasao = true
                    else 
                        result_const_multa_evasao = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_contestar_pagamentoIndevido']")
                        result_const_pagamento_indevido = true
                    else 
                        result_const_pagamento_indevido = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_contestar_placa']")
                        result_const_placa = true
                    else 
                        result_const_placa = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_contestar_passagempedagio']")
                        result_const_passagem_pedagio = true
                    else 
                        result_const_passagem_pedagio = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_contestar_taxaExtravio']")
                        result_const_taxa = true
                    else 
                        result_const_taxa = false
                end
                
                #DEV PRECISA CORRIGIR, EXIBE MAS NAO DEVERIA EXIBIR
                # if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_contestar_credito_indisponivel_embarcador']")
                #         result_const_credito_indisponivel_embarcador = true
                #     else 
                #         result_const_credito_indisponivel_embarcador = false
                # end
                
                #DEV PRECISA CORRIGIR, EXIBE MAS NAO DEVERIA EXIBIR
                # if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_contestar_multaValePedagioEmbarcador']")
                #         result_const_multa_vale_pedagio_embarcador = true
                #     else 
                #         result_const_multa_vale_pedagio_embarcador = false
                # end

                #DEV PRECISA CORRIGIR, EXIBE MAS NAO DEVERIA EXIBIR
                # if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_contestar_viagemtransportadorvp']")
                #         result_const_viagem_transportador_vp = true
                #     else 
                #         result_const_viagem_transportador_vp = false
                # end
            
                if  result_const_multa_evasao && result_const_pagamento_indevido && result_const_placa && result_const_passagem_pedagio && result_const_taxa == true
                     #result_const_credito_indisponivel_embarcador && result_const_multa_vale_pedagio_embarcador && result_const_viagem_transportador_vp
                    puts "entrou true contestar"        
                        return true
                    else
                        puts "entrou false contestar"
                        return false
                end 


            when "localizar"
                localizar_default(demanda)
                

            when "reclamar"
                
                find(:xpath, "//*[@name='Demandas_1wlw-select_key:{actionForm.primeiroNivelSelecionado}']/option[@value='#{demanda}']").click
        
                #Demandas que deve exibir para o perfil
                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_reclamar_acidenteComCancela']")
                        result_rec_acidente_cancela = true
                    else 
                        result_rec_acidente_cancela = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_reclamar_acidenteloja']")
                        result_rec_acidente_loja = true
                    else 
                        result_rec_acidente_loja = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_reclamar_cancelanaoabriu']")
                        result_rec_cancela_nao_abriu = true
                    else 
                        result_rec_cancela_nao_abriu = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_reclamar_ausenciaDebito']")
                        result_rec_ausencia_debito = true
                    else 
                        result_rec_ausencia_debito = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_reclamar_tagNaoRecebido']")
                        result_rec_tag_nao_recebido = true
                    else 
                        result_rec_tag_nao_recebido = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_reclamar_mauatendimento']")
                        result_rec_mau_atendimento = true
                    else 
                        result_rec_mau_atendimento = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_reclamar_tagSemCliente']")
                        result_rec_tag_sem_cliente = true
                    else 
                        result_rec_tag_sem_cliente = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_reclamar_creditoNaoRecebido']")
                        result_rec_credito_nao_recebido = true
                    else 
                        result_rec_credito_nao_recebido = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_reclamar_financiamento']")
                        result_rec_financiamento = true
                    else 
                        result_rec_financiamento = false
                end

                #Demandas que não deve exibir para o perfil

                #DEV PRECISA CORRIGIR, EXIBE MAS NAO DEVERIA EXIBIR
                # if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_reclamar_mauatendimentoEmbarcador']")
                #         result_rec_mau_atendimento_embarcador = true
                #     else 
                #         result_rec_mau_atendimento_embarcador = false
                # end

                #DEV PRECISA CORRIGIR, EXIBE MAS NAO DEVERIA EXIBIR
                # if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_reclamar_siteWebServiceEmbarcador']")
                #         result_rec_site_service_embarcador = true
                #     else 
                #         result_rec_site_service_embarcador = false
                # end

                if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_reclamar_naoconsegueabastecer']")
                        result_rec_nao_consegue_abastecer = true
                    else 
                        result_rec_nao_consegue_abastecer = false
                end


                if result_rec_acidente_cancela && result_rec_acidente_loja && result_rec_cancela_nao_abriu && result_rec_ausencia_debito && result_rec_tag_nao_recebido &&
                result_rec_mau_atendimento && result_rec_nao_consegue_abastecer && result_rec_tag_sem_cliente && result_rec_credito_nao_recebido && 
                result_rec_financiamento == true
                #result_rec_mau_atendimento_embarcador && result_rec_site_service_embarcador 
                        puts "entrou true reclamar"
                        return true
                    else
                        puts "entrou false reclamar"
                        return false

                end
                

            when "solicitar"

                find(:xpath, "//*[@name='Demandas_1wlw-select_key:{actionForm.primeiroNivelSelecionado}']/option[@value='#{demanda}']").click
        
                #Demandas que deve exibir para o perfil
                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_bloqueioRouboExtravio']")
                        result_sol_bloqueio_extravio = true
                    else 
                        result_sol_bloqueio_extravio = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_bloqueioVeiculoVendido']")
                        result_sol_bloqueio_veiculo_vendido = true
                    else 
                        result_sol_bloqueio_veiculo_vendido = false
                end
                
                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_encerramentoTag']")
                        result_sol_encerramento_tag = true
                    else 
                        result_sol_encerramento_tag = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_gravacaoatendimento']")
                        result_sol_gravacao_atendimento = true
                    else 
                        result_sol_gravacao_atendimento = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_historicoatendimento']")
                        result_sol_historico_atendimento = true
                    else 
                        result_sol_historico_atendimento = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_solicitarTermoDeAdesao']")
                        result_sol_termo_adesao = true
                    else 
                        result_sol_termo_adesao = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_declaracaoQuitacaoDebitos']")
                        result_sol_declaracao_quitacao_debitos = true
                    else 
                        result_sol_declaracao_quitacao_debitos = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_emitirNotaFiscalEletronica']")
                        result_sol_emitir_nota_fiscal = true
                    else 
                        result_sol_emitir_nota_fiscal = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_exclusaoSerasa']")
                        result_sol_exclusao_serasa = true
                    else 
                        result_sol_exclusao_serasa = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_exclusaoProdutosAdicionais']")
                        result_sol_exclusao_produtos_adicionais = true
                    else 
                        result_sol_exclusao_produtos_adicionais = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_inclusaoProdutosAdicionais']")
                        result_sol_inclusao_produtos_adicionais = true
                    else 
                        result_sol_inclusao_produtos_adicionais = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitar_incluirocorrencia']")
                        result_sol_incluir_ocorrencias = true
                    else 
                        result_sol_incluir_ocorrencias = false
                end
            
                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_iniciarPausaPlano']")
                        result_sol_iniciar_pausa_plano = true
                    else 
                        result_sol_iniciar_pausa_plano = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_reembolso_reembolsoPorSaldoCartao']")
                        result_sol_reembolso_saldo_cartao = true
                    else 
                        result_sol_reembolso_saldo_cartao = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_segundaViaDeExtrato']")
                        result_sol_segunda_via_extrato = true
                    else 
                        result_sol_segunda_via_extrato = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_veiculoAtivo']")
                        result_sol_veiculo_ativo = true
                    else 
                        result_sol_veiculo_ativo = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_representanteComercial']")
                        result_sol_representante_comercial = true
                    else 
                        result_sol_representante_comercial = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_registrarSugestao']")
                        result_sol_registrar_sugestao = true
                    else 
                        result_sol_registrar_sugestao = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_inclusaoVeiculo']")
                        result_sol_inclusao_veiculo = true
                    else 
                        result_sol_inclusao_veiculo = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_priorizacao']")
                        result_sol_priorizacao = true
                    else 
                        result_sol_priorizacao = false
                end

                if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_reembolsoLiberalidade']")
                        result_sol_reembolso_liberalidade = true
                    else 
                        result_sol_reembolso_liberalidade = false
                end

                
                #Demandas que não deve exibir para o perfil
                if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitar_incluirpromocao']")
                        result_sol_incluir_promocao = true
                    else 
                        result_sol_incluir_promocao = false
                end

                #DEV PRECISA CORRIGIR, EXIBE MAS NAO DEVERIA EXIBIR
                # if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_reembolsoTransferenciaSaldo']")
                #         result_sol_reembolso_transferencia_saldo = true
                #     else 
                #         result_sol_reembolso_transferencia_saldo = false
                # end            

                #DEV PRECISA CORRIGIR, EXIBE MAS NAO DEVERIA EXIBIR
                # if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_representanteComercialEmbarcador']")
                #         result_sol_representante_comercial_embarcador = true
                #     else 
                #         result_sol_representante_comercial_embarcador = false
                # end  

                #DEV PRECISA CORRIGIR, EXIBE MAS NAO DEVERIA EXIBIR
                # if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_auxilioLocalizarTransportadorEmbarcador']")
                #         result_sol_auxilio_localizador_transportador_vp = true
                #     else 
                #         result_sol_auxilio_localizador_transportador_vp = false
                # end
                
                #DEV PRECISA CORRIGIR, EXIBE MAS NAO DEVERIA EXIBIR
                # if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_auxilionavegacaosite']")
                #         result_sol_auxilio_navegacao_site = true
                #     else 
                #         result_sol_auxilio_navegacao_site = false
                # end

                #DEV PRECISA CORRIGIR, EXIBE MAS NAO DEVERIA EXIBIR
                # if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_integracaosistemica']")
                #         result_sol_integracao_sistemica = true
                #     else 
                #         result_sol_integracao_sistemica = false
                # end        

                #DEV PRECISA CORRIGIR, EXIBE MAS NAO DEVERIA EXIBIR
                # if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_liberacaocreditohomologacaoembarcador']")
                #         result_sol_liberacao_credito_embarcador = true
                #     else 
                #         result_sol_liberacao_credito_embarcador = false
                # end      
                
                #DEV PRECISA CORRIGIR, EXIBE MAS NAO DEVERIA EXIBIR
                # if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_contatoTelevendas']")
                #         result_sol_contato_televendas = true
                #     else 
                #         result_sol_contato_televendas = false
                # end

                #DEV PRECISA CORRIGIR, EXIBE MAS NAO DEVERIA EXIBIR
                # if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_reenvioFaturaEmbarcador']")
                #         result_sol_reenvio_fatura_embarcador = true
                #     else 
                #         result_sol_reenvio_fatura_embarcador = false
                # end
            
                #DEV PRECISA CORRIGIR, EXIBE MAS NAO DEVERIA EXIBIR
                # if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_solicitacao_solicitarEsclarecimentoDuvidas']")
                #         result_sol_esclarecimento_duvidas = true
                #     else 
                #         result_sol_esclarecimento_duvidas = false
                # end



                if  result_sol_bloqueio_extravio && result_sol_bloqueio_veiculo_vendido && result_sol_encerramento_tag && result_sol_gravacao_atendimento &&
                    result_sol_historico_atendimento && result_sol_termo_adesao && result_sol_declaracao_quitacao_debitos && result_sol_emitir_nota_fiscal &&
                    result_sol_exclusao_serasa && result_sol_inclusao_produtos_adicionais && result_sol_incluir_ocorrencias &&
                    result_sol_iniciar_pausa_plano && result_sol_reembolso_saldo_cartao && result_sol_segunda_via_extrato && result_sol_veiculo_ativo &&
                    result_sol_representante_comercial && result_sol_registrar_sugestao && result_sol_inclusao_veiculo && result_sol_priorizacao  && 
                    result_sol_reembolso_liberalidade && result_sol_incluir_promocao && result_sol_exclusao_produtos_adicionais == true
                    # result_sol_esclarecimento_duvidas && result_sol_liberacao_credito_embarcador && result_sol_reembolso_transferencia_saldo && result_sol_representante_comercial_embarcador 
                    # result_sol_auxilio_localizador_transportador_vp && result_sol_auxilio_navegacao_site && result_sol_integracao_sistemica && result_sol_contato_televendas &&
                    #result_sol_reenvio_fatura_embarcador &&
                        
                        puts "entrou true solicitar"
                        return true
                    else
                        puts "entrou false solicitar"
                        return false
        
                end
        end





        end 
    end




    def finalizo_atendimento
        button_logout.click
    end

    def seleciona_avancar
        button_avancar.click
    end

    def acessa_demandas_menu_inicial_retencao

        #acessar a demanda alterar forma de pagamento
        button_alterar_forma_pagamento.click
        find(:xpath, "//img[contains(@src, 'title-alterar-forma-pagamento.gif')]")
        button_cancelar.click
        button_home.click


        #acessar a demanda alterar forma de pagamento
        button_alterar_incluir_promocao.click
        find(:xpath, "//img[contains(@src, 'title_solicitar_incluir_promocao.gif')]")
        button_cancelar.click
        button_home.click


        #acessar a demanda alterar forma de pagamento
        button_alterar_plano.click
        find(:xpath, "//img[contains(@src, 'title-alterar-plano.gif')]")
        button_cancelar.click
        button_home.click


        #acessar a demanda alterar forma de pagamento
        button_bloqueio_vendido.click
        find(:xpath, "//img[contains(@src, 'title-bloqueio-tag.gif')]")
        button_cancelar.click
        button_home.click


        #acessar a demanda alterar forma de pagamento
        button_cancelamento.click
        find(:xpath, "//img[contains(@src, 'title-solicitar-encerrar-tag.jpg')]")
        button_cancelar.click
        button_home.click


        #acessar a demanda alterar forma de pagamento
        button_consultar_faturas.click
        find(:xpath, "//img[contains(@src, 'title-pesquisa-fatura.gif')]")
        button_cancelar.click
        button_home.click



        
    end




    def primeiro_nivel_default 

        find(:xpath, "//select[@id='selectPrimeiroNivel']").click

            if page.has_selector?(:xpath, "//select[@id='selectPrimeiroNivel']/option[@value='alterar']")
                    result_alterar = true
                else 
                    result_alterar = false
            end

            if page.has_selector?(:xpath, "//select[@id='selectPrimeiroNivel']/option[@value='confirmar']")
                    result_confirmar = true
                else
                    result_confirmar = false
            end

                
            if page.has_selector?(:xpath, "//select[@id='selectPrimeiroNivel']/option[@value='consultar']")
                    result_consultar = true
                else
                    result_consultar = false
            end


            if page.has_selector?(:xpath, "//select[@id='selectPrimeiroNivel']/option[@value='contestar']")
                    result_contestar = true
                else 
                    result_contestar = false
            end

            if page.has_selector?(:xpath, "//select[@id='selectPrimeiroNivel']/option[@value='localizar']")
                    result_localizar = true
                else 
                    result_localizar = false
            end

            if page.has_selector?(:xpath, "//select[@id='selectPrimeiroNivel']/option[@value='reclamar']")
                    result_reclamar = true
                else
                    result_reclamar = false
            end

            if page.has_selector?(:xpath, "//select[@id='selectPrimeiroNivel']/option[@value='solicitar']")
                    result_solicitar = true
                else 
                    result_solicitar = false
            end


            if result_alterar && result_confirmar && result_consultar && result_contestar && result_localizar && result_reclamar && result_solicitar  == true
                    return true
                else
                    return false
            end 
        
    end

    def alterar_default(demanda)
       
        find(:xpath, "//*[@name='Demandas_1wlw-select_key:{actionForm.primeiroNivelSelecionado}']/option[@value='#{demanda}']").click
        
        #Demandas que deve exibir para o perfil
        if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_alterar_alterarDadosCartaoCredito']")
                result_alt_cartao_credito = true
            else 
                result_alt_cartao_credito = false
        end

        if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_alterar_alterarDadosContaCorrente']")
                result_alt_conta_corrente = true
            else 
                result_alt_conta_corrente = false
        end
        
        if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_alterar_dadosCadastrais']")
                result_alt_dados_cadastrais = true
            else 
                result_alt_dados_cadastrais = false
        end

        if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_alterar_dadosCadastraisVeiculo']")
                result_alt_dados_veiculos = true
            else 
                result_alt_dados_veiculos = false
        end

        if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_alterar_alterarDataVencimento']")
                result_alt_data_vencimento = true
            else 
                result_alt_data_vencimento = false
        end

        if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_alterar_formaPagamento']")
                result_alt_forma_pagamento = true
            else 
                result_alt_forma_pagamento = false
        end

        if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_alterar_formaReembolso']")
                result_alt_forma_reembolso = true
            else 
                result_alt_forma_reembolso = false
        end

        if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1NIvel_alterar_plano']")
                result_alt_plano = true
            else 
                result_alt_plano = false
        end

        if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_alterar_alterarValorPeriodico']")
                result_alt_valor_periodico = true
            else 
                result_alt_valor_periodico = false
        end

        if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_alterar_atualizacaoCadastralAnual']")
                result_alt_atualizacao_anual = true
            else 
                result_alt_atualizacao_anual = false
        end

        #DEV PRECISA CORRIGIR
        # if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_alterar_telefonesms']")
        #         result_alt_telefone_sms = true
        #     else 
        #         result_alt_telefone_sms = false
        # end
        
        
        #Demandas que não deve exibir para o perfil
        if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_alterar_dadosCadastraisEmbarcador']")
                result_alt_dados_embarcador = true
            else 
                result_alt_dados_embarcador = false
        end
    
    
        if result_alt_dados_cadastrais && result_alt_conta_corrente && result_alt_cartao_credito && result_alt_dados_veiculos && result_alt_data_vencimento &&
            result_alt_forma_pagamento && result_alt_forma_reembolso && result_alt_valor_periodico && result_alt_atualizacao_anual && result_alt_dados_embarcador == true 
                #&& result_alt_telefone_sms
                puts "entrou true alterar"    
                return true
            else
                puts "entrou false alterar"  
                return false
        end 

    
    end

    def confirmar_default(demanda)
        find(:xpath, "//*[@name='Demandas_1wlw-select_key:{actionForm.primeiroNivelSelecionado}']/option[@value='#{demanda}']").click
        
        #Demandas que deve exibir para o perfil
        if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_confirmar_recebimentoDocumentos']")
                puts "entrou true confirmar"        
                return true
            else 
                puts "entrou false confirmar" 
                return false
        end
    end

    def consultar_default(demanda)
        
        find(:xpath, "//*[@name='Demandas_1wlw-select_key:{actionForm.primeiroNivelSelecionado}']/option[@value='#{demanda}']").click

        #Demandas que deve exibir para o perfil
        if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_historicoAtendimentos']")
                result_cons_historico_atendimento = true
            else 
                result_cons_historico_atendimento = false
        end

        if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_historicoBloqueios']")
                result_cons_historico_bloqueio = true
            else 
                result_cons_historico_bloqueio = false
        end
        
        if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_cobrancaExternaJudicial']")
                result_cons_cobranca_judicial= true
            else 
                result_cons_cobranca_judicial = false
        end

        if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consultar_credito']")
                result_cons_credito = true
            else 
                result_cons_credito = false
        end
    
        if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_dadosCadastrais']")
                result_cons_dados_cadastrais = true
            else 
                result_cons_dados_cadastrais = false
        end
        
        if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_dadosDeCobranca']")
                result_cons_dados_cobranca = true
            else 
                result_cons_dados_cobranca = false
        end
    
        if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_dispositivosVirtuais']")
                result_cons_dispositivo_virtual = true
            else 
                result_cons_dispositivo_virtual = false
        end

        if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_consultarFatura']")
                result_cons_faturas = true
            else 
                result_cons_faturas = false
        end

        if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_historicoAlteracoes']")
                result_cons_historico_alteracoes = true
            else 
                result_cons_historico_alteracoes = false
        end

        if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_consultaHistoricoInadimplencia']")
                result_cons_historico_inadimplencia = true
            else 
                result_cons_historico_inadimplencia = false
        end

        if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_consultarLancamentoClienteCartao']")
                result_cons_lancamento_cartao = true
            else 
                result_cons_lancamento_cartao = false
        end

        if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_procedimento']")
                result_cons_procedimento = true
            else 
                result_cons_procedimento = false
        end
        
        if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consultar_produtos_suplementares']")
                result_cons_produto_suplementar = true
            else 
                result_cons_produto_suplementar = false
        end

        if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_promocao']")
                result_cons_promocao = true
            else 
                result_cons_promocao = false
        end

        if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_consultarReembolsos']")
                result_cons_reembolso = true
            else 
                result_cons_reembolso = false
        end

        if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_historicoAnaliseCredito']")
                result_cons_historico_analise_credito = true
            else 
                result_cons_historico_analise_credito = false
        end

        if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_situacaoTag']")
                result_cons_situacao_tag = true
            else 
                result_cons_situacao_tag = false
        end

        if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_utilizacao']")
                result_cons_utilizacao = true
            else 
                result_cons_utilizacao = false
        end

        
        if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_veiculos']")
                result_cons_veiculos = true
            else 
                result_cons_veiculos = false
        end
        
        if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_consultarViagemEmbarcador']")
                result_cons_viagem_embarcador = true
            else 
                result_cons_viagem_embarcador = false
        end

                
        #DEV PRECISA CORRIGIR
        # if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_limite_abastece']")
        #         result_cons_limite_abastece = true
        #     else 
        #         result_cons_limite_abastece = false
        # end
    
    
        #Demandas que não deve exibir para o perfil
        if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_dadosCadastraisEmbarcador']")
                result_cons_dados_embarcador = true
            else 
                result_cons_dados_embarcador = false
        end

        if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_consultarExtratoEmbarcador']")
                result_cons_extrato_embarcador = true
            else 
                result_cons_extrato_embarcador = false
        end

        if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_consulta_faturaEmbarcador']")
                result_cons_fatura_embarcador = true
            else 
                result_cons_fatura_embarcador = false
        end

        if  result_cons_historico_atendimento && result_cons_historico_bloqueio && result_cons_cobranca_judicial && result_cons_credito && result_cons_dados_cadastrais &&
            result_cons_dados_cobranca && result_cons_dispositivo_virtual && result_cons_faturas && result_cons_historico_alteracoes && result_cons_historico_inadimplencia &&
            result_cons_lancamento_cartao && result_cons_procedimento && result_cons_produto_suplementar && result_cons_promocao && result_cons_reembolso && 
            result_cons_historico_analise_credito && result_cons_situacao_tag && result_cons_utilizacao && result_cons_veiculos && result_cons_viagem_embarcador &&
            result_cons_dados_embarcador && result_cons_extrato_embarcador && result_cons_fatura_embarcador == true  #&& result_cons_limite_abastece
                puts "entrou true consultar"    
                return true
            else
                puts "entrou false consultar"    
                return false
        end 
                            

    end

    def contestar_default(demanda)
        
        find(:xpath, "//*[@name='Demandas_1wlw-select_key:{actionForm.primeiroNivelSelecionado}']/option[@value='#{demanda}']").click

        #Demandas que deve exibir para o perfil
        if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_contestar_multaEvasao']")
                result_const_multa_evasao = true
            else 
                result_const_multa_evasao = false
        end

        if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_contestar_pagamentoIndevido']")
                result_const_pagamento_indevido = true
            else 
                result_const_pagamento_indevido = false
        end

        if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_contestar_placa']")
                result_const_placa = true
            else 
                result_const_placa = false
        end

        if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_contestar_passagempedagio']")
                result_const_passagem_pedagio = true
            else 
                result_const_passagem_pedagio = false
        end

        if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_contestar_taxaExtravio']")
                result_const_taxa = true
            else 
                result_const_taxa = false
        end

        
        #Demandas que não deve exibir para o perfil
        if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_contestar_credito_indisponivel_embarcador']")
                result_const_credito_indisponivel_embarcador = true
            else 
                result_const_credito_indisponivel_embarcador = false
        end

        if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_contestar_multaValePedagioEmbarcador']")
                result_const_multa_vale_pedagio_embarcador = true
            else 
                result_const_multa_vale_pedagio_embarcador = false
        end

        if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_contestar_viagemtransportadorvp']")
                result_const_viagem_transportador_vp = true
            else 
                result_const_viagem_transportador_vp = false
        end
    
        if  result_const_multa_evasao && result_const_pagamento_indevido && result_const_placa && result_const_passagem_pedagio && result_const_taxa &&
            result_const_credito_indisponivel_embarcador && result_const_multa_vale_pedagio_embarcador && result_const_viagem_transportador_vp == true
            puts "entrou true contestar"        
                return true
            else
                puts "entrou false contestar"
                return false
        end 
    
    end

    def localizar_default(demanda)
        
        find(:xpath, "//*[@name='Demandas_1wlw-select_key:{actionForm.primeiroNivelSelecionado}']/option[@value='#{demanda}']").click

        #Demandas que deve exibir para o perfil
        if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_localizar_baixapagamento']")
                result_loc_baixa_pagamento = true
            else 
                result_loc_baixa_pagamento = false
        end
        
        if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_localizar_tagdevolvido']")
                result_const_tag_devolvido = true
            else 
                result_const_tag_devolvido = false
        end
        
        if result_loc_baixa_pagamento && result_const_tag_devolvido == true
                puts "entrou true localizar"    
                return true
            else
                puts "entrou false localizar" 
                return false
        end



    end


    def reclamar_default(demanda)
        
        find(:xpath, "//*[@name='Demandas_1wlw-select_key:{actionForm.primeiroNivelSelecionado}']/option[@value='#{demanda}']").click
        
        #Demandas que deve exibir para o perfil
        if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_reclamar_acidenteComCancela']")
                result_rec_acidente_cancela = true
            else 
                result_rec_acidente_cancela = false
        end

        if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_reclamar_acidenteloja']")
                result_rec_acidente_loja = true
            else 
                result_rec_acidente_loja = false
        end

        if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_reclamar_cancelanaoabriu']")
                result_rec_cancela_nao_abriu = true
            else 
                result_rec_cancela_nao_abriu = false
        end

        if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_reclamar_ausenciaDebito']")
                result_rec_ausencia_debito = true
            else 
                result_rec_ausencia_debito = false
        end

        if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_reclamar_tagNaoRecebido']")
                result_rec_tag_nao_recebido = true
            else 
                result_rec_tag_nao_recebido = false
        end

        if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_reclamar_mauatendimento']")
                result_rec_mau_atendimento = true
            else 
                result_rec_mau_atendimento = false
        end

        if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_reclamar_naoconsegueabastecer']")
                result_rec_nao_consegue_abastecer = true
            else 
                result_rec_nao_consegue_abastecer = false
        end
        
        if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_reclamar_tagSemCliente']")
                result_rec_tag_sem_cliente = true
            else 
                result_rec_tag_sem_cliente = false
        end

        if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_reclamar_creditoNaoRecebido']")
                result_rec_credito_nao_recebido = true
            else 
                result_rec_credito_nao_recebido = false
        end

        if page.has_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_reclamar_financiamento']")
                result_rec_financiamento = true
            else 
                result_rec_financiamento = false
        end

        #Demandas que não deve exibir para o perfil
        if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_reclamar_mauatendimentoEmbarcador']")
                result_rec_mau_atendimento_embarcador = true
            else 
                result_rec_mau_atendimento_embarcador = false
        end

        if page.has_no_selector?(:xpath, "//select[@id='selectSegundoNivel']/option[@value='callcenter_portal_home_execucaoDemandas_bookEsquerdo_miolo_demanda1Nivel_reclamar_siteWebServiceEmbarcador']")
                result_rec_site_service_embarcador = true
            else 
                result_rec_site_service_embarcador = false
        end


        if result_rec_acidente_cancela && result_rec_acidente_loja && result_rec_cancela_nao_abriu && result_rec_ausencia_debito && result_rec_tag_nao_recebido &&
           result_rec_mau_atendimento && result_rec_nao_consegue_abastecer && result_rec_tag_sem_cliente && result_rec_credito_nao_recebido && result_rec_financiamento &&
           result_rec_mau_atendimento_embarcador && result_rec_site_service_embarcador == true
                puts "entrou true reclamar"
                return true
            else
                puts "entrou false reclamar"
                return false

        end

    end




end
