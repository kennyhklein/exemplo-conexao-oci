require_relative './acessar_sistema/login_call_center_pages'
require_relative './acessar_sistema/acessar_call_center_pages'
require_relative './buscar_cliente/buscar_cliente_pages'
require_relative './selecionar_demanda/selecionar_demanda_pages'
require_relative './contestar/contestar_transacoes_pages'
require_relative './consultar/consultar_atendimento_pages'
require_relative './contestar/contestar_taxas_pages'
require_relative './alterar/alterar_plano_pages'
require_relative './alterar/alterar_cartao_credito_pages'
require_relative './alterar/alterar_conta_corrente_pages'
require_relative './alterar/alterar_dia_vencimento_pages'
require_relative './alterar/alterar_valor_periodico_pages'
require_relative './alterar/alterar_forma_pagamento_pages'
require_relative './solicitar/solicitar_encerramento_semparar_pages'
require_relative './solicitar/solicitar_bloqueio_veiculo_vendido_pages'

class CallCenter < SitePrism::Page

  set_url URL["url_uat"] 
  #set_url URL["url_pprd"]   


   section :login, Login, "#Netui_Form_0"

  #Menu superior com o Busca Cliente, Escolha a Conta, Escolha a Demanda e Iniciar/Finalizar Atendimento
  section :menu_atendimento, AtendimentoCallCenter, "#buscaClienteForm"
  section :menu_cliente, BuscarCliente, "#buscaClienteForm"
  section :menu_demanda, SelecionarDemanda, "#buscaClienteForm"

  #Telas contendo as demandas e Cérebro Virtual
  section :demanda_atendimento, AtendimentoCallCenter, "#geral"
  section :demanda_cliente, BuscarCliente, "#geral"
  section :demanda, SelecionarDemanda, "#geral"
  section :perfil_atendimento, PerfilAtendimento, "#geral"

  #Telas para cada Funcionalidade
  section :consultar_fatura, ConsultarFatura, "#geral"
  section :consultar_detalhe_item_fatura, ConsultarDetalheItemFatura, "#geral"
  section :contestar_transacoes, ContestarTransacoes, "#geral"
  section :consultar_atendimento, ConsultarAtendimento, "#geral"
  section :contestar_taxas, ContestarTaxas, "#geral"
  section :alterar_plano, AlterarPlano, "#geral"
  section :alterar_cartao_credito, AlterarCartaoCredito, "#geral"
  section :alterar_conta_corrente, AlterarContaCorrente, "#geral"
  section :alterar_dia_vencimento, AlterarDiaVencimento, "#geral"
  section :alterar_valor_periodico, AlterarValorPeriodico, "#geral"
  section :alterar_forma_pagamento, AlterarFormaPagamento, "#geral"
  section :solicitar_bloqueio_veiculo_vendido, SolicitarBloqueioVeiculoVendido, "#geral"
  section :solicitar_encerramento_semparar, SolicitarEncerramentoSemParar, "#geral"


end

