require 'ruby-oci8'

class BancoDeDados

    def conectar_banco_dados

                ##HOMOLOGACAO
                @connection = OCI8.new('julia_yaman', 'NovaSenha4321', "//ORADB_CGMP6A3/CGMP6A3")

                ##PRE PROD
                #@connection = OCI8.new('kenny_verotthi', 'KverENtthiNy20#', "//ORADB_CGMP6A4/CGMP6A4")
       
    end 



    def buscar_cliente_valido
        conectar_banco_dados
        cursor = @connection.exec("
            SELECT 
            (SELECT CC.NRC FROM SUP_SCH.CST_CUSTOMER_COMPANY CC WHERE C.ID = CC.FK_CUST_ID) AS NRC, v.plate as placa, 
            (select api.name from CNT_ACCESS_POINT_IDENTIFICATOR api where vi.fk_cntid_id = API.ID) as dispositivo
            FROM 
            SUP_SCH.CST_CUSTOMER C, SUP_SCH.CNT_CONTRACT N, SUP_SCH.CAT_PRODUCT P, SUP_SCH.CNT_CONTRACTED_PRODUCT CP,
            VCL_VEHICLE v, VCL_VEHICLE_ACCESS_POINT vap, VCL_VEHICLE_ACCESS_POINT_IDENT vi,
            SUP_SCH.ACC_PAYMENT_MODE MO, SUP_SCH.ACC_ACCOUNT A
            WHERE 1=1
            AND V.FK_CUST_ID = A.FK_CUST_ID
            AND A.ID = MO.FK_ACCNT_ID
            AND A.FK_CUST_ID = C.ID
            AND vi.FK_VCLAP_ID = vap.ID
            AND vap.FK_VCLVC_ID = v.id
                  AND C.ID = v.FK_CUST_ID
                  AND vi.FINAL_DATE is null
                  AND N.FK_CUST_ID = C.ID
                  AND N.ID = CP.FK_SVCTR_ID 
                  AND CP.FK_PRDCT_ID = P.ID
                  AND A.REAL_BALANCE < 0
                 AND EXISTS (select CC.FK_CUST_ID, count(1) from 
                          VCL_VEHICLE v, VCL_VEHICLE_ACCESS_POINT vap, VCL_VEHICLE_ACCESS_POINT_IDENT vi, CST_CUSTOMER_COMPANY cc
                          where vi.FK_VCLAP_ID = vap.ID
                          and vap.FK_VCLVC_ID = v.id
                          and vi.FINAL_DATE is null
                          and CC.FK_CUST_ID = v.FK_CUST_ID
                          and CC.FK_CUST_ID = C.ID
                          group by cc.FK_CUST_ID
                          having count(1) > 1)   
                            AND not exists(select 1 from CNT_CONTRACTED_PROD_STATUS_HIS CTSTH
                            where CTSTH.FK_CTPRD_ID = CP.ID 
                             AND CP.FK_PRDCT_ID = P.ID
                            AND N.ID = CP.FK_SVCTR_ID
                            AND N.FK_CUST_ID = C.ID
                            AND CTSTH.FK_CNTST_ID in (2,3) AND CTSTH.VALIDITY_END_DATE IS NULL)
                  AND ROWNUM < 2
            ")
        while response = (cursor.fetch())
            @retorno = response.join('|')
            return response
        end

        cursor.close
        @connection.logoff 
    end


###### BUSCAR CLIENTE TIPO CARTAO DE CREDITO ######
        def buscar_cliente_cartao_visa
            conectar_banco_dados
            cursor = @connection.exec("
            SELECT 
                (SELECT CC.NRC FROM SUP_SCH.CST_CUSTOMER_COMPANY CC WHERE C.ID = CC.FK_CUST_ID) AS NRC
            FROM 
                SUP_SCH.CST_CUSTOMER C, SUP_SCH.CNT_CONTRACT N, SUP_SCH.CAT_PRODUCT P, SUP_SCH.CNT_CONTRACTED_PRODUCT CP,
                SUP_SCH.ACC_PAYMENT_MODE MO, SUP_SCH.ACC_ACCOUNT A
            WHERE 1=1
                AND A.ID = MO.FK_ACCNT_ID
                AND A.FK_CUST_ID = C.ID
                AND N.FK_CUST_ID = C.ID
                AND N.ID = CP.FK_SVCTR_ID
                AND CP.FK_PRDCT_ID = P.ID
                AND P.ID = '100192017'	--SEM PARAR AUTOMÁTICO - CARTÃO
                AND MO.CREDIT_CARD_ISSUER = 'VISA'
                AND MO.credit_card_number <> '7MX6hB7ItQVumVLFufT4JE5eTY/qqUU01q70AkuKkt0='
                AND exists(select 1 from CNT_CONTRACTED_PROD_STATUS_HIS CTSTH, CNT_CONTRACTED_PRODUCT CP, SUP_SCH.CNT_CONTRACT N
                    where CTSTH.FK_CTPRD_ID = CP.ID 
                    AND N.ID = CP.FK_SVCTR_ID
                    AND N.FK_CUST_ID = C.ID
                    AND CP.FK_PRDCT_ID = '100001' 
                    AND CTSTH.FK_CNTST_ID = 1
                    AND CTSTH.VALIDITY_END_DATE IS NULL)
                AND ROWNUM < 2
                ")
            while response = (cursor.fetch())
                return response
            end

            cursor.close
            @connection.logoff 
        end

        def buscar_cliente_cartao_mastercard
            conectar_banco_dados
            cursor = @connection.exec("
            SELECT 
                (SELECT CC.NRC FROM SUP_SCH.CST_CUSTOMER_COMPANY CC WHERE C.ID = CC.FK_CUST_ID) AS NRC
            FROM 
                SUP_SCH.CST_CUSTOMER C, SUP_SCH.CNT_CONTRACT N, SUP_SCH.CAT_PRODUCT P, SUP_SCH.CNT_CONTRACTED_PRODUCT CP,
                SUP_SCH.ACC_PAYMENT_MODE MO, SUP_SCH.ACC_ACCOUNT A
            WHERE 1=1
                AND A.ID = MO.FK_ACCNT_ID
                AND A.FK_CUST_ID = C.ID
                AND N.FK_CUST_ID = C.ID
                AND N.ID = CP.FK_SVCTR_ID
                AND CP.FK_PRDCT_ID = P.ID
                AND P.ID = '100192017'	--SEM PARAR AUTOMÁTICO - CARTÃO
                AND MO.CREDIT_CARD_ISSUER = 'MASTERCARD'
                AND mo.credit_card_number <> 'uIzmNbzNGx8BGMVKLvFjP05eTY/qqUU01q70AkuKkt0='
                AND exists(select 1 from CNT_CONTRACTED_PROD_STATUS_HIS CTSTH, CNT_CONTRACTED_PRODUCT CP, SUP_SCH.CNT_CONTRACT N
                    where CTSTH.FK_CTPRD_ID = CP.ID 
                    AND N.ID = CP.FK_SVCTR_ID
                    AND N.FK_CUST_ID = C.ID
                    AND CP.FK_PRDCT_ID = '100001' 
                    AND CTSTH.FK_CNTST_ID = 1
                    AND CTSTH.VALIDITY_END_DATE IS NULL)
                AND ROWNUM < 2
                ")
                while response = (cursor.fetch())
                    return response
                end

                cursor.close
                @connection.logoff 
        end


        def buscar_cliente_pf_pre_cartao
            conectar_banco_dados
            cursor = @connection.exec("
                SELECT 
                (SELECT CC.NRC FROM SUP_SCH.CST_CUSTOMER_COMPANY CC WHERE C.ID = CC.FK_CUST_ID) AS NRC
                FROM 
                SUP_SCH.CST_CUSTOMER C, SUP_SCH.CNT_CONTRACT N, SUP_SCH.CAT_PRODUCT P, SUP_SCH.CNT_CONTRACTED_PRODUCT CP,
                VCL_VEHICLE v, VCL_VEHICLE_ACCESS_POINT vap, VCL_VEHICLE_ACCESS_POINT_IDENT vi,
                SUP_SCH.ACC_PAYMENT_MODE MO, SUP_SCH.ACC_ACCOUNT A
                WHERE 1=1
                AND V.FK_CUST_ID = A.FK_CUST_ID
                AND A.ID = MO.FK_ACCNT_ID
                AND A.FK_CUST_ID = C.ID
                AND vi.FK_VCLAP_ID = vap.ID
                AND vap.FK_VCLVC_ID = v.id
                      AND C.ID = v.FK_CUST_ID
                      AND vi.FINAL_DATE is null
                      AND N.FK_CUST_ID = C.ID
                      AND N.ID = CP.FK_SVCTR_ID 
                      AND CP.FK_PRDCT_ID = P.ID
                      AND C.PERSON_TYPE = 1
                      AND A.REAL_BALANCE < 0
                      AND MO.PAY_MODE = 3	
                      AND P.ID in ('100282001') --Planos SEM SER TRIGGER 
                                AND not exists(select 1 from CNT_CONTRACTED_PROD_STATUS_HIS CTSTH, CNT_CONTRACTED_PRODUCT CP, CNT_CONTRACT N, CAT_PRODUCT P
                                where CTSTH.FK_CTPRD_ID = CP.ID 
                                 AND CP.FK_PRDCT_ID = P.ID
                                AND N.ID = CP.FK_SVCTR_ID
                                AND N.FK_CUST_ID = C.ID
                                AND CTSTH.FK_CNTST_ID in (2,3) AND CTSTH.VALIDITY_END_DATE IS NULL)
                      AND ROWNUM < 2
                ")
                while response = (cursor.fetch())
                    return response
                end
        
                cursor.close
                @connection.logoff 
        end

def buscar_cliente_pf_pre_debito
    conectar_banco_dados
    cursor = @connection.exec("
        SELECT 
  (SELECT CC.NRC FROM SUP_SCH.CST_CUSTOMER_COMPANY CC WHERE C.ID = CC.FK_CUST_ID) AS NRC
  FROM 
  SUP_SCH.CST_CUSTOMER C, SUP_SCH.CNT_CONTRACT N, SUP_SCH.CAT_PRODUCT P, SUP_SCH.CNT_CONTRACTED_PRODUCT CP,
  VCL_VEHICLE v, VCL_VEHICLE_ACCESS_POINT vap, VCL_VEHICLE_ACCESS_POINT_IDENT vi,
  SUP_SCH.ACC_PAYMENT_MODE MO, SUP_SCH.ACC_ACCOUNT A
  WHERE 1=1
  AND V.FK_CUST_ID = A.FK_CUST_ID
  AND A.ID = MO.FK_ACCNT_ID
  AND A.FK_CUST_ID = C.ID
  AND vi.FK_VCLAP_ID = vap.ID
  AND vap.FK_VCLVC_ID = v.id
        AND C.ID = v.FK_CUST_ID
        AND vi.FINAL_DATE is null
        AND N.FK_CUST_ID = C.ID
        AND N.ID = CP.FK_SVCTR_ID 
        AND CP.FK_PRDCT_ID = P.ID
        AND A.REAL_BALANCE < -100
        AND MO.PAY_MODE = 4	
        AND C.PERSON_TYPE = 1
        --and CP.sale_date > sysdate - 150
                  AND not exists(select 1 from CNT_CONTRACTED_PROD_STATUS_HIS CTSTH, CNT_CONTRACTED_PRODUCT CP, CNT_CONTRACT N, CAT_PRODUCT P
                  where CTSTH.FK_CTPRD_ID = CP.ID 
                   AND CP.FK_PRDCT_ID = P.ID
                  AND N.ID = CP.FK_SVCTR_ID
                  AND N.FK_CUST_ID = C.ID
                  AND CTSTH.FK_CNTST_ID in (2,3) AND CTSTH.VALIDITY_END_DATE IS NULL)
        AND ROWNUM < 2 
        ")
        while response = (cursor.fetch())
            return response
        end

        cursor.close
        @connection.logoff 
end


def buscar_cliente_pf_pos_debito
    conectar_banco_dados
    cursor = @connection.exec("
        SELECT 
        (SELECT CC.NRC FROM SUP_SCH.CST_CUSTOMER_COMPANY CC WHERE C.ID = CC.FK_CUST_ID) AS NRC
        FROM 
        SUP_SCH.CST_CUSTOMER C, SUP_SCH.CNT_CONTRACT N, SUP_SCH.CAT_PRODUCT P, SUP_SCH.CNT_CONTRACTED_PRODUCT CP,
        VCL_VEHICLE v, VCL_VEHICLE_ACCESS_POINT vap, VCL_VEHICLE_ACCESS_POINT_IDENT vi,
        SUP_SCH.ACC_PAYMENT_MODE MO, SUP_SCH.ACC_ACCOUNT A
        WHERE 1=1
        AND V.FK_CUST_ID = A.FK_CUST_ID
        AND A.ID = MO.FK_ACCNT_ID
        AND A.FK_CUST_ID = C.ID
        AND vi.FK_VCLAP_ID = vap.ID
        AND vap.FK_VCLVC_ID = v.id
                AND C.ID = v.FK_CUST_ID
                AND vi.FINAL_DATE is null
                AND N.FK_CUST_ID = C.ID
                AND N.ID = CP.FK_SVCTR_ID 
                AND CP.FK_PRDCT_ID = P.ID
                AND A.REAL_BALANCE < 0
                AND MO.PAY_MODE = 2	
                AND C.PERSON_TYPE = 1
                        AND not exists(select 1 from CNT_CONTRACTED_PROD_STATUS_HIS CTSTH, CNT_CONTRACTED_PRODUCT CP, CNT_CONTRACT N, CAT_PRODUCT P
                        where CTSTH.FK_CTPRD_ID = CP.ID 
                        AND CP.FK_PRDCT_ID = P.ID
                        AND N.ID = CP.FK_SVCTR_ID
                        AND N.FK_CUST_ID = C.ID
                        AND CTSTH.FK_CNTST_ID in (2,3) AND CTSTH.VALIDITY_END_DATE IS NULL)
                AND ROWNUM < 2
        ")
        while response = (cursor.fetch())
            return response
        end

        cursor.close
        @connection.logoff 
end

def buscar_cliente_pf_boleto
    conectar_banco_dados
    cursor = @connection.exec("
        SELECT 
  (SELECT CC.NRC FROM SUP_SCH.CST_CUSTOMER_COMPANY CC WHERE C.ID = CC.FK_CUST_ID) AS NRC
  FROM 
  SUP_SCH.CST_CUSTOMER C, SUP_SCH.CNT_CONTRACT N, SUP_SCH.CAT_PRODUCT P, SUP_SCH.CNT_CONTRACTED_PRODUCT CP,
  VCL_VEHICLE v, VCL_VEHICLE_ACCESS_POINT vap, VCL_VEHICLE_ACCESS_POINT_IDENT vi,
  SUP_SCH.ACC_PAYMENT_MODE MO, SUP_SCH.ACC_ACCOUNT A
  WHERE 1=1
  AND V.FK_CUST_ID = A.FK_CUST_ID
  AND A.ID = MO.FK_ACCNT_ID
  AND A.FK_CUST_ID = C.ID
  AND vi.FK_VCLAP_ID = vap.ID
  AND vap.FK_VCLVC_ID = v.id
        AND C.ID = v.FK_CUST_ID
        AND vi.FINAL_DATE is null
        AND N.FK_CUST_ID = C.ID
        AND N.ID = CP.FK_SVCTR_ID 
        AND CP.FK_PRDCT_ID = P.ID
        AND A.REAL_BALANCE < 0
        AND MO.PAY_MODE = 5
        AND C.PERSON_TYPE = 1	
                  AND not exists(select 1 from CNT_CONTRACTED_PROD_STATUS_HIS CTSTH, CNT_CONTRACTED_PRODUCT CP, CNT_CONTRACT N, CAT_PRODUCT P
                  where CTSTH.FK_CTPRD_ID = CP.ID 
                   AND CP.FK_PRDCT_ID = P.ID
                  AND N.ID = CP.FK_SVCTR_ID
                  AND N.FK_CUST_ID = C.ID
                  AND CTSTH.FK_CNTST_ID in (2,3) AND CTSTH.VALIDITY_END_DATE IS NULL)
        AND ROWNUM < 2
        ")
        while response = (cursor.fetch())
            return response
        end

        cursor.close
        @connection.logoff 
end

def buscar_cliente_pj_boleto
    conectar_banco_dados
    cursor = @connection.exec("
        SELECT 
  (SELECT CC.NRC FROM SUP_SCH.CST_CUSTOMER_COMPANY CC WHERE C.ID = CC.FK_CUST_ID) AS NRC
  FROM 
  SUP_SCH.CST_CUSTOMER C, SUP_SCH.CNT_CONTRACT N, SUP_SCH.CAT_PRODUCT P, SUP_SCH.CNT_CONTRACTED_PRODUCT CP,
  VCL_VEHICLE v, VCL_VEHICLE_ACCESS_POINT vap, VCL_VEHICLE_ACCESS_POINT_IDENT vi,
  SUP_SCH.ACC_PAYMENT_MODE MO, SUP_SCH.ACC_ACCOUNT A
  WHERE 1=1
  AND V.FK_CUST_ID = A.FK_CUST_ID
  AND A.ID = MO.FK_ACCNT_ID
  AND A.FK_CUST_ID = C.ID
  AND vi.FK_VCLAP_ID = vap.ID
  AND vap.FK_VCLVC_ID = v.id
        AND C.ID = v.FK_CUST_ID
        AND vi.FINAL_DATE is null
        AND N.FK_CUST_ID = C.ID
        AND N.ID = CP.FK_SVCTR_ID 
        AND CP.FK_PRDCT_ID = P.ID
        AND A.REAL_BALANCE < 0
        AND MO.PAY_MODE = 5
        AND C.PERSON_TYPE = 2
        AND A.FK_ACCTP_ID = 1	
                  AND not exists(select 1 from CNT_CONTRACTED_PROD_STATUS_HIS CTSTH, CNT_CONTRACTED_PRODUCT CP, CNT_CONTRACT N, CAT_PRODUCT P
                  where CTSTH.FK_CTPRD_ID = CP.ID 
                   AND CP.FK_PRDCT_ID = P.ID
                  AND N.ID = CP.FK_SVCTR_ID
                  AND N.FK_CUST_ID = C.ID
                  AND CTSTH.FK_CNTST_ID in (2,3) AND CTSTH.VALIDITY_END_DATE IS NULL)
        AND ROWNUM < 2
        ")
        while response = (cursor.fetch())
            return response
        end

        cursor.close
        @connection.logoff 
end


def buscar_cliente_pj_carga_programada
    conectar_banco_dados
    cursor = @connection.exec("
        SELECT 
  (SELECT CC.NRC FROM SUP_SCH.CST_CUSTOMER_COMPANY CC WHERE C.ID = CC.FK_CUST_ID) AS NRC
  FROM 
  SUP_SCH.CST_CUSTOMER C, SUP_SCH.CNT_CONTRACT N, SUP_SCH.CAT_PRODUCT P, SUP_SCH.CNT_CONTRACTED_PRODUCT CP,
  VCL_VEHICLE v, VCL_VEHICLE_ACCESS_POINT vap, VCL_VEHICLE_ACCESS_POINT_IDENT vi,
  SUP_SCH.ACC_PAYMENT_MODE MO, SUP_SCH.ACC_ACCOUNT A
  WHERE 1=1
  AND V.FK_CUST_ID = A.FK_CUST_ID
  AND A.ID = MO.FK_ACCNT_ID
  AND A.FK_CUST_ID = C.ID
  AND vi.FK_VCLAP_ID = vap.ID
  AND vap.FK_VCLVC_ID = v.id
        AND C.ID = v.FK_CUST_ID
        AND vi.FINAL_DATE is null
        AND N.FK_CUST_ID = C.ID
        AND N.ID = CP.FK_SVCTR_ID 
        AND CP.FK_PRDCT_ID = P.ID
        AND A.REAL_BALANCE < 0
        AND MO.PAY_MODE = 6
        AND C.PERSON_TYPE = 2	
                  AND not exists(select 1 from CNT_CONTRACTED_PROD_STATUS_HIS CTSTH, CNT_CONTRACTED_PRODUCT CP, CNT_CONTRACT N, CAT_PRODUCT P
                  where CTSTH.FK_CTPRD_ID = CP.ID 
                   AND CP.FK_PRDCT_ID = P.ID
                  AND N.ID = CP.FK_SVCTR_ID
                  AND N.FK_CUST_ID = C.ID
                  AND CTSTH.FK_CNTST_ID in (2,3) AND CTSTH.VALIDITY_END_DATE IS NULL)
        AND ROWNUM < 2
        ")
        while response = (cursor.fetch())
            return response
        end

        cursor.close
        @connection.logoff 
end

def buscar_cliente_pf_pre_manual
    conectar_banco_dados
    cursor = @connection.exec("
        SELECT 
  (SELECT CC.NRC FROM SUP_SCH.CST_CUSTOMER_COMPANY CC WHERE C.ID = CC.FK_CUST_ID) AS NRC
  FROM 
  SUP_SCH.CST_CUSTOMER C, SUP_SCH.CNT_CONTRACT N, SUP_SCH.CAT_PRODUCT P, SUP_SCH.CNT_CONTRACTED_PRODUCT CP,
  VCL_VEHICLE v, VCL_VEHICLE_ACCESS_POINT vap, VCL_VEHICLE_ACCESS_POINT_IDENT vi,
  SUP_SCH.ACC_PAYMENT_MODE MO, SUP_SCH.ACC_ACCOUNT A
  WHERE 1=1
  AND V.FK_CUST_ID = A.FK_CUST_ID
  AND A.ID = MO.FK_ACCNT_ID
  AND A.FK_CUST_ID = C.ID
  AND vi.FK_VCLAP_ID = vap.ID
  AND vap.FK_VCLVC_ID = v.id
        AND C.ID = v.FK_CUST_ID
        AND vi.FINAL_DATE is null
        AND N.FK_CUST_ID = C.ID
        AND N.ID = CP.FK_SVCTR_ID 
        AND CP.FK_PRDCT_ID = P.ID
        AND A.REAL_BALANCE < 0
        AND MO.PAY_MODE = 7
        AND C.PERSON_TYPE = 1	
                  AND not exists(select 1 from CNT_CONTRACTED_PROD_STATUS_HIS CTSTH, CNT_CONTRACTED_PRODUCT CP, CNT_CONTRACT N, CAT_PRODUCT P
                  where CTSTH.FK_CTPRD_ID = CP.ID 
                   AND CP.FK_PRDCT_ID = P.ID
                  AND N.ID = CP.FK_SVCTR_ID
                  AND N.FK_CUST_ID = C.ID
                  AND CTSTH.FK_CNTST_ID in (2,3) AND CTSTH.VALIDITY_END_DATE IS NULL)
        AND ROWNUM < 2
        ")
        while response = (cursor.fetch())
            return response
            
        end
        cursor.close
        @connection.logoff 
end


def buscar_cliente_pf_pos_cartao
    conectar_banco_dados
    cursor = @connection.exec("
        SELECT 
  (SELECT CC.NRC FROM SUP_SCH.CST_CUSTOMER_COMPANY CC WHERE C.ID = CC.FK_CUST_ID) AS NRC
  FROM 
  SUP_SCH.CST_CUSTOMER C, SUP_SCH.CNT_CONTRACT N, SUP_SCH.CAT_PRODUCT P, SUP_SCH.CNT_CONTRACTED_PRODUCT CP,
  VCL_VEHICLE v, VCL_VEHICLE_ACCESS_POINT vap, VCL_VEHICLE_ACCESS_POINT_IDENT vi,
  SUP_SCH.ACC_PAYMENT_MODE MO, SUP_SCH.ACC_ACCOUNT A
  WHERE 1=1
  AND V.FK_CUST_ID = A.FK_CUST_ID
  AND A.ID = MO.FK_ACCNT_ID
  AND A.FK_CUST_ID = C.ID
  AND vi.FK_VCLAP_ID = vap.ID
  AND vap.FK_VCLVC_ID = v.id
        AND C.ID = v.FK_CUST_ID
        AND vi.FINAL_DATE is null
        AND N.FK_CUST_ID = C.ID
        AND N.ID = CP.FK_SVCTR_ID 
        AND CP.FK_PRDCT_ID = P.ID
        AND A.REAL_BALANCE < 0
        AND MO.PAY_MODE = 1
        AND C.PERSON_TYPE = 1	
                  AND not exists(select 1 from CNT_CONTRACTED_PROD_STATUS_HIS CTSTH, CNT_CONTRACTED_PRODUCT CP, CNT_CONTRACT N, CAT_PRODUCT P
                  where CTSTH.FK_CTPRD_ID = CP.ID 
                   AND CP.FK_PRDCT_ID = P.ID
                  AND N.ID = CP.FK_SVCTR_ID
                  AND N.FK_CUST_ID = C.ID
                  AND CTSTH.FK_CNTST_ID in (2,3) AND CTSTH.VALIDITY_END_DATE IS NULL)
        AND ROWNUM < 2
        ")
        while response = (cursor.fetch())
            return response
            
        end
        cursor.close
        @connection.logoff 
end


def buscar_cliente_pf_pre_cartao_trigger
    conectar_banco_dados
    cursor = @connection.exec("
        SELECT 
        (SELECT CC.NRC FROM SUP_SCH.CST_CUSTOMER_COMPANY CC WHERE C.ID = CC.FK_CUST_ID) AS NRC
        FROM 
        SUP_SCH.CST_CUSTOMER C, SUP_SCH.CNT_CONTRACT N, SUP_SCH.CAT_PRODUCT P, SUP_SCH.CNT_CONTRACTED_PRODUCT CP,
        VCL_VEHICLE v, VCL_VEHICLE_ACCESS_POINT vap, VCL_VEHICLE_ACCESS_POINT_IDENT vi,
        SUP_SCH.ACC_PAYMENT_MODE MO, SUP_SCH.ACC_ACCOUNT A
        WHERE 1=1
        AND V.FK_CUST_ID = A.FK_CUST_ID
        AND A.ID = MO.FK_ACCNT_ID
        AND A.FK_CUST_ID = C.ID
        AND vi.FK_VCLAP_ID = vap.ID
        AND vap.FK_VCLVC_ID = v.id
              AND C.ID = v.FK_CUST_ID
              AND vi.FINAL_DATE is null
              AND N.FK_CUST_ID = C.ID
              AND N.ID = CP.FK_SVCTR_ID 
              AND CP.FK_PRDCT_ID = P.ID
              AND A.REAL_BALANCE < 0
              AND P.ID IN ('100322007')
              AND MO.PAY_MODE = 3
                        AND not exists(select 1 from CNT_CONTRACTED_PROD_STATUS_HIS CTSTH, CNT_CONTRACTED_PRODUCT CP, CNT_CONTRACT N, CAT_PRODUCT P
                        where CTSTH.FK_CTPRD_ID = CP.ID 
                         AND CP.FK_PRDCT_ID = P.ID
                        AND N.ID = CP.FK_SVCTR_ID
                        AND N.FK_CUST_ID = C.ID
                        AND CTSTH.FK_CNTST_ID in (2,3) AND CTSTH.VALIDITY_END_DATE IS NULL)
              AND ROWNUM < 2
        ")
        while response = (cursor.fetch())
            return response
            
        end
        cursor.close
        @connection.logoff 
end


        def buscar_cliente_liberar_disparo_cartao
            conectar_banco_dados
            cursor = @connection.exec("
                SELECT  
                    (SELECT CC.NRC FROM SUP_SCH.CST_CUSTOMER_COMPANY CC WHERE A.ID = AB.FK_ACCNT_ID AND A.FK_CUST_ID = CC.FK_CUST_ID) AS NRC
                    FROM SUP_SCH.ACC_BLOCK ab, SUP_SCH.ACC_ACCOUNT A, ACC_PAYMENT_MODE MO
                    WHERE  A.ID = AB.FK_ACCNT_ID(+)
                    and A.ID = MO.FK_ACCNT_ID(+)
                    and FK_REASS_ID = -33
                    and ab.actual = 1
                    AND PAY_MODE = 3
                    and ab.modification_date > sysdate - 90
                    and rownum < 2
                    ORDER BY AB.MODIFICATION_DATE DESC
                ")
            while response = (cursor.fetch())
                return response
            end

            cursor.close
            @connection.logoff 
        end

        def buscar_cliente_liberar_disparo_debito
            conectar_banco_dados
            cursor = @connection.exec("
                SELECT  
                    (SELECT CC.NRC FROM SUP_SCH.CST_CUSTOMER_COMPANY CC WHERE A.ID = AB.FK_ACCNT_ID AND A.FK_CUST_ID = CC.FK_CUST_ID) AS NRC
                    FROM SUP_SCH.ACC_BLOCK ab, SUP_SCH.ACC_ACCOUNT A, ACC_PAYMENT_MODE MO
                    WHERE  A.ID = AB.FK_ACCNT_ID(+)
                    and A.ID = MO.FK_ACCNT_ID(+)
                    and FK_REASS_ID = -33
                    and ab.actual = 1
                    AND PAY_MODE in (2,4)
                    and ab.modification_date > sysdate - 300
                    and rownum < 2
                    ORDER BY AB.MODIFICATION_DATE DESC
                ")
            while response = (cursor.fetch())
                return response
            end

            cursor.close
            @connection.logoff 
        end

###### BUSCAR CLIENTE PARA ALTERAR CONTA CORRENTE ######

    def buscar_pos_debito_cc
            conectar_banco_dados
            cursor = @connection.exec("
        SELECT 
        (SELECT CC.NRC FROM SUP_SCH.CST_CUSTOMER_COMPANY CC WHERE C.ID = CC.FK_CUST_ID) AS NRC
        FROM 
        SUP_SCH.CST_CUSTOMER C, SUP_SCH.CNT_CONTRACT N, SUP_SCH.CAT_PRODUCT P, SUP_SCH.CNT_CONTRACTED_PRODUCT CP,
        VCL_VEHICLE v, VCL_VEHICLE_ACCESS_POINT vap, VCL_VEHICLE_ACCESS_POINT_IDENT vi,
        SUP_SCH.ACC_PAYMENT_MODE MO, SUP_SCH.ACC_ACCOUNT A
        WHERE 1=1
        AND V.FK_CUST_ID = A.FK_CUST_ID
        AND A.ID = MO.FK_ACCNT_ID
        AND A.FK_CUST_ID = C.ID
        AND vi.FK_VCLAP_ID = vap.ID
        AND vap.FK_VCLVC_ID = v.id
                AND C.ID = v.FK_CUST_ID
                AND vi.FINAL_DATE is null
                AND N.FK_CUST_ID = C.ID
                AND N.ID = CP.FK_SVCTR_ID 
                AND CP.FK_PRDCT_ID = P.ID
                AND A.REAL_BALANCE < 0
                AND MO.PAY_MODE = 2	
                AND MO.formatted_bank_acc not in '04366832      '               
                        AND not exists(select 1 from CNT_CONTRACTED_PROD_STATUS_HIS CTSTH, CNT_CONTRACTED_PRODUCT CP, CNT_CONTRACT N, CAT_PRODUCT P
                        where CTSTH.FK_CTPRD_ID = CP.ID 
                        AND CP.FK_PRDCT_ID = P.ID
                        AND N.ID = CP.FK_SVCTR_ID
                        AND N.FK_CUST_ID = C.ID
                        AND CTSTH.FK_CNTST_ID in (2,3) AND CTSTH.VALIDITY_END_DATE IS NULL)
        AND ROWNUM < 2
        ")
        while response = (cursor.fetch())
            return response
        end

        cursor.close
        @connection.logoff 
    end


    def buscar_cliente_pre_debito_cc
        conectar_banco_dados
        cursor = @connection.exec("
            SELECT 
      (SELECT CC.NRC FROM SUP_SCH.CST_CUSTOMER_COMPANY CC WHERE C.ID = CC.FK_CUST_ID) AS NRC
      FROM 
      SUP_SCH.CST_CUSTOMER C, SUP_SCH.CNT_CONTRACT N, SUP_SCH.CAT_PRODUCT P, SUP_SCH.CNT_CONTRACTED_PRODUCT CP,
      VCL_VEHICLE v, VCL_VEHICLE_ACCESS_POINT vap, VCL_VEHICLE_ACCESS_POINT_IDENT vi,
      SUP_SCH.ACC_PAYMENT_MODE MO, SUP_SCH.ACC_ACCOUNT A
      WHERE 1=1
      AND V.FK_CUST_ID = A.FK_CUST_ID
      AND A.ID = MO.FK_ACCNT_ID
      AND A.FK_CUST_ID = C.ID
      AND vi.FK_VCLAP_ID = vap.ID
      AND vap.FK_VCLVC_ID = v.id
            AND C.ID = v.FK_CUST_ID
            AND vi.FINAL_DATE is null
            AND N.FK_CUST_ID = C.ID
            AND N.ID = CP.FK_SVCTR_ID 
            AND CP.FK_PRDCT_ID = P.ID
            AND A.REAL_BALANCE < 0
            AND MO.PAY_MODE = 4	
            AND MO.formatted_bank_acc not in '04366832      '        
                      AND not exists(select 1 from CNT_CONTRACTED_PROD_STATUS_HIS CTSTH, CNT_CONTRACTED_PRODUCT CP, CNT_CONTRACT N, CAT_PRODUCT P
                      where CTSTH.FK_CTPRD_ID = CP.ID 
                       AND CP.FK_PRDCT_ID = P.ID
                      AND N.ID = CP.FK_SVCTR_ID
                      AND N.FK_CUST_ID = C.ID
                      AND CTSTH.FK_CNTST_ID in (2,3) AND CTSTH.VALIDITY_END_DATE IS NULL)
            AND ROWNUM < 2 
            ")
            while response = (cursor.fetch())
                return response
            end
    
            cursor.close
            @connection.logoff 
    end



    def buscar_cliente_pj_pre_cc

        conectar_banco_dados

            cursor = @connection.exec("
            SELECT 
            (SELECT CC.NRC FROM SUP_SCH.CST_CUSTOMER_COMPANY CC WHERE C.ID = CC.FK_CUST_ID) AS NRC
            FROM 
            SUP_SCH.CST_CUSTOMER C, SUP_SCH.CNT_CONTRACT N, SUP_SCH.CAT_PRODUCT P, SUP_SCH.CNT_CONTRACTED_PRODUCT CP,
            VCL_VEHICLE v, VCL_VEHICLE_ACCESS_POINT vap, VCL_VEHICLE_ACCESS_POINT_IDENT vi,
            SUP_SCH.ACC_PAYMENT_MODE MO, SUP_SCH.ACC_ACCOUNT A
            WHERE 1=1
            AND V.FK_CUST_ID = A.FK_CUST_ID
            AND A.ID = MO.FK_ACCNT_ID
            AND A.FK_CUST_ID = C.ID
            AND vi.FK_VCLAP_ID = vap.ID
            AND vap.FK_VCLVC_ID = v.id
            AND C.ID = v.FK_CUST_ID
            AND vi.FINAL_DATE is null
            AND N.FK_CUST_ID = C.ID
            AND N.ID = CP.FK_SVCTR_ID 
            AND CP.FK_PRDCT_ID = P.ID
            AND P.ID = '100192013'	--EMPRESA PRE AUTOMATICO PJ
            AND MO.formatted_bank_acc not in '04366832      '        
              AND not exists(select 1 from CNT_CONTRACTED_PROD_STATUS_HIS CTSTH, CNT_CONTRACTED_PRODUCT CP, CNT_CONTRACT N, CAT_PRODUCT P
              where CTSTH.FK_CTPRD_ID = CP.ID 
               AND CP.FK_PRDCT_ID = P.ID
              AND N.ID = CP.FK_SVCTR_ID
              AND N.FK_CUST_ID = C.ID
              AND CTSTH.FK_CNTST_ID in (2,3) AND CTSTH.VALIDITY_END_DATE IS NULL)
            AND ROWNUM < 2 
        ")

        while response = (cursor.fetch())
            return response
        end

        cursor.close
        @connection.logoff 
    end


    def buscar_cliente_pj_pos_cc

        conectar_banco_dados

            cursor = @connection.exec("
            SELECT 
            (SELECT CC.NRC FROM SUP_SCH.CST_CUSTOMER_COMPANY CC WHERE C.ID = CC.FK_CUST_ID) AS NRC
            FROM 
            SUP_SCH.CST_CUSTOMER C, SUP_SCH.CNT_CONTRACT N, SUP_SCH.CAT_PRODUCT P, SUP_SCH.CNT_CONTRACTED_PRODUCT CP,
            VCL_VEHICLE v, VCL_VEHICLE_ACCESS_POINT vap, VCL_VEHICLE_ACCESS_POINT_IDENT vi,
            SUP_SCH.ACC_PAYMENT_MODE MO, SUP_SCH.ACC_ACCOUNT A
            WHERE 1=1
            AND V.FK_CUST_ID = A.FK_CUST_ID
            AND A.ID = MO.FK_ACCNT_ID
            AND A.FK_CUST_ID = C.ID
            AND vi.FK_VCLAP_ID = vap.ID
            AND vap.FK_VCLVC_ID = v.id
            AND C.ID = v.FK_CUST_ID
            AND vi.FINAL_DATE is null
            AND N.FK_CUST_ID = C.ID
            AND N.ID = CP.FK_SVCTR_ID 
            AND CP.FK_PRDCT_ID = P.ID
            AND P.ID = '100302005'	--SP SEM PARAR - PJ
            AND MO.formatted_bank_acc not in '04366832      '        
              AND not exists(select 1 from CNT_CONTRACTED_PROD_STATUS_HIS CTSTH, CNT_CONTRACTED_PRODUCT CP, CNT_CONTRACT N, CAT_PRODUCT P
              where CTSTH.FK_CTPRD_ID = CP.ID 
               AND CP.FK_PRDCT_ID = P.ID
              AND N.ID = CP.FK_SVCTR_ID
              AND N.FK_CUST_ID = C.ID
              AND CTSTH.FK_CNTST_ID = 3 AND CTSTH.VALIDITY_END_DATE IS NULL)
                  AND not exists(select 1 from CNT_CONTRACTED_PROD_STATUS_HIS CTSTH, CNT_CONTRACTED_PRODUCT CP, CNT_CONTRACT N, CAT_PRODUCT P
                  where CTSTH.FK_CTPRD_ID = CP.ID 
                   AND CP.FK_PRDCT_ID = P.ID
                  AND N.ID = CP.FK_SVCTR_ID
                  AND N.FK_CUST_ID = C.ID
                  AND CTSTH.FK_CNTST_ID = 2 AND CTSTH.VALIDITY_END_DATE IS NULL)
            AND ROWNUM < 2 
        ")

        while response = (cursor.fetch())
            return response
        end

        cursor.close
        @connection.logoff 
    end


    def buscar_cliente_pj_carga_programada_cc
        conectar_banco_dados
        cursor = @connection.exec("
            SELECT 
      (SELECT CC.NRC FROM SUP_SCH.CST_CUSTOMER_COMPANY CC WHERE C.ID = CC.FK_CUST_ID) AS NRC
      FROM 
      SUP_SCH.CST_CUSTOMER C, SUP_SCH.CNT_CONTRACT N, SUP_SCH.CAT_PRODUCT P, SUP_SCH.CNT_CONTRACTED_PRODUCT CP,
      VCL_VEHICLE v, VCL_VEHICLE_ACCESS_POINT vap, VCL_VEHICLE_ACCESS_POINT_IDENT vi,
      SUP_SCH.ACC_PAYMENT_MODE MO, SUP_SCH.ACC_ACCOUNT A
      WHERE 1=1
      AND V.FK_CUST_ID = A.FK_CUST_ID
      AND A.ID = MO.FK_ACCNT_ID
      AND A.FK_CUST_ID = C.ID
      AND vi.FK_VCLAP_ID = vap.ID
      AND vap.FK_VCLVC_ID = v.id
            AND C.ID = v.FK_CUST_ID
            AND vi.FINAL_DATE is null
            AND N.FK_CUST_ID = C.ID
            AND N.ID = CP.FK_SVCTR_ID 
            AND CP.FK_PRDCT_ID = P.ID
            AND A.REAL_BALANCE < 0
            AND MO.PAY_MODE = 6
            AND C.PERSON_TYPE = 2	
            AND MO.formatted_bank_acc not in '04366832      '               
                      AND not exists(select 1 from CNT_CONTRACTED_PROD_STATUS_HIS CTSTH, CNT_CONTRACTED_PRODUCT CP, CNT_CONTRACT N, CAT_PRODUCT P
                      where CTSTH.FK_CTPRD_ID = CP.ID 
                       AND CP.FK_PRDCT_ID = P.ID
                      AND N.ID = CP.FK_SVCTR_ID
                      AND N.FK_CUST_ID = C.ID
                      AND CTSTH.FK_CNTST_ID in (2,3) AND CTSTH.VALIDITY_END_DATE IS NULL)
            AND ROWNUM < 2
            ")
            while response = (cursor.fetch())
                return response
            end
    
            cursor.close
            @connection.logoff 
    end



    def buscar_cliente_inadimplente_cc

        conectar_banco_dados

            cursor = @connection.exec("
                SELECT 
                (SELECT CC.NRC FROM SUP_SCH.CST_CUSTOMER_COMPANY CC WHERE C.ID = CC.FK_CUST_ID) AS NRC
                FROM 
                SUP_SCH.CST_CUSTOMER C, SUP_SCH.CNT_CONTRACT N, SUP_SCH.CAT_PRODUCT P, SUP_SCH.CNT_CONTRACTED_PRODUCT CP,
                VCL_VEHICLE v, VCL_VEHICLE_ACCESS_POINT vap, VCL_VEHICLE_ACCESS_POINT_IDENT vi,
                SUP_SCH.ACC_PAYMENT_MODE MO, SUP_SCH.ACC_ACCOUNT A
                WHERE 1=1
                AND V.FK_CUST_ID = A.FK_CUST_ID
                AND A.ID = MO.FK_ACCNT_ID
                AND A.FK_CUST_ID = C.ID
                AND vi.FK_VCLAP_ID = vap.ID
                AND vap.FK_VCLVC_ID = v.id
                    AND C.ID = v.FK_CUST_ID
                    AND vi.FINAL_DATE is not null
                    AND N.FK_CUST_ID = C.ID
                    AND N.ID = CP.FK_SVCTR_ID
                    AND CP.FK_PRDCT_ID = P.ID
                    AND MO.formatted_bank_acc not in '04366832      '  
                        AND exists(select 1 from CNT_CONTRACTED_PROD_STATUS_HIS CTSTH, CNT_CONTRACTED_PRODUCT CP, SUP_SCH.CNT_CONTRACT N, CAT_PRODUCT P
                            where CTSTH.FK_CTPRD_ID = CP.ID 
                            AND CP.FK_PRDCT_ID = P.ID
                            AND N.ID = CP.FK_SVCTR_ID
                            AND N.FK_CUST_ID = C.ID
                            AND CTSTH.FK_CNTST_ID = 3 AND CTSTH.VALIDITY_END_DATE IS NULL)
                    AND ROWNUM < 2
            ")

            while response = (cursor.fetch())
                return response
            end

            cursor.close
            @connection.logoff 
    end



    def buscar_cliente_pf_conta_terceiro_cc
        conectar_banco_dados
        cursor = @connection.exec("
            SELECT (SELECT CC.NRC FROM SUP_SCH.CST_CUSTOMER_COMPANY CC WHERE C.ID = CC.FK_CUST_ID) AS NRC
            FROM INV_BANK_ACCOUNT BA, CST_CUSTOMER C, DOC_IDENTIFICATION_DOCUMENT D, ACC_PAYMENT_MODE MO, ACC_ACCOUNT A
            WHERE 1=1
            AND BA.CUSTOMER_ID = C.ID
            AND A.ID = MO.FK_ACCNT_ID
            AND A.FK_CUST_ID = C.ID
            AND MO.PAY_MODE in (2,4)
            AND MO.formatted_bank_acc not in '04366832      '       
            AND C.FK_DOCUM_MAIN_DOCUMENT_ID = D.ID
            AND LPAD(BA.DOCUMENT_NUMBER,11,0) <> D.DOCUMENT_NUMBER AND D.FK_DOCTP_ID = 2 -- 2-CPF 
            and rownum < 2
            ")
        while response = (cursor.fetch())
            return response
        end

        cursor.close
        @connection.logoff 
    end




    ###### BUSCAR CLIENTE PARA ALTERAR DIA VENCIMENTO ######

    def buscar_pf_pos_debito_venci
            conectar_banco_dados
            cursor = @connection.exec("
                SELECT 
                (SELECT CC.NRC FROM SUP_SCH.CST_CUSTOMER_COMPANY CC WHERE C.ID = CC.FK_CUST_ID) AS NRC
                FROM 
                SUP_SCH.CST_CUSTOMER C, SUP_SCH.CNT_CONTRACT N, SUP_SCH.CAT_PRODUCT P, SUP_SCH.CNT_CONTRACTED_PRODUCT CP,
                VCL_VEHICLE v, VCL_VEHICLE_ACCESS_POINT vap, VCL_VEHICLE_ACCESS_POINT_IDENT vi,
                SUP_SCH.ACC_PAYMENT_MODE MO, SUP_SCH.ACC_ACCOUNT A
                WHERE 1=1
                AND V.FK_CUST_ID = A.FK_CUST_ID
                AND A.ID = MO.FK_ACCNT_ID
                AND A.FK_CUST_ID = C.ID
                AND vi.FK_VCLAP_ID = vap.ID
                AND vap.FK_VCLVC_ID = v.id
                        AND C.ID = v.FK_CUST_ID
                        AND vi.FINAL_DATE is null
                        AND N.FK_CUST_ID = C.ID
                        AND N.ID = CP.FK_SVCTR_ID 
                        AND CP.FK_PRDCT_ID = P.ID
                        AND A.REAL_BALANCE < 0
                        AND MO.PAY_MODE = 2	
                        AND A.DUE_DAY = '10'
                        AND C.PERSON_TYPE = 1	
                                AND not exists(select 1 from CNT_CONTRACTED_PROD_STATUS_HIS CTSTH, CNT_CONTRACTED_PRODUCT CP, CNT_CONTRACT N, CAT_PRODUCT P
                                where CTSTH.FK_CTPRD_ID = CP.ID 
                                AND CP.FK_PRDCT_ID = P.ID
                                AND N.ID = CP.FK_SVCTR_ID
                                AND N.FK_CUST_ID = C.ID
                                AND CTSTH.FK_CNTST_ID in (2,3) AND CTSTH.VALIDITY_END_DATE IS NULL)
                AND ROWNUM < 2
        ")
        while response = (cursor.fetch())
            return response
        end

        cursor.close
        @connection.logoff 
    end

    def buscar_pf_pos_boleto_venci
        conectar_banco_dados
        cursor = @connection.exec("
            SELECT 
            (SELECT CC.NRC FROM SUP_SCH.CST_CUSTOMER_COMPANY CC WHERE C.ID = CC.FK_CUST_ID) AS NRC
            FROM 
            SUP_SCH.CST_CUSTOMER C, SUP_SCH.CNT_CONTRACT N, SUP_SCH.CAT_PRODUCT P, SUP_SCH.CNT_CONTRACTED_PRODUCT CP,
            VCL_VEHICLE v, VCL_VEHICLE_ACCESS_POINT vap, VCL_VEHICLE_ACCESS_POINT_IDENT vi,
            SUP_SCH.ACC_PAYMENT_MODE MO, SUP_SCH.ACC_ACCOUNT A
            WHERE 1=1
            AND V.FK_CUST_ID = A.FK_CUST_ID
            AND A.ID = MO.FK_ACCNT_ID
            AND A.FK_CUST_ID = C.ID
            AND vi.FK_VCLAP_ID = vap.ID
            AND vap.FK_VCLVC_ID = v.id
                    AND C.ID = v.FK_CUST_ID
                    AND vi.FINAL_DATE is null
                    AND N.FK_CUST_ID = C.ID
                    AND N.ID = CP.FK_SVCTR_ID 
                    AND CP.FK_PRDCT_ID = P.ID
                    AND MO.PAY_MODE = 5	
                    AND A.DUE_DAY = '10'
                    AND C.PERSON_TYPE = 1	
                            AND not exists(select 1 from CNT_CONTRACTED_PROD_STATUS_HIS CTSTH, CNT_CONTRACTED_PRODUCT CP, CNT_CONTRACT N, CAT_PRODUCT P
                            where CTSTH.FK_CTPRD_ID = CP.ID 
                            AND CP.FK_PRDCT_ID = P.ID
                            AND N.ID = CP.FK_SVCTR_ID
                            AND N.FK_CUST_ID = C.ID
                            AND CTSTH.FK_CNTST_ID in (2,3) AND CTSTH.VALIDITY_END_DATE IS NULL)
            AND ROWNUM < 2
            ")
            while response = (cursor.fetch())
                return response
            end

            cursor.close
            @connection.logoff 
    end

    def buscar_pf_pos_cartao_venci
        conectar_banco_dados
        cursor = @connection.exec("
            SELECT 
            (SELECT CC.NRC FROM SUP_SCH.CST_CUSTOMER_COMPANY CC WHERE C.ID = CC.FK_CUST_ID) AS NRC
            FROM 
            SUP_SCH.CST_CUSTOMER C, SUP_SCH.CNT_CONTRACT N, SUP_SCH.CAT_PRODUCT P, SUP_SCH.CNT_CONTRACTED_PRODUCT CP,
            VCL_VEHICLE v, VCL_VEHICLE_ACCESS_POINT vap, VCL_VEHICLE_ACCESS_POINT_IDENT vi,
            SUP_SCH.ACC_PAYMENT_MODE MO, SUP_SCH.ACC_ACCOUNT A
            WHERE 1=1
            AND V.FK_CUST_ID = A.FK_CUST_ID
            AND A.ID = MO.FK_ACCNT_ID
            AND A.FK_CUST_ID = C.ID
            AND vi.FK_VCLAP_ID = vap.ID
            AND vap.FK_VCLVC_ID = v.id
                    AND C.ID = v.FK_CUST_ID
                    AND vi.FINAL_DATE is null
                    AND N.FK_CUST_ID = C.ID
                    AND N.ID = CP.FK_SVCTR_ID 
                    AND CP.FK_PRDCT_ID = P.ID
                    AND A.REAL_BALANCE < 0
                    AND MO.PAY_MODE = 1	
                    AND A.DUE_DAY = '15'
                            AND not exists(select 1 from CNT_CONTRACTED_PROD_STATUS_HIS CTSTH, CNT_CONTRACTED_PRODUCT CP, CNT_CONTRACT N, CAT_PRODUCT P
                            where CTSTH.FK_CTPRD_ID = CP.ID 
                            AND CP.FK_PRDCT_ID = P.ID
                            AND N.ID = CP.FK_SVCTR_ID
                            AND N.FK_CUST_ID = C.ID
                            AND CTSTH.FK_CNTST_ID in (2,3) AND CTSTH.VALIDITY_END_DATE IS NULL)
            AND ROWNUM < 2
            ")
            while response = (cursor.fetch())
                return response
            end

            cursor.close
            @connection.logoff 
    end


    def buscar_cliente_pj_pos_venci

        conectar_banco_dados

            cursor = @connection.exec("
                SELECT 
                (SELECT CC.NRC FROM SUP_SCH.CST_CUSTOMER_COMPANY CC WHERE C.ID = CC.FK_CUST_ID) AS NRC
                FROM 
                SUP_SCH.CST_CUSTOMER C, SUP_SCH.CNT_CONTRACT N, SUP_SCH.CAT_PRODUCT P, SUP_SCH.CNT_CONTRACTED_PRODUCT CP,
                VCL_VEHICLE v, VCL_VEHICLE_ACCESS_POINT vap, VCL_VEHICLE_ACCESS_POINT_IDENT vi,
                SUP_SCH.ACC_PAYMENT_MODE MO, SUP_SCH.ACC_ACCOUNT A
                WHERE 1=1
                AND V.FK_CUST_ID = A.FK_CUST_ID
                AND A.ID = MO.FK_ACCNT_ID
                AND A.FK_CUST_ID = C.ID
                AND vi.FK_VCLAP_ID = vap.ID
                AND vap.FK_VCLVC_ID = v.id
                        AND C.ID = v.FK_CUST_ID
                        AND vi.FINAL_DATE is null
                        AND N.FK_CUST_ID = C.ID
                        AND N.ID = CP.FK_SVCTR_ID 
                        AND CP.FK_PRDCT_ID = P.ID
                        AND A.REAL_BALANCE < 0  --SALDO POSITIVO
                        AND MO.PAY_MODE = 2     -- DEBITO
                        AND C.PERSON_TYPE = 2   -- 2 PJ
                        and A.FK_ACCTP_ID = 1   --1 USUARIO
                        AND A.DUE_DAY = '10'    --DIA VENCIMENTO
                                AND not exists(select 1 from CNT_CONTRACTED_PROD_STATUS_HIS CTSTH, CNT_CONTRACTED_PRODUCT CP, CNT_CONTRACT N, CAT_PRODUCT P
                                where CTSTH.FK_CTPRD_ID = CP.ID 
                                AND CP.FK_PRDCT_ID = P.ID
                                AND N.ID = CP.FK_SVCTR_ID
                                AND N.FK_CUST_ID = C.ID
                                AND CTSTH.FK_CNTST_ID in (2,3) AND CTSTH.VALIDITY_END_DATE IS NULL)
                AND ROWNUM < 2
        ")

        while response = (cursor.fetch())
            return response
        end

        cursor.close
        @connection.logoff 
    end

    def buscar_cliente_pj_boleto_venci

        conectar_banco_dados

            cursor = @connection.exec("
                SELECT 
                (SELECT CC.NRC FROM SUP_SCH.CST_CUSTOMER_COMPANY CC WHERE C.ID = CC.FK_CUST_ID) AS NRC
                FROM 
                SUP_SCH.CST_CUSTOMER C, SUP_SCH.CNT_CONTRACT N, SUP_SCH.CAT_PRODUCT P, SUP_SCH.CNT_CONTRACTED_PRODUCT CP,
                VCL_VEHICLE v, VCL_VEHICLE_ACCESS_POINT vap, VCL_VEHICLE_ACCESS_POINT_IDENT vi,
                SUP_SCH.ACC_PAYMENT_MODE MO, SUP_SCH.ACC_ACCOUNT A
                WHERE 1=1
                AND V.FK_CUST_ID = A.FK_CUST_ID
                AND A.ID = MO.FK_ACCNT_ID
                AND A.FK_CUST_ID = C.ID
                AND vi.FK_VCLAP_ID = vap.ID
                AND vap.FK_VCLVC_ID = v.id
                        AND C.ID = v.FK_CUST_ID
                        AND vi.FINAL_DATE is null
                        AND N.FK_CUST_ID = C.ID
                        AND N.ID = CP.FK_SVCTR_ID 
                        AND CP.FK_PRDCT_ID = P.ID
                        AND A.DUE_DAY <> '15'
                        AND MO.PAY_MODE = 5     -- BOLETO
                        AND C.PERSON_TYPE = 2   -- 2 PJ
                        and A.FK_ACCTP_ID = 1   --1 USUARIO
                                AND not exists(select 1 from CNT_CONTRACTED_PROD_STATUS_HIS CTSTH, CNT_CONTRACTED_PRODUCT CP, CNT_CONTRACT N, CAT_PRODUCT P
                                where CTSTH.FK_CTPRD_ID = CP.ID 
                                AND CP.FK_PRDCT_ID = P.ID
                                AND N.ID = CP.FK_SVCTR_ID
                                AND N.FK_CUST_ID = C.ID
                                AND CTSTH.FK_CNTST_ID in (2,3) AND CTSTH.VALIDITY_END_DATE IS NULL)
                AND ROWNUM < 2
                ")

        while response = (cursor.fetch())
            return response
        end

        cursor.close
        @connection.logoff 
    end


    def buscar_cliente_pj_carga_programada_venci
        conectar_banco_dados
        cursor = @connection.exec("
            SELECT 
      (SELECT CC.NRC FROM SUP_SCH.CST_CUSTOMER_COMPANY CC WHERE C.ID = CC.FK_CUST_ID) AS NRC
      FROM 
      SUP_SCH.CST_CUSTOMER C, SUP_SCH.CNT_CONTRACT N, SUP_SCH.CAT_PRODUCT P, SUP_SCH.CNT_CONTRACTED_PRODUCT CP,
      VCL_VEHICLE v, VCL_VEHICLE_ACCESS_POINT vap, VCL_VEHICLE_ACCESS_POINT_IDENT vi,
      SUP_SCH.ACC_PAYMENT_MODE MO, SUP_SCH.ACC_ACCOUNT A
      WHERE 1=1
      AND V.FK_CUST_ID = A.FK_CUST_ID
      AND A.ID = MO.FK_ACCNT_ID
      AND A.FK_CUST_ID = C.ID
      AND vi.FK_VCLAP_ID = vap.ID
      AND vap.FK_VCLVC_ID = v.id
            AND C.ID = v.FK_CUST_ID
            AND vi.FINAL_DATE is null
            AND N.FK_CUST_ID = C.ID
            AND N.ID = CP.FK_SVCTR_ID 
            AND CP.FK_PRDCT_ID = P.ID
            AND A.REAL_BALANCE < 0
            AND MO.PAY_MODE = 6
            AND C.PERSON_TYPE = 2	
            AND NOT EXISTS (SELECT 1 FROM ACC_ACCOUNT AA WHERE AA.FK_CUST_ID = C.ID AND V.FK_CUST_ID = AA.FK_CUST_ID AND AA.FK_ACCTP_ID IN (2,3,4,5))
            AND A.DUE_DAY = '30'    --DIA VENCIMENTO
                      AND not exists(select 1 from CNT_CONTRACTED_PROD_STATUS_HIS CTSTH, CNT_CONTRACTED_PRODUCT CP, CNT_CONTRACT N, CAT_PRODUCT P
                      where CTSTH.FK_CTPRD_ID = CP.ID 
                       AND CP.FK_PRDCT_ID = P.ID
                      AND N.ID = CP.FK_SVCTR_ID
                      AND N.FK_CUST_ID = C.ID
                      AND CTSTH.FK_CNTST_ID in (2,3) AND CTSTH.VALIDITY_END_DATE IS NULL)
            AND ROWNUM < 2
            ")
            while response = (cursor.fetch())
                return response
            end
    
            cursor.close
            @connection.logoff 
    end

    def buscar_cliente_prazo_carencia_venci
        conectar_banco_dados
        cursor = @connection.exec("
            select cc.NRC 
            from reg_register rr, CST_CUSTOMER_COMPANY cc , ACC_PAYMENT_MODE mo, ACC_ACCOUNT A, CST_CUSTOMER C
            where mo.FK_ACCNT_ID = rr.FK_ACCNT_ID
            AND A.ID = MO.FK_ACCNT_ID
            AND A.FK_CUST_ID = C.ID
            AND A.ID = rr.FK_ACCNT_ID
            and rr.FK_CUST_ID = cc.FK_CUST_ID and FK_G_TPN_ID = '100009' 
            and mo.pay_mode = 2
            and A.DUE_DAY <> 10
            and C.PERSON_TYPE = 1
            and CREATION_DATE > sysdate - 10 and rownum < 2
            ")
            while response = (cursor.fetch())
                return response
            end
    
            cursor.close
            @connection.logoff 
    end


###### BUSCAR CLIENTE PARA ALTERAR VALOR PERIÓDICO ######

def buscar_pf_pre_debito_periodico
    conectar_banco_dados
    cursor = @connection.exec("
        SELECT 
        (SELECT CC.NRC FROM SUP_SCH.CST_CUSTOMER_COMPANY CC WHERE C.ID = CC.FK_CUST_ID) AS NRC
        FROM 
        SUP_SCH.CST_CUSTOMER C, SUP_SCH.CNT_CONTRACT N, SUP_SCH.CAT_PRODUCT P, SUP_SCH.CNT_CONTRACTED_PRODUCT CP,
        VCL_VEHICLE v, VCL_VEHICLE_ACCESS_POINT vap, VCL_VEHICLE_ACCESS_POINT_IDENT vi,
        SUP_SCH.ACC_PAYMENT_MODE MO, SUP_SCH.ACC_ACCOUNT A
        WHERE 1=1
        AND V.FK_CUST_ID = A.FK_CUST_ID
        AND A.ID = MO.FK_ACCNT_ID
        AND A.FK_CUST_ID = C.ID
        AND vi.FK_VCLAP_ID = vap.ID
        AND vap.FK_VCLVC_ID = v.id
                AND C.ID = v.FK_CUST_ID
                AND vi.FINAL_DATE is null
                AND N.FK_CUST_ID = C.ID
                AND N.ID = CP.FK_SVCTR_ID 
                AND CP.FK_PRDCT_ID = P.ID
                AND A.REAL_BALANCE < 0
                AND MO.PAY_MODE = 4	
                AND A.RECHARGE_VALUE = '100'
                AND C.PERSON_TYPE = 1
                        AND not exists(select 1 from CNT_CONTRACTED_PROD_STATUS_HIS CTSTH, CNT_CONTRACTED_PRODUCT CP, CNT_CONTRACT N, CAT_PRODUCT P
                        where CTSTH.FK_CTPRD_ID = CP.ID 
                        AND CP.FK_PRDCT_ID = P.ID
                        AND N.ID = CP.FK_SVCTR_ID
                        AND N.FK_CUST_ID = C.ID
                        AND CTSTH.FK_CNTST_ID in (2,3) AND CTSTH.VALIDITY_END_DATE IS NULL)
        AND ROWNUM < 2
")
while response = (cursor.fetch())
    return response
end

cursor.close
@connection.logoff 
end

def buscar_pf_pre_debito_inadimplente_periodico
    conectar_banco_dados
    cursor = @connection.exec("
        SELECT 
        (SELECT CC.NRC FROM SUP_SCH.CST_CUSTOMER_COMPANY CC WHERE C.ID = CC.FK_CUST_ID) AS NRC
        FROM 
        SUP_SCH.CST_CUSTOMER C, SUP_SCH.CNT_CONTRACT N, SUP_SCH.CAT_PRODUCT P, SUP_SCH.CNT_CONTRACTED_PRODUCT CP,
        VCL_VEHICLE v, VCL_VEHICLE_ACCESS_POINT vap, VCL_VEHICLE_ACCESS_POINT_IDENT vi,
        SUP_SCH.ACC_PAYMENT_MODE MO, SUP_SCH.ACC_ACCOUNT A
        WHERE 1=1
        AND V.FK_CUST_ID = A.FK_CUST_ID
        AND A.ID = MO.FK_ACCNT_ID
        AND A.FK_CUST_ID = C.ID
        AND vi.FK_VCLAP_ID = vap.ID
        AND vap.FK_VCLVC_ID = v.id
                AND C.ID = v.FK_CUST_ID
                AND vi.FINAL_DATE is null
                AND N.FK_CUST_ID = C.ID
                AND N.ID = CP.FK_SVCTR_ID 
                AND CP.FK_PRDCT_ID = P.ID
                AND A.REAL_BALANCE > 0
                AND MO.PAY_MODE = 4	
                AND A.RECHARGE_VALUE = '50'
                AND C.PERSON_TYPE = 1
                        AND not exists(select 1 from CNT_CONTRACTED_PROD_STATUS_HIS CTSTH, CNT_CONTRACTED_PRODUCT CP, CNT_CONTRACT N, CAT_PRODUCT P
                        where CTSTH.FK_CTPRD_ID = CP.ID 
                        AND CP.FK_PRDCT_ID = P.ID
                        AND N.ID = CP.FK_SVCTR_ID
                        AND N.FK_CUST_ID = C.ID
                        AND CTSTH.FK_CNTST_ID in (2,3) AND CTSTH.VALIDITY_END_DATE IS NULL)
        AND ROWNUM < 2
")
while response = (cursor.fetch())
    return response
end

cursor.close
@connection.logoff 
end


def buscar_pf_pre_cartao_periodico
    conectar_banco_dados
    cursor = @connection.exec("
        SELECT 
        (SELECT CC.NRC FROM SUP_SCH.CST_CUSTOMER_COMPANY CC WHERE C.ID = CC.FK_CUST_ID) AS NRC
        FROM 
        SUP_SCH.CST_CUSTOMER C, SUP_SCH.CNT_CONTRACT N, SUP_SCH.CAT_PRODUCT P, SUP_SCH.CNT_CONTRACTED_PRODUCT CP,
        VCL_VEHICLE v, VCL_VEHICLE_ACCESS_POINT vap, VCL_VEHICLE_ACCESS_POINT_IDENT vi,
        SUP_SCH.ACC_PAYMENT_MODE MO, SUP_SCH.ACC_ACCOUNT A
        WHERE 1=1
        AND V.FK_CUST_ID = A.FK_CUST_ID
        AND A.ID = MO.FK_ACCNT_ID
        AND A.FK_CUST_ID = C.ID
        AND vi.FK_VCLAP_ID = vap.ID
        AND vap.FK_VCLVC_ID = v.id
                AND C.ID = v.FK_CUST_ID
                AND vi.FINAL_DATE is null
                AND N.FK_CUST_ID = C.ID
                AND N.ID = CP.FK_SVCTR_ID 
                AND CP.FK_PRDCT_ID = P.ID
                AND P.ID not in ('100322004','100322007','100372000','100582000','100582002','100814000','101014000')
                AND a.real_balance < 0
                AND MO.PAY_MODE = 3
                AND C.PERSON_TYPE = 1
                and A.RECHARGE_VALUE = 150
                        AND not exists(select 1 from CNT_CONTRACTED_PROD_STATUS_HIS CTSTH, CNT_CONTRACTED_PRODUCT CP, CNT_CONTRACT N, CAT_PRODUCT P
                        where CTSTH.FK_CTPRD_ID = CP.ID 
                        AND CP.FK_PRDCT_ID = P.ID
                        AND N.ID = CP.FK_SVCTR_ID
                        AND N.FK_CUST_ID = C.ID
                        AND CTSTH.FK_CNTST_ID in (2,3) AND CTSTH.VALIDITY_END_DATE IS NULL)
                AND ROWNUM < 2
            ")
            while response = (cursor.fetch())
                return response
            end

            cursor.close
            @connection.logoff 
end



def buscar_pj_pre_debito_periodico
    conectar_banco_dados
    cursor = @connection.exec("
        SELECT 
        (SELECT CC.NRC FROM SUP_SCH.CST_CUSTOMER_COMPANY CC WHERE C.ID = CC.FK_CUST_ID) AS NRC
        FROM 
        SUP_SCH.CST_CUSTOMER C, SUP_SCH.CNT_CONTRACT N, SUP_SCH.CAT_PRODUCT P, SUP_SCH.CNT_CONTRACTED_PRODUCT CP,
        VCL_VEHICLE v, VCL_VEHICLE_ACCESS_POINT vap, VCL_VEHICLE_ACCESS_POINT_IDENT vi,
        SUP_SCH.ACC_PAYMENT_MODE MO, SUP_SCH.ACC_ACCOUNT A
        WHERE 1=1
        AND V.FK_CUST_ID = A.FK_CUST_ID
        AND A.ID = MO.FK_ACCNT_ID
        AND A.FK_CUST_ID = C.ID
        AND vi.FK_VCLAP_ID = vap.ID
        AND vap.FK_VCLVC_ID = v.id
                AND C.ID = v.FK_CUST_ID
                AND vi.FINAL_DATE is null
                AND N.FK_CUST_ID = C.ID
                AND N.ID = CP.FK_SVCTR_ID 
                AND CP.FK_PRDCT_ID = P.ID
                AND a.real_balance < 0
                AND MO.PAY_MODE = 4
                AND C.PERSON_TYPE = 2
                AND A.RECHARGE_VALUE = 500
                        AND not exists(select 1 from CNT_CONTRACTED_PROD_STATUS_HIS CTSTH, CNT_CONTRACTED_PRODUCT CP, CNT_CONTRACT N, CAT_PRODUCT P
                        where CTSTH.FK_CTPRD_ID = CP.ID 
                        AND CP.FK_PRDCT_ID = P.ID
                        AND N.ID = CP.FK_SVCTR_ID
                        AND N.FK_CUST_ID = C.ID
                        AND CTSTH.FK_CNTST_ID in (2,3) AND CTSTH.VALIDITY_END_DATE IS NULL)
                AND ROWNUM < 2
            ")
            while response = (cursor.fetch())
                return response
            end

            cursor.close
            @connection.logoff 
end


def buscar_pj_pre_debito_periodico_reduzir
    conectar_banco_dados
    cursor = @connection.exec("
        SELECT 
        (SELECT CC.NRC FROM SUP_SCH.CST_CUSTOMER_COMPANY CC WHERE C.ID = CC.FK_CUST_ID) AS NRC
        FROM 
        SUP_SCH.CST_CUSTOMER C, SUP_SCH.CNT_CONTRACT N, SUP_SCH.CAT_PRODUCT P, SUP_SCH.CNT_CONTRACTED_PRODUCT CP,
        VCL_VEHICLE v, VCL_VEHICLE_ACCESS_POINT vap, VCL_VEHICLE_ACCESS_POINT_IDENT vi,
        SUP_SCH.ACC_PAYMENT_MODE MO, SUP_SCH.ACC_ACCOUNT A
        WHERE 1=1
        AND V.FK_CUST_ID = A.FK_CUST_ID
        AND A.ID = MO.FK_ACCNT_ID
        AND A.FK_CUST_ID = C.ID
        AND vi.FK_VCLAP_ID = vap.ID
        AND vap.FK_VCLVC_ID = v.id
                AND C.ID = v.FK_CUST_ID
                AND vi.FINAL_DATE is null
                AND N.FK_CUST_ID = C.ID
                AND N.ID = CP.FK_SVCTR_ID 
                AND CP.FK_PRDCT_ID = P.ID
                AND MO.PAY_MODE = 4
                AND C.PERSON_TYPE = 2
                AND A.RECHARGE_VALUE = 2000
                        AND not exists(select 1 from CNT_CONTRACTED_PROD_STATUS_HIS CTSTH, CNT_CONTRACTED_PRODUCT CP, CNT_CONTRACT N, CAT_PRODUCT P
                        where CTSTH.FK_CTPRD_ID = CP.ID 
                        AND CP.FK_PRDCT_ID = P.ID
                        AND N.ID = CP.FK_SVCTR_ID
                        AND N.FK_CUST_ID = C.ID
                        AND CTSTH.FK_CNTST_ID in (2,3) AND CTSTH.VALIDITY_END_DATE IS NULL)
                AND ROWNUM < 2
            ")
            while response = (cursor.fetch())
                return response
            end

            cursor.close
            @connection.logoff 
end

def buscar_pj_carga_programada_periodico
    conectar_banco_dados
    cursor = @connection.exec("
        SELECT 
        (SELECT CC.NRC FROM SUP_SCH.CST_CUSTOMER_COMPANY CC WHERE C.ID = CC.FK_CUST_ID) AS NRC
        FROM 
        SUP_SCH.CST_CUSTOMER C, SUP_SCH.CNT_CONTRACT N, SUP_SCH.CAT_PRODUCT P, SUP_SCH.CNT_CONTRACTED_PRODUCT CP,
        VCL_VEHICLE v, VCL_VEHICLE_ACCESS_POINT vap, VCL_VEHICLE_ACCESS_POINT_IDENT vi,
        SUP_SCH.ACC_PAYMENT_MODE MO, SUP_SCH.ACC_ACCOUNT A
        WHERE 1=1
        AND V.FK_CUST_ID = A.FK_CUST_ID
        AND A.ID = MO.FK_ACCNT_ID
        AND A.FK_CUST_ID = C.ID
        AND vi.FK_VCLAP_ID = vap.ID
        AND vap.FK_VCLVC_ID = v.id
                AND C.ID = v.FK_CUST_ID
                AND vi.FINAL_DATE is null
                AND N.FK_CUST_ID = C.ID
                AND N.ID = CP.FK_SVCTR_ID 
                AND CP.FK_PRDCT_ID = P.ID
                AND a.real_balance < 0
                AND MO.PAY_MODE = 6
                AND C.PERSON_TYPE = 2
                AND A.RECHARGE_VALUE = 1500
                        AND not exists(select 1 from CNT_CONTRACTED_PROD_STATUS_HIS CTSTH, CNT_CONTRACTED_PRODUCT CP, CNT_CONTRACT N, CAT_PRODUCT P
                        where CTSTH.FK_CTPRD_ID = CP.ID 
                        AND CP.FK_PRDCT_ID = P.ID
                        AND N.ID = CP.FK_SVCTR_ID
                        AND N.FK_CUST_ID = C.ID
                        AND CTSTH.FK_CNTST_ID in (2,3) AND CTSTH.VALIDITY_END_DATE IS NULL)
                AND ROWNUM < 2
            ")
            while response = (cursor.fetch())
                return response
            end

            cursor.close
            @connection.logoff 
end


def buscar_pj_carga_programada_periodico_reduzir
    conectar_banco_dados
    cursor = @connection.exec("
        SELECT 
        (SELECT CC.NRC FROM SUP_SCH.CST_CUSTOMER_COMPANY CC WHERE C.ID = CC.FK_CUST_ID) AS NRC
        FROM 
        SUP_SCH.CST_CUSTOMER C, SUP_SCH.CNT_CONTRACT N, SUP_SCH.CAT_PRODUCT P, SUP_SCH.CNT_CONTRACTED_PRODUCT CP,
        VCL_VEHICLE v, VCL_VEHICLE_ACCESS_POINT vap, VCL_VEHICLE_ACCESS_POINT_IDENT vi,
        SUP_SCH.ACC_PAYMENT_MODE MO, SUP_SCH.ACC_ACCOUNT A
        WHERE 1=1
        AND V.FK_CUST_ID = A.FK_CUST_ID
        AND A.ID = MO.FK_ACCNT_ID
        AND A.FK_CUST_ID = C.ID
        AND vi.FK_VCLAP_ID = vap.ID
        AND vap.FK_VCLVC_ID = v.id
                AND C.ID = v.FK_CUST_ID
                AND vi.FINAL_DATE is null
                AND N.FK_CUST_ID = C.ID
                AND N.ID = CP.FK_SVCTR_ID 
                AND CP.FK_PRDCT_ID = P.ID
                AND MO.PAY_MODE = 6
                AND C.PERSON_TYPE = 2
                AND A.RECHARGE_VALUE = 2000
                        AND not exists(select 1 from CNT_CONTRACTED_PROD_STATUS_HIS CTSTH, CNT_CONTRACTED_PRODUCT CP, CNT_CONTRACT N, CAT_PRODUCT P
                        where CTSTH.FK_CTPRD_ID = CP.ID 
                        AND CP.FK_PRDCT_ID = P.ID
                        AND N.ID = CP.FK_SVCTR_ID
                        AND N.FK_CUST_ID = C.ID
                        AND CTSTH.FK_CNTST_ID in (2,3) AND CTSTH.VALIDITY_END_DATE IS NULL)
                AND ROWNUM < 2
            ")
            while response = (cursor.fetch())
                return response
            end

            cursor.close
            @connection.logoff 
end

def buscar_pj_pre_debito_periodico_media_fat
    conectar_banco_dados
    cursor = @connection.exec("
        SELECT 
        (SELECT CC.NRC FROM SUP_SCH.CST_CUSTOMER_COMPANY CC WHERE C.ID = CC.FK_CUST_ID) AS NRC
        FROM 
        SUP_SCH.CST_CUSTOMER C, SUP_SCH.CNT_CONTRACT N, SUP_SCH.CAT_PRODUCT P, SUP_SCH.CNT_CONTRACTED_PRODUCT CP,
        VCL_VEHICLE v, VCL_VEHICLE_ACCESS_POINT vap, VCL_VEHICLE_ACCESS_POINT_IDENT vi,
        SUP_SCH.ACC_PAYMENT_MODE MO, SUP_SCH.ACC_ACCOUNT A
        WHERE 1=1
        AND V.FK_CUST_ID = A.FK_CUST_ID
        AND A.ID = MO.FK_ACCNT_ID
        AND A.FK_CUST_ID = C.ID
        AND vi.FK_VCLAP_ID = vap.ID
        AND vap.FK_VCLVC_ID = v.id
                AND C.ID = v.FK_CUST_ID
                AND vi.FINAL_DATE is null
                AND N.FK_CUST_ID = C.ID
                AND N.ID = CP.FK_SVCTR_ID 
                AND CP.FK_PRDCT_ID = P.ID
                AND a.real_balance < 0
                AND MO.PAY_MODE = 4
                AND C.PERSON_TYPE = 2
                AND A.RECHARGE_VALUE = 2500
                        AND not exists(select 1 from CNT_CONTRACTED_PROD_STATUS_HIS CTSTH, CNT_CONTRACTED_PRODUCT CP, CNT_CONTRACT N, CAT_PRODUCT P
                        where CTSTH.FK_CTPRD_ID = CP.ID 
                        AND CP.FK_PRDCT_ID = P.ID
                        AND N.ID = CP.FK_SVCTR_ID
                        AND N.FK_CUST_ID = C.ID
                        AND CTSTH.FK_CNTST_ID in (2,3) AND CTSTH.VALIDITY_END_DATE IS NULL)
                AND ROWNUM < 2
            ")
            while response = (cursor.fetch())
                return response
            end

            cursor.close
            @connection.logoff 
end



def buscar_cliente_pf_pos_debito_forma_pagamento_sem_alterar_plano
    conectar_banco_dados
    cursor = @connection.exec("
        SELECT 
  (SELECT CC.NRC FROM SUP_SCH.CST_CUSTOMER_COMPANY CC WHERE C.ID = CC.FK_CUST_ID) AS NRC
  FROM 
  SUP_SCH.CST_CUSTOMER C, SUP_SCH.CNT_CONTRACT N, SUP_SCH.CAT_PRODUCT P, SUP_SCH.CNT_CONTRACTED_PRODUCT CP,
  VCL_VEHICLE v, VCL_VEHICLE_ACCESS_POINT vap, VCL_VEHICLE_ACCESS_POINT_IDENT vi,
  SUP_SCH.ACC_PAYMENT_MODE MO, SUP_SCH.ACC_ACCOUNT A
  WHERE 1=1
  AND V.FK_CUST_ID = A.FK_CUST_ID
  AND A.ID = MO.FK_ACCNT_ID
  AND A.FK_CUST_ID = C.ID
  AND vi.FK_VCLAP_ID = vap.ID
  AND vap.FK_VCLVC_ID = v.id
        AND C.ID = v.FK_CUST_ID
        AND vi.FINAL_DATE is null
        AND N.FK_CUST_ID = C.ID
        AND N.ID = CP.FK_SVCTR_ID 
        AND CP.FK_PRDCT_ID = P.ID
        and A.FK_ACCTP_ID = 1 
        and a.real_balance < 0
        and P.ID <> '100046000' --Plano ADESÃO ZERO II
        AND MO.PAY_MODE = 2
        AND C.PERSON_TYPE = 1
                  AND not exists(select 1 from CNT_CONTRACTED_PROD_STATUS_HIS CTSTH, CNT_CONTRACTED_PRODUCT CP, CNT_CONTRACT N, CAT_PRODUCT P
                  where CTSTH.FK_CTPRD_ID = CP.ID 
                   AND CP.FK_PRDCT_ID = P.ID
                  AND N.ID = CP.FK_SVCTR_ID
                  AND N.FK_CUST_ID = C.ID
                  AND CTSTH.FK_CNTST_ID in (2,3) AND CTSTH.VALIDITY_END_DATE IS NULL)
        AND ROWNUM < 2 
        ")
        while response = (cursor.fetch())
            return response
        end

        cursor.close
        @connection.logoff 
end



def buscar_cliente_pf_pos_debito_forma_pagamento_alterando_plano
    conectar_banco_dados
    cursor = @connection.exec("
        SELECT 
  (SELECT CC.NRC FROM SUP_SCH.CST_CUSTOMER_COMPANY CC WHERE C.ID = CC.FK_CUST_ID) AS NRC
  FROM 
  SUP_SCH.CST_CUSTOMER C, SUP_SCH.CNT_CONTRACT N, SUP_SCH.CAT_PRODUCT P, SUP_SCH.CNT_CONTRACTED_PRODUCT CP,
  VCL_VEHICLE v, VCL_VEHICLE_ACCESS_POINT vap, VCL_VEHICLE_ACCESS_POINT_IDENT vi,
  SUP_SCH.ACC_PAYMENT_MODE MO, SUP_SCH.ACC_ACCOUNT A
  WHERE 1=1
  AND V.FK_CUST_ID = A.FK_CUST_ID
  AND A.ID = MO.FK_ACCNT_ID
  AND A.FK_CUST_ID = C.ID
  AND vi.FK_VCLAP_ID = vap.ID
  AND vap.FK_VCLVC_ID = v.id
        AND C.ID = v.FK_CUST_ID
        AND vi.FINAL_DATE is null
        AND N.FK_CUST_ID = C.ID
        AND N.ID = CP.FK_SVCTR_ID 
        AND CP.FK_PRDCT_ID = P.ID
        and A.FK_ACCTP_ID = 1 
        and a.real_balance < 0
        and P.ID = '102074000' --EM TODO LUGAR FLEX 4 - PÓS  PAGO
        AND MO.PAY_MODE = 2
        AND C.PERSON_TYPE = 1
                  AND not exists(select 1 from CNT_CONTRACTED_PROD_STATUS_HIS CTSTH, CNT_CONTRACTED_PRODUCT CP, CNT_CONTRACT N, CAT_PRODUCT P
                  where CTSTH.FK_CTPRD_ID = CP.ID 
                   AND CP.FK_PRDCT_ID = P.ID
                  AND N.ID = CP.FK_SVCTR_ID
                  AND N.FK_CUST_ID = C.ID
                  AND CTSTH.FK_CNTST_ID in (2,3,4) AND CTSTH.VALIDITY_END_DATE IS NULL)
        AND ROWNUM < 2
        ")
        while response = (cursor.fetch())
            return response
        end

        cursor.close
        @connection.logoff 
end


        def buscar_cliente_sem_veiculo_ativo
            conectar_banco_dados
            cursor = @connection.exec("
                SELECT 
                (SELECT CC.NRC FROM SUP_SCH.CST_CUSTOMER_COMPANY CC WHERE C.ID = CC.FK_CUST_ID) AS NRC
                FROM 
                SUP_SCH.CST_CUSTOMER C, SUP_SCH.CNT_CONTRACT N, SUP_SCH.CAT_PRODUCT P, SUP_SCH.CNT_CONTRACTED_PRODUCT CP,
                VCL_VEHICLE v, VCL_VEHICLE_ACCESS_POINT vap, VCL_VEHICLE_ACCESS_POINT_IDENT vi,
                SUP_SCH.ACC_PAYMENT_MODE MO, SUP_SCH.ACC_ACCOUNT A
                WHERE 1=1
                AND V.FK_CUST_ID = A.FK_CUST_ID
                AND A.ID = MO.FK_ACCNT_ID
                AND A.FK_CUST_ID = C.ID
                AND vi.FK_VCLAP_ID = vap.ID
                AND vap.FK_VCLVC_ID = v.id
                        AND C.ID = v.FK_CUST_ID
                        AND vi.FINAL_DATE is not null                       
                AND N.FK_CUST_ID = C.ID
                AND N.ID = CP.FK_SVCTR_ID
                AND CP.FK_PRDCT_ID = P.ID
                --AND P.ID = '100192017'	--SEM PARAR AUTOMÁTICO - CARTÃO
                    AND exists(select 1 from CNT_CONTRACTED_PROD_STATUS_HIS CTSTH, CNT_CONTRACTED_PRODUCT CP, SUP_SCH.CNT_CONTRACT N
                    where CTSTH.FK_CTPRD_ID = CP.ID 
                    AND N.ID = CP.FK_SVCTR_ID
                    AND N.FK_CUST_ID = C.ID
                    AND CTSTH.FK_CNTST_ID = 1 AND CTSTH.VALIDITY_END_DATE IS not NULL)
                        AND not exists(select 1 from CNT_CONTRACTED_PROD_STATUS_HIS CTSTH, CNT_CONTRACTED_PRODUCT CP, SUP_SCH.CNT_CONTRACT N
                        where CTSTH.FK_CTPRD_ID = CP.ID 
                        AND N.ID = CP.FK_SVCTR_ID
                        AND N.FK_CUST_ID = C.ID
                        AND CTSTH.FK_CNTST_ID = 3)
                            AND not exists(select 1 from CNT_CONTRACTED_PROD_STATUS_HIS CTSTH, CNT_CONTRACTED_PRODUCT CP, SUP_SCH.CNT_CONTRACT N
                            where CTSTH.FK_CTPRD_ID = CP.ID 
                            AND N.ID = CP.FK_SVCTR_ID
                            AND N.FK_CUST_ID = C.ID
                            AND CTSTH.FK_CNTST_ID = 1 AND CTSTH.VALIDITY_END_DATE IS NULL)
                AND ROWNUM < 2
                ")
            while response = (cursor.fetch())
                return response
            end

            cursor.close
            @connection.logoff 
        end
        
            

        def buscar_cliente_inadimplente

            conectar_banco_dados

                cursor = @connection.exec("
                    SELECT 
                    (SELECT CC.NRC FROM SUP_SCH.CST_CUSTOMER_COMPANY CC WHERE C.ID = CC.FK_CUST_ID) AS NRC
                    FROM 
                    SUP_SCH.CST_CUSTOMER C, SUP_SCH.CNT_CONTRACT N, SUP_SCH.CAT_PRODUCT P, SUP_SCH.CNT_CONTRACTED_PRODUCT CP,
                    VCL_VEHICLE v, VCL_VEHICLE_ACCESS_POINT vap, VCL_VEHICLE_ACCESS_POINT_IDENT vi,
                    SUP_SCH.ACC_PAYMENT_MODE MO, SUP_SCH.ACC_ACCOUNT A
                    WHERE 1=1
                    AND V.FK_CUST_ID = A.FK_CUST_ID
                    AND A.ID = MO.FK_ACCNT_ID
                    AND A.FK_CUST_ID = C.ID
                    AND vi.FK_VCLAP_ID = vap.ID
                    AND vap.FK_VCLVC_ID = v.id
                        AND C.ID = v.FK_CUST_ID
                        AND vi.FINAL_DATE is not null
                        AND N.FK_CUST_ID = C.ID
                        AND N.ID = CP.FK_SVCTR_ID
                        AND CP.FK_PRDCT_ID = P.ID
                            AND exists(select 1 from CNT_CONTRACTED_PROD_STATUS_HIS CTSTH, CNT_CONTRACTED_PRODUCT CP, SUP_SCH.CNT_CONTRACT N, CAT_PRODUCT P
                                where CTSTH.FK_CTPRD_ID = CP.ID 
                                AND CP.FK_PRDCT_ID = P.ID
                                AND N.ID = CP.FK_SVCTR_ID
                                AND N.FK_CUST_ID = C.ID
                                AND CTSTH.FK_CNTST_ID = 3 AND CTSTH.VALIDITY_END_DATE IS NULL)
                        AND ROWNUM < 2
                ")

                while response = (cursor.fetch())
                    return response
                end

                cursor.close
                @connection.logoff 
        end


        def buscar_cliente_pj_pre

            conectar_banco_dados

                cursor = @connection.exec("
                    SELECT 
                    (SELECT CC.NRC FROM SUP_SCH.CST_CUSTOMER_COMPANY CC WHERE C.ID = CC.FK_CUST_ID) AS NRC
                    FROM 
                    SUP_SCH.CST_CUSTOMER C, SUP_SCH.CNT_CONTRACT N, SUP_SCH.CAT_PRODUCT P, SUP_SCH.CNT_CONTRACTED_PRODUCT CP,
                    VCL_VEHICLE v, VCL_VEHICLE_ACCESS_POINT vap, VCL_VEHICLE_ACCESS_POINT_IDENT vi,
                    SUP_SCH.ACC_PAYMENT_MODE MO, SUP_SCH.ACC_ACCOUNT A
                    WHERE 1=1
                    AND V.FK_CUST_ID = A.FK_CUST_ID
                    AND A.ID = MO.FK_ACCNT_ID
                    AND A.FK_CUST_ID = C.ID
                    AND vi.FK_VCLAP_ID = vap.ID
                    AND vap.FK_VCLVC_ID = v.id
                            AND C.ID = v.FK_CUST_ID
                            AND vi.FINAL_DATE is null
                            AND N.FK_CUST_ID = C.ID
                            AND N.ID = CP.FK_SVCTR_ID 
                            AND CP.FK_PRDCT_ID = P.ID
                            AND A.REAL_BALANCE < 0
                            AND MO.PAY_MODE = 4
                            AND C.PERSON_TYPE = 2
                            and A.FK_ACCTP_ID = 1   --1 USUARIO
                                    AND not exists(select 1 from CNT_CONTRACTED_PROD_STATUS_HIS CTSTH, CNT_CONTRACTED_PRODUCT CP, CNT_CONTRACT N, CAT_PRODUCT P
                                    where CTSTH.FK_CTPRD_ID = CP.ID 
                                    AND CP.FK_PRDCT_ID = P.ID
                                    AND N.ID = CP.FK_SVCTR_ID
                                    AND N.FK_CUST_ID = C.ID
                                    AND CTSTH.FK_CNTST_ID in (2,3) AND CTSTH.VALIDITY_END_DATE IS NULL)
                    AND ROWNUM < 2
            ")

            while response = (cursor.fetch())
                return response
            end

            cursor.close
            @connection.logoff 
        end


        def buscar_cliente_pj_pos

            conectar_banco_dados

                cursor = @connection.exec("
                    SELECT 
                    (SELECT CC.NRC FROM SUP_SCH.CST_CUSTOMER_COMPANY CC WHERE C.ID = CC.FK_CUST_ID) AS NRC
                    FROM 
                    SUP_SCH.CST_CUSTOMER C, SUP_SCH.CNT_CONTRACT N, SUP_SCH.CAT_PRODUCT P, SUP_SCH.CNT_CONTRACTED_PRODUCT CP,
                    VCL_VEHICLE v, VCL_VEHICLE_ACCESS_POINT vap, VCL_VEHICLE_ACCESS_POINT_IDENT vi,
                    SUP_SCH.ACC_PAYMENT_MODE MO, SUP_SCH.ACC_ACCOUNT A
                    WHERE 1=1
                    AND V.FK_CUST_ID = A.FK_CUST_ID
                    AND A.ID = MO.FK_ACCNT_ID
                    AND A.FK_CUST_ID = C.ID
                    AND vi.FK_VCLAP_ID = vap.ID
                    AND vap.FK_VCLVC_ID = v.id
                            AND C.ID = v.FK_CUST_ID
                            AND vi.FINAL_DATE is null
                            AND N.FK_CUST_ID = C.ID
                            AND N.ID = CP.FK_SVCTR_ID 
                            AND CP.FK_PRDCT_ID = P.ID
                            AND A.REAL_BALANCE < 0
                            AND MO.PAY_MODE = 2
                            AND C.PERSON_TYPE = 2
                            and A.FK_ACCTP_ID = 1   --1 USUARIO
                                    AND not exists(select 1 from CNT_CONTRACTED_PROD_STATUS_HIS CTSTH, CNT_CONTRACTED_PRODUCT CP, CNT_CONTRACT N, CAT_PRODUCT P
                                    where CTSTH.FK_CTPRD_ID = CP.ID 
                                    AND CP.FK_PRDCT_ID = P.ID
                                    AND N.ID = CP.FK_SVCTR_ID
                                    AND N.FK_CUST_ID = C.ID
                                    AND CTSTH.FK_CNTST_ID in (2,3) AND CTSTH.VALIDITY_END_DATE IS NULL)
                    AND ROWNUM < 2
            ")

            while response = (cursor.fetch())
                return response
            end

            cursor.close
            @connection.logoff 
        end
        

            def buscar_cliente_sem_promocao
                
                conectar_banco_dados

                cursor = @connection.exec("
                    SELECT 
                    (SELECT CC.NRC FROM SUP_SCH.CST_CUSTOMER_COMPANY CC WHERE C.ID = CC.FK_CUST_ID) AS NRC
                    FROM 
                    SUP_SCH.CST_CUSTOMER C, SUP_SCH.CNT_CONTRACT N, SUP_SCH.CAT_PRODUCT P, SUP_SCH.CNT_CONTRACTED_PRODUCT CP,
                    VCL_VEHICLE v, VCL_VEHICLE_ACCESS_POINT vap, VCL_VEHICLE_ACCESS_POINT_IDENT vi,
                    SUP_SCH.ACC_PAYMENT_MODE MO, SUP_SCH.ACC_ACCOUNT A
                    WHERE 1=1
                    AND V.FK_CUST_ID = A.FK_CUST_ID
                    AND A.ID = MO.FK_ACCNT_ID
                    AND A.FK_CUST_ID = C.ID
                    AND vi.FK_VCLAP_ID = vap.ID
                    AND vap.FK_VCLVC_ID = v.id
                          AND C.ID = v.FK_CUST_ID
                          AND vi.FINAL_DATE is null
                          AND N.FK_CUST_ID = C.ID
                          AND N.ID = CP.FK_SVCTR_ID 
                          AND CP.FK_PRDCT_ID = P.ID
                          AND A.REAL_BALANCE < 0
                          and C.PERSON_TYPE = 1
                          and MO.PAY_MODE = 2
                              AND not exists(select 1 from CNT_CONTRACTED_PROD_STATUS_HIS CTSTH, SUP_SCH.CNT_CONTRACT N, SUP_SCH.CAT_PRODUCT P, SUP_SCH.CNT_CONTRACTED_PRODUCT CP
                              where CTSTH.FK_CTPRD_ID = CP.ID 
                              AND CP.FK_PRDCT_ID = P.ID
                              AND N.ID = CP.FK_SVCTR_ID
                              AND N.FK_CUST_ID = C.ID
                              AND CTSTH.FK_CNTST_ID in (2,3) AND CTSTH.VALIDITY_END_DATE IS NULL)
                                    and not exists(select 1 from SUP_SCH.CNT_CONTRACT N, SUP_SCH.CAT_PRODUCT P, SUP_SCH.CNT_CONTRACTED_PRODUCT CP
                                    where N.ID = CP.FK_SVCTR_ID 
                                    AND CP.FK_PRDCT_ID = P.ID
                                    AND N.FK_CUST_ID = C.ID
                                    and CP.CONTRACTED_PRODUCT_TYPE in (2,5))
                                    and rownum < 2
            ")

            while response = (cursor.fetch())
                return response
            end

            cursor.close
            @connection.logoff 
                
            end

            def buscar_cliente_sem_produto_suplementar
                
                conectar_banco_dados

                cursor = @connection.exec("
                    SELECT 
                    (SELECT CC.NRC FROM SUP_SCH.CST_CUSTOMER_COMPANY CC WHERE C.ID = CC.FK_CUST_ID) AS NRC
                    FROM 
                    SUP_SCH.CST_CUSTOMER C, SUP_SCH.CNT_CONTRACT N, SUP_SCH.CAT_PRODUCT P, SUP_SCH.CNT_CONTRACTED_PRODUCT CP,
                    VCL_VEHICLE v, VCL_VEHICLE_ACCESS_POINT vap, VCL_VEHICLE_ACCESS_POINT_IDENT vi,
                    SUP_SCH.ACC_PAYMENT_MODE MO, SUP_SCH.ACC_ACCOUNT A
                    WHERE 1=1
                    AND V.FK_CUST_ID = A.FK_CUST_ID
                    AND A.ID = MO.FK_ACCNT_ID
                    AND A.FK_CUST_ID = C.ID
                    AND vi.FK_VCLAP_ID = vap.ID
                    AND vap.FK_VCLVC_ID = v.id
                          AND C.ID = v.FK_CUST_ID
                          AND vi.FINAL_DATE is null
                          AND N.FK_CUST_ID = C.ID
                          AND N.ID = CP.FK_SVCTR_ID 
                          AND CP.FK_PRDCT_ID = P.ID
                          AND A.REAL_BALANCE < 0
                          and C.PERSON_TYPE = 1
                              AND not exists(select 1 from CNT_CONTRACTED_PROD_STATUS_HIS CTSTH, SUP_SCH.CNT_CONTRACT N, SUP_SCH.CAT_PRODUCT P, SUP_SCH.CNT_CONTRACTED_PRODUCT CP
                              where CTSTH.FK_CTPRD_ID = CP.ID 
                              AND CP.FK_PRDCT_ID = P.ID
                              AND N.ID = CP.FK_SVCTR_ID
                              AND N.FK_CUST_ID = C.ID
                              AND CTSTH.FK_CNTST_ID in (2,3) AND CTSTH.VALIDITY_END_DATE IS NULL)
                                    and not exists(select 1 from SUP_SCH.CNT_CONTRACT N, SUP_SCH.CAT_PRODUCT P, SUP_SCH.CNT_CONTRACTED_PRODUCT CP
                                    where N.ID = CP.FK_SVCTR_ID 
                                    AND CP.FK_PRDCT_ID = P.ID
                                    AND N.FK_CUST_ID = C.ID
                                    and CP.CONTRACTED_PRODUCT_TYPE = 2)
                                    and rownum < 2
            ")

            while response = (cursor.fetch())
                return response
            end

            cursor.close
            @connection.logoff 
                
            end


            def buscar_cliente_com_promocao
                
                conectar_banco_dados

                cursor = @connection.exec("
                    SELECT 
            (SELECT CC.NRC FROM SUP_SCH.CST_CUSTOMER_COMPANY CC WHERE C.ID = CC.FK_CUST_ID) AS NRC
            FROM 
            SUP_SCH.CST_CUSTOMER C, SUP_SCH.CNT_CONTRACT N, SUP_SCH.CAT_PRODUCT P, SUP_SCH.CNT_CONTRACTED_PRODUCT CP,
            VCL_VEHICLE v, VCL_VEHICLE_ACCESS_POINT vap, VCL_VEHICLE_ACCESS_POINT_IDENT vi,
            SUP_SCH.ACC_PAYMENT_MODE MO, SUP_SCH.ACC_ACCOUNT A
            WHERE 1=1
            AND V.FK_CUST_ID = A.FK_CUST_ID
            AND A.ID = MO.FK_ACCNT_ID
            AND A.FK_CUST_ID = C.ID
            AND vi.FK_VCLAP_ID = vap.ID
            AND vap.FK_VCLVC_ID = v.id
                  AND C.ID = v.FK_CUST_ID
                  AND vi.FINAL_DATE is null
                  AND N.FK_CUST_ID = C.ID
                  AND N.ID = CP.FK_SVCTR_ID 
                  AND CP.FK_PRDCT_ID = P.ID
                  AND A.REAL_BALANCE < 0
                  and C.PERSON_TYPE = 1
                      AND not exists(select 1 from CNT_CONTRACTED_PROD_STATUS_HIS CTSTH, SUP_SCH.CNT_CONTRACT N, SUP_SCH.CAT_PRODUCT P, SUP_SCH.CNT_CONTRACTED_PRODUCT CP
                      where CTSTH.FK_CTPRD_ID = CP.ID 
                      AND CP.FK_PRDCT_ID = P.ID
                      AND N.ID = CP.FK_SVCTR_ID
                      AND N.FK_CUST_ID = C.ID
                      AND CTSTH.FK_CNTST_ID in (2,3) AND CTSTH.VALIDITY_END_DATE IS NULL)
                            and exists(select 1 from SUP_SCH.CNT_CONTRACT N, SUP_SCH.CAT_PRODUCT P, SUP_SCH.CNT_CONTRACTED_PRODUCT CP
                            where N.ID = CP.FK_SVCTR_ID 
                            AND CP.FK_PRDCT_ID = P.ID
                            AND N.FK_CUST_ID = C.ID
                            and CP.CONTRACTED_PRODUCT_TYPE = 5)
                            and rownum < 2
            ")

            while response = (cursor.fetch())
                return response
            end

            cursor.close
            @connection.logoff 
                
            end

            def buscar_cliente_com_produto_suplementar
                
                conectar_banco_dados

                cursor = @connection.exec("
                    SELECT 
                    (SELECT CC.NRC FROM SUP_SCH.CST_CUSTOMER_COMPANY CC WHERE C.ID = CC.FK_CUST_ID) AS NRC
                    FROM 
                    SUP_SCH.CST_CUSTOMER C, SUP_SCH.CNT_CONTRACT N, SUP_SCH.CAT_PRODUCT P, SUP_SCH.CNT_CONTRACTED_PRODUCT CP,
                    VCL_VEHICLE v, VCL_VEHICLE_ACCESS_POINT vap, VCL_VEHICLE_ACCESS_POINT_IDENT vi,
                    SUP_SCH.ACC_PAYMENT_MODE MO, SUP_SCH.ACC_ACCOUNT A
                    WHERE 1=1
                    AND V.FK_CUST_ID = A.FK_CUST_ID
                    AND A.ID = MO.FK_ACCNT_ID
                    AND A.FK_CUST_ID = C.ID
                    AND vi.FK_VCLAP_ID = vap.ID
                    AND vap.FK_VCLVC_ID = v.id
                          AND C.ID = v.FK_CUST_ID
                          AND vi.FINAL_DATE is null
                          AND N.FK_CUST_ID = C.ID
                          AND N.ID = CP.FK_SVCTR_ID 
                          AND CP.FK_PRDCT_ID = P.ID
                          AND A.REAL_BALANCE < 0
                          and C.PERSON_TYPE = 1
                          and mo.pay_mode = 3
                              AND not exists(select 1 from CNT_CONTRACTED_PROD_STATUS_HIS CTSTH, SUP_SCH.CNT_CONTRACT N, SUP_SCH.CAT_PRODUCT P, SUP_SCH.CNT_CONTRACTED_PRODUCT CP
                              where CTSTH.FK_CTPRD_ID = CP.ID 
                              AND CP.FK_PRDCT_ID = P.ID
                              AND N.ID = CP.FK_SVCTR_ID
                              AND N.FK_CUST_ID = C.ID
                              AND CTSTH.FK_CNTST_ID in (2,3) AND CTSTH.VALIDITY_END_DATE IS NULL)
                                    and exists(select 1 from SUP_SCH.CNT_CONTRACT N, SUP_SCH.CAT_PRODUCT P, SUP_SCH.CNT_CONTRACTED_PRODUCT CP
                                    where N.ID = CP.FK_SVCTR_ID 
                                    AND CP.FK_PRDCT_ID = P.ID
                                    AND N.FK_CUST_ID = C.ID
                                    and CP.CONTRACTED_PRODUCT_TYPE = 2)
                                    and rownum < 2
            ")

            while response = (cursor.fetch())
                return response
            end

            cursor.close
            @connection.logoff 
                
            end

            def buscar_cliente_valor_disparo_zerado
                
                conectar_banco_dados

                cursor = @connection.exec("
                    select cusco.nrc               NRC
                    from cst_customer cust, 
                         cst_customer_company cusco, 
                         acc_account accnt, 
                         acc_payment_mode paymd, 
                         acc_product_account prdacc, 
                         cnt_contracted_product ctprd, 
                         cnt_contracted_prod_status_his ctsth, 
                         cat_product                    prdct, 
                         doc_identification_document    docid 
                  where 1 = 1 
                     and cust.id = cusco.fk_cust_id 
                     and cust.fk_docum_main_document_id = docid.id 
                     and accnt.fk_cust_id = cust.id 
                     and paymd.fk_accnt_id = accnt.id 
                     and paymd.pay_mode in (3, 4) 
                     and prdacc.fk_accnt_id = accnt.id 
                     and ctprd.id = prdacc.contracted_product_id 
                     and ctsth.fk_ctprd_id = ctprd.id 
                     AND CUSCO.NRC NOT IN (                            
                                              SELECT DISTINCT(CC.NRC)
                                              FROM 
                                              SUP_SCH.CST_CUSTOMER C, 
                                              SUP_SCH.CST_CUSTOMER_COMPANY CC,
                                              SUP_SCH.DOC_IDENTIFICATION_DOCUMENT D,
                                              SUP_SCH.ACC_ACCOUNT A 
                                              ,CNT_CONTRACTED_PRODUCT CP
                                              ,ACC_PRODUCT_ACCOUNT PA
                                              ,CNT_CONTRACTED_PROD_STATUS_HIS SH
                                              WHERE 
                                              A.FK_CUST_ID = C.ID
                                              AND CC.FK_CUST_ID = C.ID
                                              AND C.FK_DOCUM_MAIN_DOCUMENT_ID = D.ID
                                              AND PA.FK_ACCNT_ID = A.ID
                                              AND PA.CONTRACTED_PRODUCT_ID = CP.ID
                                              AND SH.FK_CTPRD_ID = CP.ID
                                              AND SH.fk_cntst_id = 1 
                                              AND CP.FK_PRDCT_ID IN (100322004, 100322007, 100372000, 100582000, 100582002,100794000,100794001,100814000,100038000,100092001,100192004,100192007,100252001,100282000,100492001))
                     and ctsth.validity_end_date is null 
                     and ctsth.fk_cntst_id = 1 
                     and ctprd.contracted_product_type = 4 
                     and ctprd.fk_prdct_id = prdct.id 
                     and (accnt.recharge_value is null) 
                     and prdct.id not in (100322004,100322007,100372000,100582000,100582002,100794000,100794001,100814000,100038000,100092001,100192004,100192007,100252001,100282000,100492001,101434002,101114016,101114002,101424002,101114021,101114002)
                     and rownum < 2 
            ")

            while response = (cursor.fetch())
                return response
            end

            cursor.close
            @connection.logoff 
                
            end

            
            def buscar_dados_atendimento
                
                conectar_banco_dados

                cursor = @connection.exec("
                    SELECT aa.TB0086_cd_cliente, bb.TB0086_NR_PROTOCOLO, cc.TB0090_NR_CONTROLEWORKFLOW as ocorrência , 
                    to_char(aa.TB0085_DT_INICIOATENDIMENTO,'DD/MM/YYYY') as data_atendimento
                    FROM cadmo.tb0086_atendimentocliente aa, TB0088_ATENDIMENTODEMANDA bb, TB0090_WORKFLOWATENDIMENTO cc 
                    WHERE aa.TB0086_NR_PROTOCOLO = bb.TB0086_NR_PROTOCOLO
                    and bb.TB0088_CD_ATENDIMENTODEMANDA = cc.TB0088_CD_ATENDIMENTODEMANDA
                    and aa.TB0085_DT_FIMCONTATOCLIENTE is not null
                    and aa.TB0085_DT_INICIOATENDIMENTO > sysdate - 90  
                    and ROWNUM < 2
                ")

                while response = (cursor.fetch())
                    @retorno = response.join('|')
                end

                cursor.close
                @connection.logoff 
                
            end


            def buscar_cliente_atendimento_paginacao
                
                conectar_banco_dados

                cursor = @connection.exec("
                    SELECT aa.TB0086_cd_cliente,
                    to_char(aa.TB0085_DT_INICIOATENDIMENTO,'DD/MM/YYYY') as data_atendimento
                    FROM cadmo.tb0086_atendimentocliente aa
                    WHERE
                    aa.TB0086_cd_cliente is not null
                    and exists (SELECT aa.TB0086_cd_cliente FROM cadmo.tb0086_atendimentocliente aa
                                WHERE aa.TB0085_DT_FIMCONTATOCLIENTE is not null
                                and aa.TB0085_DT_INICIOATENDIMENTO > sysdate - 90  
                                and aa.TB0085_DT_FIMCONTATOCLIENTE < sysdate
                                and aa.TB0086_cd_cliente is not null
                                and aa.TB0025_ST_ATENDIMENTO in (2,4)
                                group by aa.TB0086_cd_cliente
                                having count(1) > 10)
                    and rownum < 2   
                ")

                while response = (cursor.fetch())
                    @retorno = response.join('|')
                end

                cursor.close
                @connection.logoff 
                
            end



            def buscar_funcionalidade_atendimento
                
                conectar_banco_dados

                cursor = @connection.exec("
                    SELECT aa.TB0086_cd_cliente, DECODE(bb.TB0087_CD_DEMANDA, 2, 'Consulta Informação') as funcionalidade,
                    (SELECT TB0087_NM_DEMANDA FROM TB0087_DEMANDA dd where bb.TB0087_CD_DEMANDA = dd.TB0087_CD_DEMANDA ) as demanda,
                    to_char(aa.TB0085_DT_INICIOATENDIMENTO,'DD/MM/YYYY') as data_atendimento
                    FROM cadmo.tb0086_atendimentocliente aa, TB0088_ATENDIMENTODEMANDA bb, TB0090_WORKFLOWATENDIMENTO cc 
                    WHERE aa.TB0086_NR_PROTOCOLO = bb.TB0086_NR_PROTOCOLO
                    and bb.TB0088_CD_ATENDIMENTODEMANDA = cc.TB0088_CD_ATENDIMENTODEMANDA
                    and aa.TB0085_DT_FIMCONTATOCLIENTE is not null
                    and  bb.TB0087_CD_DEMANDA = 2
                    and aa.TB0085_DT_INICIOATENDIMENTO > sysdate - 120
                    and ROWNUM < 2
                ")

                while response = (cursor.fetch())
                    @retorno = response.join('|')
                end

                cursor.close
                @connection.logoff 
                
            end


###### BUSCAR VARIOS TIPOS DE CLIENTE ######
    def buscar_cliente_pre_pago
        conectar_banco_dados

        cursor = @connection.exec("
        select cusco.nrc
            from cst_customer                cust,
                cst_customer_company         cusco,
                acc_account                  accnt,
                acc_payment_mode             acpm,
                acc_account_payment_mode     apm
        where 1 = 1
            and cust.id = cusco.fk_cust_id
            and accnt.fk_cust_id = cust.id
            and acpm.fk_accnt_id = accnt.id
            and acpm.pay_mode = apm.identification
            and acpm.pay_mode in (3,4)
            and accnt.real_balance <  -150
            and accnt.balance  < -150
            and rownum < 2
        ")

        while response = (cursor.fetch())
            return response
        end

        cursor.close
        @connection.logoff 
    end


    def buscar_cliente_pj_embarcador
        conectar_banco_dados

        cursor = @connection.exec("
            --Consultar cliente embarcador retornando NRC, CNPJ, entre outros dados
            select cusco_emb.NRC
            --, doc.DOCUMENT_NUMBER CNPJ, emb.*, cst_emb.*, cusco_emb.*
            from acc_account emb
            inner join CST_CUSTOMER cst_emb on (emb.FK_CUST_ID = cst_emb.ID)
            inner join cst_customer_company cusco_emb on (cusco_emb.FK_CUST_ID = cst_emb.ID)
            inner join acc_account parc on (emb.FK_ACCNT_ID_PAYER = parc.ID and parc.ID != emb.ID)
            inner join CST_CUSTOMER cst_parc on (parc.FK_CUST_ID = cst_parc.ID)
            INNER JOIN CST_CUSTOMER_COMPANY CUSCO_PARC ON (CUSCO_PARC.FK_CUST_ID = CST_PARC.ID)
            INNER JOIN DOC_IDENTIFICATION_DOCUMENT DOC ON (DOC.ID = CST_EMB.FK_DOCUM_MAIN_DOCUMENT_ID)
            and emb.FK_ACCTP_ID = 3
            and rownum < 2
            ")

        while response = (cursor.fetch())
            return response
        end

        cursor.close
        @connection.logoff 
    end



    def buscar_cliente_movida
        
        conectar_banco_dados

        cursor = @connection.exec("
        --Consultar Cliente Movida
        select cc.NRC from acc_account acc, cst_customer_company cc where 
        cc.FK_CUST_ID = acc.FK_CUST_ID
        and identification = '2019261542'
        ")

        while response = (cursor.fetch())
            return response
        end

        cursor.close
        @connection.logoff 

    end



    def query_cliente_combo
        conectar_banco_dados

        cursor = @connection.exec("
            select P.tb0170_cd_Cliente
            FROM 
            CADMO.TB0170_PEDIDO P,
            CADMO.TB0171_ITEMPEDIDO I,
            CADMO.TB0172_VEICULOPEDIDO V
            WHERE 
            I.TB0170_CD_PEDIDO = P.TB0170_CD_PEDIDO
            AND V.TB0171_CD_PEDIDO = I.TB0170_CD_PEDIDO
            AND V.TB0171_ID_ITEMPEDIDO = I.TB0171_ID_ITEMPEDIDO
            and V.tb0172_DS_MARCAVEICULONOVO IS NOT NULL
            --and P.TB0170_DT_CRIACAO > sysdate - 200
            and I.TB0084_ID_OFERTACOMERCIAL = '40030'
            and not exists (select 1 from tmovpd01 where mov_tag = v.tb0172_cd_identificador and mov_codoco in (22,95,20,15))   --and mov_Codacao in (11,14)
            and rownum < 2
            order by P.TB0170_DT_CRIACAO asc
            ")

        while response = (cursor.fetch())
            @retorno = response.join('|')
            puts @retorno
        end

        cursor.close
        @connection.logoff 
    end

    def retorna_cliente_combo
        
        query_cliente_combo
        @retornoCompleto = @retorno.split("|")
        @cliente, placa = @retornoCompleto        

        return @cliente
    end

    def query_cliente_varios_veiculos_pf
        conectar_banco_dados

        cursor = @connection.exec("
            SELECT 
                (SELECT CC.NRC FROM SUP_SCH.CST_CUSTOMER_COMPANY CC WHERE C.ID = CC.FK_CUST_ID) AS NRC
                FROM 
                SUP_SCH.CST_CUSTOMER C, SUP_SCH.CNT_CONTRACT N, SUP_SCH.CAT_PRODUCT P, SUP_SCH.CNT_CONTRACTED_PRODUCT CP,
                VCL_VEHICLE v, VCL_VEHICLE_ACCESS_POINT vap, VCL_VEHICLE_ACCESS_POINT_IDENT vi,
                SUP_SCH.ACC_PAYMENT_MODE MO, SUP_SCH.ACC_ACCOUNT A
                WHERE 1=1
                        AND V.FK_CUST_ID = A.FK_CUST_ID
                        and A.ID = MO.FK_ACCNT_ID
                        and A.FK_CUST_ID = C.ID
                    AND vi.FK_VCLAP_ID = vap.ID
                    AND vap.FK_VCLVC_ID = v.id
                    AND C.ID = v.FK_CUST_ID
                    AND vi.FINAL_DATE is null
                AND N.FK_CUST_ID = C.ID
                AND N.ID = CP.FK_SVCTR_ID
                AND CP.FK_PRDCT_ID = P.ID
                AND C.ID IN (SELECT DISTINCT(N.FK_CUST_ID) FROM CNT_CONTRACT N GROUP BY N.FK_CUST_ID HAVING COUNT(1) > 2)
                AND C.PERSON_TYPE = 1
                and P.type = 4
                AND ROWNUM < 2
            ")

        while response = (cursor.fetch())
            @retorno = response.join('|')
            puts @retorno
        end

        cursor.close
        @connection.logoff 
    end

    def retorna_cliente_varios_veiculos_pf
        
        query_cliente_varios_veiculos_pf
        @retornoCompleto = @retorno.split("|")
        @cliente = @retornoCompleto        

        return @cliente
    end

    def query_cliente_varios_veiculos_pj
        conectar_banco_dados

        cursor = @connection.exec("
            SELECT 
                (SELECT CC.NRC FROM SUP_SCH.CST_CUSTOMER_COMPANY CC WHERE C.ID = CC.FK_CUST_ID) AS NRC
                FROM 
                SUP_SCH.CST_CUSTOMER C, SUP_SCH.CNT_CONTRACT N, SUP_SCH.CAT_PRODUCT P, SUP_SCH.CNT_CONTRACTED_PRODUCT CP,
                VCL_VEHICLE v, VCL_VEHICLE_ACCESS_POINT vap, VCL_VEHICLE_ACCESS_POINT_IDENT vi,
                SUP_SCH.ACC_PAYMENT_MODE MO, SUP_SCH.ACC_ACCOUNT A
                WHERE 1=1
                        AND V.FK_CUST_ID = A.FK_CUST_ID
                        and A.ID = MO.FK_ACCNT_ID
                        and A.FK_CUST_ID = C.ID
                    AND vi.FK_VCLAP_ID = vap.ID
                    AND vap.FK_VCLVC_ID = v.id
                    AND C.ID = v.FK_CUST_ID
                    AND vi.FINAL_DATE is null
                AND N.FK_CUST_ID = C.ID
                AND N.ID = CP.FK_SVCTR_ID
                AND CP.FK_PRDCT_ID = P.ID
                AND P.ID in ('100192005','100192007','100192009')
                AND C.ID IN (SELECT DISTINCT(N.FK_CUST_ID) FROM CNT_CONTRACT N where n.FK_CNTCT_ID = 1 and N.VALIDITY_END_DATE is null GROUP BY N.FK_CUST_ID HAVING COUNT(1) > 2)
                and P.type = 4
                AND ROWNUM < 2
            ")

        while response = (cursor.fetch())
            @retorno = response.join('|')
            puts @retorno
        end

        cursor.close
        @connection.logoff 
    end

    def retorna_cliente_varios_veiculos_pj
        
        query_cliente_varios_veiculos_pj
        @retornoCompleto = @retorno.split("|")
        @cliente = @retornoCompleto        

        return @cliente
    end


    def query_cliente_cliente_veiculo_vendido
        conectar_banco_dados

        cursor = @connection.exec("
            select 
                (SELECT CC.NRC FROM SUP_SCH.CST_CUSTOMER_COMPANY CC WHERE C.ID = CC.FK_CUST_ID) AS NRC
                from tmovpd01 mov, ACC_ACCOUNT aa, cst_customer c
                where 1=1  
                and c.ID = aa.fk_cust_id 
                and aa.identification = mov.MOV_CONTA
                and mov.mov_codoco = 51
                and mov.MOV_CONTA is not null
                and mov.mov_status = 3 
                and mov.mov_datlan > sysdate - 200
                and not exists (select 1 from tmovpd01 vv where mov.mov_tag = vv.mov_tag and vv.mov_codoco in (22,95,72))
                and rownum < 2
            ")

        while response = (cursor.fetch())
            @retorno = response.join('|')
            puts @retorno
        end

        cursor.close
        @connection.logoff 
    end

    def retorna_cliente_veiculo_vendido
        
        query_cliente_cliente_veiculo_vendido
        @retornoCompleto = @retorno.split("|")
        @cliente = @retornoCompleto        

        return @cliente
    end

    def query_cliente_cliente_veiculo_ativo_vendido
        conectar_banco_dados

        cursor = @connection.exec("
            select MOV_CLIENTE  
            from tmovpd01, acc_account a, cst_customer c
            where a.IDENTIFICATION = mov_conta
            and c.ID = a.FK_CUST_ID
            and mov_codoco = 51
            and mov_datlan > sysdate - 120
            AND C.ID IN (SELECT DISTINCT(N.FK_CUST_ID) FROM CNT_CONTRACT N where n.FK_CNTCT_ID = 1 and N.VALIDITY_END_DATE is null GROUP BY N.FK_CUST_ID HAVING COUNT(1) > 1)
            and rownum < 2
            order by mov_datlan desc
            ")

        while response = (cursor.fetch())
            @retorno = response.join('|')
            puts @retorno
        end

        cursor.close
        @connection.logoff 
    end

    def retorna_cliente_veiculo_ativo_vendido
        
        query_cliente_cliente_veiculo_ativo_vendido
        @retornoCompleto = @retorno.split("|")
        @cliente = @retornoCompleto        

        return @cliente
    end

    def query_cliente_cliente_apenas_veiculo_vendido
        conectar_banco_dados

        cursor = @connection.exec("
            select 
            mov_cliente
            from tmovpd01 mov, ACC_ACCOUNT aa, cst_customer c
            where 1=1  
            and c.ID = aa.fk_cust_id 
            and aa.identification = mov.MOV_CONTA
            and mov.mov_codoco = 51
            and mov.MOV_CONTA is not null
            and mov.mov_status = 3 
            and mov.mov_datlan > sysdate - 90
            and c.person_type = 1
            and not exists (select 1 from tmovpd01 vv where mov.mov_tag = vv.mov_tag and vv.mov_codoco in (22,95,72))
                and exists (select 1 from SUP_SCH.CNT_ACCESS_POINT_IDENTIFICATOR cc, CNT_CONTRACTED_PRODUCT cp,  CNT_CONTRACTED_PROD_STATUS_HIS CTSTH
                where 1=1 
                and cp.ID = CTSTH.FK_CTPRD_ID
                and cp.ID = cc.FK_CTPRD_ID 
                and  name = mov.mov_tag
                and CTSTH.VALIDITY_END_DATE is null)
                and rownum < 2
            ")

        while response = (cursor.fetch())
            @retorno = response.join('|')
            puts @retorno
        end

        cursor.close
        @connection.logoff 
    end

    def retorna_cliente_apenas_veiculo_vendido
        
        query_cliente_cliente_apenas_veiculo_vendido
        @retornoCompleto = @retorno.split("|")
        @cliente = @retornoCompleto        

        return @cliente
    end

  


    


    def contestar_taxa_juros_multa
        conectar_banco_dados

        cursor = @connection.exec("
            SELECT 
                (SELECT CC.NRC FROM SUP_SCH.CST_CUSTOMER_COMPANY CC WHERE C.ID = CC.FK_CUST_ID) AS NRC,
                II.EVENT_DATE
                FROM
                SUP_SCH.ACC_ACCOUNT A,
                CBILL_SCH.INV_INVOICE_ITEM PARTITION(INV_INVOICE_ITEM_202105) II,
                CBILL_SCH.INV_INVOICE I,
                CST_CUSTOMER C
                WHERE
                I.ID = II.FK_INVCE_ID --(+)
                and II.FK_ACCNT_ID = A.ID
                AND I.FK_CUSTOMER_ID = C.ID
                AND C.PERSON_TYPE = 1         --PF = 1  | PJ = 2
                AND II.FK_RATEV_ID = 101010	    --JUROS POR PAGAMENTO EM ATRASO
                AND II.GROSS_VALUE > 0
                and I.status not in (3,4,5,6)
                    AND not exists (select 1 from  TB0271_CONTESTACAOCONV where TB0271_CD_CONTA = a.Identification and TB0271_DT_CRIACAO > sysdate - 5)   --784,092 segundos
                AND ROWNUM < 2
                order by II.EVENT_DATE desc
            ")

        while response = (cursor.fetch())
            @retorno = response.join('|')
        end

        cursor.close
        @connection.logoff 
    end


    def retorna_taxa_juros_multa_cliente
        
        contestar_taxa_juros_multa
        @retornoCompleto = @retorno.split("|")
        @cliente, data = @retornoCompleto        

        return @cliente
    end

    def retorna_taxa_juros_multa_data
        
        contestar_taxa_juros_multa
        @retornoCompleto = @retorno.split("|")
        cliente, @data = @retornoCompleto        

        return @data
    end


    def contestar_taxa_adesao
        conectar_banco_dados

        cursor = @connection.exec("
            SELECT 
                (SELECT CC.NRC FROM SUP_SCH.CST_CUSTOMER_COMPANY CC WHERE C.ID = CC.FK_CUST_ID) AS NRC,
                 II.EVENT_DATE
                FROM
                SUP_SCH.ACC_ACCOUNT A,
                CBILL_SCH.INV_INVOICE_ITEM PARTITION(INV_INVOICE_ITEM_202105) II,
                CBILL_SCH.INV_INVOICE I,
                CST_CUSTOMER C
                WHERE
                I.ID = II.FK_INVCE_ID
                and II.FK_ACCNT_ID = A.ID
                AND I.FK_CUSTOMER_ID = C.ID
                AND C.PERSON_TYPE = 1         --PF = 1  | PJ = 2
                AND II.FK_RATEV_ID = 101006 --TAXA ADESÃO
                AND II.GROSS_VALUE > 0
                and I.status not in (3,4,5,6)
                    AND not exists (select 1 from  TB0271_CONTESTACAOCONV where TB0271_CD_CONTA = a.Identification and TB0271_DT_CRIACAO > sysdate - 5)  
                AND ROWNUM < 2
                order by II.EVENT_DATE desc
            ")

        while response = (cursor.fetch())
            @retorno = response.join('|')
        end

        cursor.close
        @connection.logoff 
    end


    def retorna_taxa_adesao_cliente
        
        contestar_taxa_adesao
        @retornoCompleto = @retorno.split("|")
        @cliente, data = @retornoCompleto        

        return @cliente
    end

    def retorna_taxa_adesao_data
        
        contestar_taxa_adesao
        @retornoCompleto = @retorno.split("|")
        cliente, @data = @retornoCompleto        

        return @data
    end


    def contestar_taxa_substituicao
        conectar_banco_dados

        cursor = @connection.exec("
            SELECT 
                (SELECT CC.NRC FROM SUP_SCH.CST_CUSTOMER_COMPANY CC WHERE C.ID = CC.FK_CUST_ID) AS NRC,
                II.EVENT_DATE   
                FROM
                SUP_SCH.ACC_ACCOUNT A,
                CBILL_SCH.INV_INVOICE_ITEM PARTITION(INV_INVOICE_ITEM_202105) II,
                CBILL_SCH.INV_INVOICE I,
                CST_CUSTOMER C
                WHERE
                I.ID = II.FK_INVCE_ID --(+)
                and II.FK_ACCNT_ID = A.ID
                AND I.FK_CUSTOMER_ID = C.ID
                AND C.PERSON_TYPE = 1         --PF = 1  | PJ = 2
                AND II.FK_RATEV_ID = 101002 --TAXA SUBSTITUICAO
                AND II.GROSS_VALUE > 0
                and I.status not in (3,4,5,6)
                --and II.EVENT_DATE > sysdate - 120
                    AND not exists (select 1 from  TB0271_CONTESTACAOCONV where TB0271_CD_CONTA = a.Identification and TB0271_DT_CRIACAO > sysdate - 5)  
                AND ROWNUM < 2
                order by II.EVENT_DATE desc
            ")

        while response = (cursor.fetch())
            @retorno = response.join('|')
        end

        cursor.close
        @connection.logoff 
    end


    def retorna_taxa_substituicao_cliente
        
        contestar_taxa_substituicao
        @retornoCompleto = @retorno.split("|")
        @cliente, data = @retornoCompleto        

        return @cliente
    end

    def retorna_taxa_substituicao_data
        
        contestar_taxa_substituicao
        @retornoCompleto = @retorno.split("|")
        cliente, @data = @retornoCompleto        

        return @data
    end

    def contestar_taxa_multa_cancelamento
        conectar_banco_dados

        cursor = @connection.exec("
            SELECT 
            (SELECT CC.NRC FROM SUP_SCH.CST_CUSTOMER_COMPANY CC WHERE C.ID = CC.FK_CUST_ID) AS NRC,
            II.EVENT_DATE 
            FROM
            SUP_SCH.ACC_ACCOUNT A,
            CBILL_SCH.INV_INVOICE_ITEM PARTITION(INV_INVOICE_ITEM_202105) II,
            CBILL_SCH.INV_INVOICE I,
            CST_CUSTOMER C
            WHERE
            I.ID = II.FK_INVCE_ID --(+)
            and II.FK_ACCNT_ID = A.ID
            AND I.FK_CUSTOMER_ID = C.ID
            AND C.PERSON_TYPE = 1         --PF = 1  | PJ = 2
            AND II.FK_RATEV_ID = 101007 --TAXA MULTA CANCELAMENTO
            AND II.GROSS_VALUE > 0
            and I.status not in (3,4,5,6)
                AND not exists (select 1 from  TB0271_CONTESTACAOCONV where TB0271_CD_CONTA = a.Identification and TB0271_DT_CRIACAO > sysdate - 5)  
            AND ROWNUM < 2
            order by II.EVENT_DATE desc
            ")

        while response = (cursor.fetch())
            @retorno = response.join('|')
        end

        cursor.close
        @connection.logoff 
    end


    def retorna_taxa_multa_cancelamento_cliente
        
        contestar_taxa_multa_cancelamento
        @retornoCompleto = @retorno.split("|")
        @cliente, data = @retornoCompleto        

        return @cliente
    end

    def retorna_taxa_multa_cancelamento_data
        
        contestar_taxa_multa_cancelamento
        @retornoCompleto = @retorno.split("|")
        cliente, @data = @retornoCompleto        

        return @data
    end

    def contestar_taxa_extravio
        conectar_banco_dados

        cursor = @connection.exec("
            SELECT 
            (SELECT CC.NRC FROM SUP_SCH.CST_CUSTOMER_COMPANY CC WHERE C.ID = CC.FK_CUST_ID) AS NRC,
            II.EVENT_DATE
            FROM
            SUP_SCH.ACC_ACCOUNT A,
            CBILL_SCH.INV_INVOICE_ITEM PARTITION(INV_INVOICE_ITEM_202105) II,
            CBILL_SCH.INV_INVOICE I,
            CST_CUSTOMER C
            WHERE
            I.ID = II.FK_INVCE_ID --(+)
            --AND I.FK_ACCNT_ID_PAYER = PM.ID
            and II.FK_ACCNT_ID = A.ID
            AND I.FK_CUSTOMER_ID = C.ID
            AND C.PERSON_TYPE = 1         --PF = 1  | PJ = 2
            AND II.FK_RATEV_ID = 101004 --TAXA EXTRAVIO
            AND II.GROSS_VALUE > 0
            and I.status not in (3,4,5,6)
                AND not exists (select 1 from  TB0271_CONTESTACAOCONV where TB0271_CD_CONTA = a.Identification and TB0271_DT_CRIACAO > sysdate - 5)  
            AND ROWNUM < 2
            order by II.EVENT_DATE desc
            ")

        while response = (cursor.fetch())
            @retorno = response.join('|')
        end

        cursor.close
        @connection.logoff 
    end


    def retorna_taxa_extravio_cliente
        
        contestar_taxa_extravio
        @retornoCompleto = @retorno.split("|")
        @cliente, data = @retornoCompleto        

        return @cliente
    end

    def retorna_taxa_extravio_data
        
        contestar_taxa_extravio
        @retornoCompleto = @retorno.split("|")
        cliente, @data = @retornoCompleto        

        return @data
    end


    def contestar_taxa_recarga
        conectar_banco_dados

        cursor = @connection.exec("
            SELECT 
            (SELECT CC.NRC FROM SUP_SCH.CST_CUSTOMER_COMPANY CC WHERE C.ID = CC.FK_CUST_ID) AS NRC,
            II.EVENT_DATE
            --to_date(II.EVENT_DATE,'DD/MM/YYYY') AS DATA
            FROM
            SUP_SCH.ACC_ACCOUNT A,
            CBILL_SCH.INV_INVOICE_ITEM PARTITION(INV_INVOICE_ITEM_202010) II,
            CBILL_SCH.INV_INVOICE I,
            CST_CUSTOMER C
            WHERE
            I.ID = II.FK_INVCE_ID --(+)
            and II.FK_ACCNT_ID = A.ID
            AND I.FK_CUSTOMER_ID = C.ID
            AND C.PERSON_TYPE = 1         --PF = 1  | PJ = 2
            AND II.FK_RATEV_ID = '100467000' --TAXA RECARGA
            AND II.GROSS_VALUE > 0
            and I.status not in (3,4,5,6)
            --and II.EVENT_DATE > sysdate - 400
                AND not exists (select 1 from  TB0271_CONTESTACAOCONV where TB0271_CD_CONTA = a.Identification and TB0271_DT_CRIACAO > sysdate - 35)  
            AND ROWNUM < 2
            order by II.EVENT_DATE desc
            ")

        while response = (cursor.fetch())
            @retorno = response.join('|')
        end

        cursor.close
        @connection.logoff 
    end


    def retorna_taxa_recarga_cliente
        
        contestar_taxa_recarga
        @retornoCompleto = @retorno.split("|")
        @cliente, data = @retornoCompleto        

        return @cliente
    end

    def retorna_taxa_recarga_data
        
        contestar_taxa_recarga
        @retornoCompleto = @retorno.split("|")
        cliente, @data = @retornoCompleto        

        return @data
    end


    def contestar_taxa_caucao
        conectar_banco_dados

        cursor = @connection.exec("
            SELECT 
            (SELECT CC.NRC FROM SUP_SCH.CST_CUSTOMER_COMPANY CC WHERE C.ID = CC.FK_CUST_ID) AS NRC,
            II.EVENT_DATE       
            FROM
            SUP_SCH.ACC_ACCOUNT A,
            CBILL_SCH.INV_INVOICE_ITEM PARTITION(INV_INVOICE_ITEM_202105) II,
            CBILL_SCH.INV_INVOICE I,
            CST_CUSTOMER C
            WHERE
            I.ID = II.FK_INVCE_ID --(+)
            and II.FK_ACCNT_ID = A.ID
            AND I.FK_CUSTOMER_ID = C.ID
            AND C.PERSON_TYPE = 1         --PF = 1  | PJ = 2
            AND II.FK_RATEV_ID = 106002 --TAXA CAUCAO
            AND II.GROSS_VALUE > 0
            and I.status not in (3,4,5,6)
                AND not exists (select 1 from  TB0271_CONTESTACAOCONV where TB0271_CD_CONTA = a.Identification and TB0271_DT_CRIACAO > sysdate - 5)  
            AND ROWNUM < 2
            order by II.EVENT_DATE desc
            ")

        while response = (cursor.fetch())
            @retorno = response.join('|')
        end

        cursor.close
        @connection.logoff 
    end


    def retorna_taxa_caucao_cliente
        
        contestar_taxa_caucao
        @retornoCompleto = @retorno.split("|")
        @cliente, data = @retornoCompleto        

        return @cliente
    end

    def retorna_taxa_caucao_data
        
        contestar_taxa_caucao
        @retornoCompleto = @retorno.split("|")
        cliente, @data = @retornoCompleto        

        return @data
    end

    def contestar_taxa_uso_fora_cobertura
        conectar_banco_dados

        cursor = @connection.exec("
            SELECT 
            (SELECT CC.NRC FROM SUP_SCH.CST_CUSTOMER_COMPANY CC WHERE C.ID = CC.FK_CUST_ID) AS NRC,
            II.EVENT_DATE        
            FROM
            SUP_SCH.ACC_ACCOUNT A,
            CBILL_SCH.INV_INVOICE_ITEM PARTITION(INV_INVOICE_ITEM_202105) II,
            CBILL_SCH.INV_INVOICE I,
            CST_CUSTOMER C
            WHERE
            I.ID = II.FK_INVCE_ID --(+)
            and II.FK_ACCNT_ID = A.ID
            AND I.FK_CUSTOMER_ID = C.ID
            AND C.PERSON_TYPE = 1         --PF = 1  | PJ = 2
            AND II.FK_RATEV_ID = 100000003 --TAXA USO FORA COBERTURA
            AND II.GROSS_VALUE > 0
            and I.status not in (3,4,5,6)
                AND not exists (select 1 from  TB0271_CONTESTACAOCONV where TB0271_CD_CONTA = a.Identification and TB0271_DT_CRIACAO > sysdate - 5)  
            AND ROWNUM < 2
            order by II.EVENT_DATE desc
            ")

        while response = (cursor.fetch())
            @retorno = response.join('|')
        end

        cursor.close
        @connection.logoff 
    end


    def retorna_taxa_uso_fora_cobertura_cliente
        
        contestar_taxa_uso_fora_cobertura
        @retornoCompleto = @retorno.split("|")
        @cliente, data = @retornoCompleto        

        return @cliente
    end

    def retorna_taxa_uso_fora_cobertura_data
        
        contestar_taxa_uso_fora_cobertura
        @retornoCompleto = @retorno.split("|")
        cliente, @data = @retornoCompleto        

        return @data
    end


    def contestar_taxa_reprocessamento
        conectar_banco_dados

        cursor = @connection.exec("
            SELECT 
            (SELECT CC.NRC FROM SUP_SCH.CST_CUSTOMER_COMPANY CC WHERE C.ID = CC.FK_CUST_ID) AS NRC,
            II.EVENT_DATE       
            FROM
            SUP_SCH.ACC_ACCOUNT A,
            CBILL_SCH.INV_INVOICE_ITEM PARTITION(INV_INVOICE_ITEM_202105) II,
            CBILL_SCH.INV_INVOICE I,
            CST_CUSTOMER C
            WHERE
            I.ID = II.FK_INVCE_ID --(+)
            and II.FK_ACCNT_ID = A.ID
            AND I.FK_CUSTOMER_ID = C.ID
            AND C.PERSON_TYPE = 1         --PF = 1  | PJ = 2
            AND II.FK_RATEV_ID = 100034003 --TAXA REPROCESSAMENTO
            AND II.GROSS_VALUE > 0
            and I.status not in (3,4,5,6)
                AND not exists (select 1 from  TB0271_CONTESTACAOCONV where TB0271_CD_CONTA = a.Identification and TB0271_DT_CRIACAO > sysdate - 55)  
            AND ROWNUM < 2
            order by II.EVENT_DATE desc
            ")

        while response = (cursor.fetch())
            @retorno = response.join('|')
        end

        cursor.close
        @connection.logoff 
    end


    def retorna_taxa_reprocessamento_cliente
        
        contestar_taxa_reprocessamento
        @retornoCompleto = @retorno.split("|")
        @cliente, data = @retornoCompleto        

        return @cliente
    end

    def retorna_taxa_reprocessamento_data
        
        contestar_taxa_reprocessamento
        @retornoCompleto = @retorno.split("|")
        cliente, @data = @retornoCompleto        

        return @data
    end

    def contestar_taxa_extrato
        conectar_banco_dados

        cursor = @connection.exec("
            SELECT 
            (SELECT CC.NRC FROM SUP_SCH.CST_CUSTOMER_COMPANY CC WHERE C.ID = CC.FK_CUST_ID) AS NRC,
            II.EVENT_DATE
            FROM
            SUP_SCH.ACC_ACCOUNT A,
            CBILL_SCH.INV_INVOICE_ITEM PARTITION(INV_INVOICE_ITEM_202105) II,
            CBILL_SCH.INV_INVOICE I,
            CST_CUSTOMER C
            WHERE
            I.ID = II.FK_INVCE_ID --(+)
            and II.FK_ACCNT_ID = A.ID
            AND I.FK_CUSTOMER_ID = C.ID
            AND C.PERSON_TYPE = 1         --PF = 1  | PJ = 2
            AND II.FK_RATEV_ID = 106001 --TAXA EXTRATO
            AND II.GROSS_VALUE > 0
            and I.status not in (3,4,5,6)
                AND not exists (select 1 from  TB0271_CONTESTACAOCONV where TB0271_CD_CONTA = a.Identification and TB0271_DT_CRIACAO > sysdate - 55)  
            AND ROWNUM < 2
            order by II.EVENT_DATE desc
            ")

        while response = (cursor.fetch())
            @retorno = response.join('|')
        end

        cursor.close
        @connection.logoff 
    end


    def retorna_taxa_extrato_cliente
        
        contestar_taxa_extrato
        @retornoCompleto = @retorno.split("|")
        @cliente, data = @retornoCompleto        

        return @cliente
    end

    def retorna_taxa_extrato_data
        
        contestar_taxa_extrato
        @retornoCompleto = @retorno.split("|")
        cliente, @data = @retornoCompleto        

        return @data
    end

    def contestar_taxa_seguros
        conectar_banco_dados

        cursor = @connection.exec("
            SELECT 
            (SELECT CC.NRC FROM SUP_SCH.CST_CUSTOMER_COMPANY CC WHERE C.ID = CC.FK_CUST_ID) AS NRC,
            II.EVENT_DATE 
            FROM
            SUP_SCH.ACC_ACCOUNT A,
            CBILL_SCH.INV_INVOICE_ITEM PARTITION(INV_INVOICE_ITEM_202105) II,
            CBILL_SCH.INV_INVOICE I,
            CST_CUSTOMER C
            WHERE
            I.ID = II.FK_INVCE_ID --(+)
            and II.FK_ACCNT_ID = A.ID
            AND I.FK_CUSTOMER_ID = C.ID
            --AND C.PERSON_TYPE = 1         --PF = 1  | PJ = 2
            AND II.FK_RATEV_ID = 100015002 --TAXA SEGUROS
            AND II.GROSS_VALUE > 0
            and I.status not in (3,4,5,6)
                AND not exists (select 1 from  TB0271_CONTESTACAOCONV where TB0271_CD_CONTA = a.Identification and TB0271_DT_CRIACAO > sysdate - 5)  
            AND ROWNUM < 2
            order by II.EVENT_DATE desc
            ")

        while response = (cursor.fetch())
            @retorno = response.join('|')
        end

        cursor.close
        @connection.logoff 
    end


    def retorna_taxa_seguros_cliente
        
        contestar_taxa_seguros
        @retornoCompleto = @retorno.split("|")
        @cliente, data = @retornoCompleto        

        return @cliente
    end

    def retorna_taxa_seguros_data
        
        contestar_taxa_seguros
        @retornoCompleto = @retorno.split("|")
        cliente, @data = @retornoCompleto        

        return @data
    end


    def contestar_taxa_extrato_impresso
        conectar_banco_dados

        cursor = @connection.exec("
            SELECT 
            (SELECT CC.NRC FROM SUP_SCH.CST_CUSTOMER_COMPANY CC WHERE C.ID = CC.FK_CUST_ID) AS NRC,
            II.EVENT_DATE
            FROM
            SUP_SCH.ACC_ACCOUNT A,
            CBILL_SCH.INV_INVOICE_ITEM PARTITION(INV_INVOICE_ITEM_202105) II,
            CBILL_SCH.INV_INVOICE I,
            CST_CUSTOMER C
            WHERE
            I.ID = II.FK_INVCE_ID --(+)
            and II.FK_ACCNT_ID = A.ID
            AND I.FK_CUSTOMER_ID = C.ID
            AND C.PERSON_TYPE = 1         --PF = 1  | PJ = 2
            AND II.FK_RATEV_ID = 101009 --TAXA PAPER FEE
            AND II.GROSS_VALUE > 0
            and I.status not in (3,4,5,6)
                AND not exists (select 1 from  TB0271_CONTESTACAOCONV where TB0271_CD_CONTA = a.Identification and TB0271_DT_CRIACAO > sysdate - 5)  
            AND ROWNUM < 2
            order by ii.event_date desc
            ")

        while response = (cursor.fetch())
            @retorno = response.join('|')
        end

        cursor.close
        @connection.logoff 
    end


    def retorna_taxa_extrato_impresso_cliente
        
        contestar_taxa_extrato_impresso
        @retornoCompleto = @retorno.split("|")
        @cliente, data = @retornoCompleto        

        return @cliente
    end

    def retorna_taxa_extrato_impresso_data
        
        contestar_taxa_extrato_impresso
        @retornoCompleto = @retorno.split("|")
        cliente, @data = @retornoCompleto        

        return @data
    end

    def contestar_taxa_pausa
        conectar_banco_dados

        cursor = @connection.exec("
            SELECT 
            (SELECT CC.NRC FROM SUP_SCH.CST_CUSTOMER_COMPANY CC WHERE C.ID = CC.FK_CUST_ID) AS NRC,
            II.EVENT_DATE      
            FROM
            SUP_SCH.ACC_ACCOUNT A,
            CBILL_SCH.INV_INVOICE_ITEM PARTITION(INV_INVOICE_ITEM_202105) II,
            CBILL_SCH.INV_INVOICE I,
            CST_CUSTOMER C
            WHERE
            I.ID = II.FK_INVCE_ID --(+)
            and II.FK_ACCNT_ID = A.ID
            AND I.FK_CUSTOMER_ID = C.ID
            AND C.PERSON_TYPE = 1         --PF = 1  | PJ = 2
            AND II.FK_RATEV_ID = 100035000 --TAXA PAUSA
            AND II.GROSS_VALUE > 0
            and I.status not in (3,4,5,6)
                AND not exists (select 1 from  TB0271_CONTESTACAOCONV where TB0271_CD_CONTA = a.Identification and TB0271_DT_CRIACAO > sysdate - 5)  
            AND ROWNUM < 2
            order by II.EVENT_DATE desc
            ")

        while response = (cursor.fetch())
            @retorno = response.join('|')
        end

        cursor.close
        @connection.logoff 
    end


    def retorna_taxa_pausa_cliente
        
        contestar_taxa_pausa
        @retornoCompleto = @retorno.split("|")
        @cliente, data = @retornoCompleto        

        return @cliente
    end

    def retorna_taxa_pausa_data
        
        contestar_taxa_pausa
        @retornoCompleto = @retorno.split("|")
        cliente, @data = @retornoCompleto        

        return @data
    end

    def contestar_taxa_mensalidade
        conectar_banco_dados

        cursor = @connection.exec("
            SELECT 
            (SELECT CC.NRC FROM SUP_SCH.CST_CUSTOMER_COMPANY CC WHERE C.ID = CC.FK_CUST_ID) AS NRC,
            II.EVENT_DATE     
            FROM
            SUP_SCH.ACC_ACCOUNT A,
            CBILL_SCH.INV_INVOICE_ITEM PARTITION(INV_INVOICE_ITEM_202107) II,
            CBILL_SCH.INV_INVOICE I,
            CST_CUSTOMER C
            WHERE
            I.ID = II.FK_INVCE_ID 
            and II.FK_ACCNT_ID = A.ID
            AND I.FK_CUSTOMER_ID = C.ID
            AND C.PERSON_TYPE = 1         --PF = 1  | PJ = 2
            AND II.FK_RATEV_ID = '100001' --TAXA MENSALIDADE
            AND II.GROSS_VALUE > 0
            and I.status not in (3,4,5,6)
            --and II.EVENT_DATE > sysdate - 120
                AND not exists (select 1 from  TB0271_CONTESTACAOCONV where TB0271_CD_CONTA = a.Identification and TB0271_DT_CRIACAO > sysdate - 5)  
            AND ROWNUM < 2
            order by II.EVENT_DATE desc
            ")

        while response = (cursor.fetch())
            @retorno = response.join('|')
        end

        cursor.close
        @connection.logoff 
    end


    def retorna_taxa_mensalidade_cliente
        
        contestar_taxa_mensalidade
        @retornoCompleto = @retorno.split("|")
        @cliente, data = @retornoCompleto        

        return @cliente
    end

    def retorna_taxa_mensalidade_data
        
        contestar_taxa_mensalidade
        @retornoCompleto = @retorno.split("|")
        cliente, @data = @retornoCompleto        

        return @data
    end


    def contestar_taxa_inatividade
        conectar_banco_dados

        cursor = @connection.exec("
            SELECT 
            (SELECT CC.NRC FROM SUP_SCH.CST_CUSTOMER_COMPANY CC WHERE C.ID = CC.FK_CUST_ID) AS NRC,
            II.EVENT_DATE        
            FROM
            SUP_SCH.ACC_ACCOUNT A,
            CBILL_SCH.INV_INVOICE_ITEM PARTITION(INV_INVOICE_ITEM_202105) II,
            CBILL_SCH.INV_INVOICE I,
            CST_CUSTOMER C
            WHERE
            I.ID = II.FK_INVCE_ID --(+)
            and II.FK_ACCNT_ID = A.ID
            AND I.FK_CUSTOMER_ID = C.ID
            AND C.PERSON_TYPE = 1         --PF = 1  | PJ = 2
            AND II.FK_RATEV_ID = 100417000 --TAXA INATIVIDADE
            AND II.GROSS_VALUE > 0
            and I.status not in (3,4,5,6)
                AND not exists (select 1 from  TB0271_CONTESTACAOCONV where TB0271_CD_CONTA = a.Identification and TB0271_DT_CRIACAO > sysdate - 5)  
            AND ROWNUM < 2
            order by II.EVENT_DATE desc
            ")

        while response = (cursor.fetch())
            @retorno = response.join('|')
        end

        cursor.close
        @connection.logoff 
    end


    def retorna_taxa_inatividade_cliente
        
        contestar_taxa_inatividade
        @retornoCompleto = @retorno.split("|")
        @cliente, data = @retornoCompleto        

        return @cliente
    end

    def retorna_taxa_inatividade_data
        
        contestar_taxa_inatividade
        @retornoCompleto = @retorno.split("|")
        cliente, @data = @retornoCompleto        

        return @data
    end


    def contestar_taxa_administrativa
        conectar_banco_dados

        cursor = @connection.exec("
            
            ")

        while response = (cursor.fetch())
            @retorno = response.join('|')
        end

        cursor.close
        @connection.logoff 
    end


    def retorna_taxa_administrativa_cliente
        
        contestar_taxa_administrativa
        @retornoCompleto = @retorno.split("|")
        @cliente, data = @retornoCompleto        

        return @cliente
    end

    def retorna_taxa_administrativa_data
        
        contestar_taxa_administrativa
        @retornoCompleto = @retorno.split("|")
        cliente, @data = @retornoCompleto        

        return @data
    end


    def contestar_taxa_excedente
        conectar_banco_dados

        cursor = @connection.exec("
            
            ")

        while response = (cursor.fetch())
            @retorno = response.join('|')
        end

        cursor.close
        @connection.logoff 
    end


    def retorna_taxa_excedente_cliente
        
        contestar_taxa_excedente
        @retornoCompleto = @retorno.split("|")
        @cliente, data = @retornoCompleto        

        return @cliente
    end

    def retorna_taxa_excedente_data
        
        contestar_taxa_excedente
        @retornoCompleto = @retorno.split("|")
        cliente, @data = @retornoCompleto        

        return @data
    end


    def contestar_taxa_reboque
        conectar_banco_dados

        cursor = @connection.exec("
            SELECT 
                (SELECT CC.NRC FROM SUP_SCH.CST_CUSTOMER_COMPANY CC WHERE C.ID = CC.FK_CUST_ID) AS NRC,
                II.EVENT_DATE
                FROM
                SUP_SCH.ACC_ACCOUNT A,
                CBILL_SCH.INV_INVOICE_ITEM II,
                CBILL_SCH.INV_INVOICE I,
                CST_CUSTOMER C
                WHERE
                I.ID = II.FK_INVCE_ID --(+)
                and II.FK_ACCNT_ID = A.ID
                AND I.FK_CUSTOMER_ID = C.ID
                AND C.PERSON_TYPE = 1         --PF = 1  | PJ = 2
                AND II.FK_RATEV_ID = '100567000'	    --TAXA REBOQUE
                AND II.GROSS_VALUE > 0
                and I.status not in (3,4,5,6)
                    AND not exists (select 1 from  TB0271_CONTESTACAOCONV where TB0271_CD_CONTA = a.Identification and TB0271_DT_CRIACAO > sysdate - 5)   --784,092 segundos
                AND ROWNUM < 2
                order by II.EVENT_DATE desc
            ")

        while response = (cursor.fetch())
            @retorno = response.join('|')
        end

        cursor.close
        @connection.logoff 
    end


    def retorna_taxa_reboque_cliente
        
        contestar_taxa_reboque
        @retornoCompleto = @retorno.split("|")
        @cliente, data = @retornoCompleto        

        return @cliente
    end

    def retorna_taxa_reboque_data
        
        contestar_taxa_reboque
        @retornoCompleto = @retorno.split("|")
        cliente, @data = @retornoCompleto        

        return @data
    end







    def buscar_cliente_taxa_recontestar
        conectar_banco_dados
        cursor = @connection.exec("
            select TB0271_CD_CLIENTE from TB0271_CONTESTACAOCONV 
            where TB0025_TP_CONVENIADO = 4 and TB0271_ST_CONTESTACAO = 0 
            and TB0025_CL_TPMOTIVOSOLUCAO = 539
            and rownum < 2
            ")
            while response = (cursor.fetch())
                return response
            end
    
            cursor.close
            @connection.logoff 
    end


###### QUERY PARA BUSCAR TRANSACOES PEDAGIOS ######

def query_transacao_pedagio_com_fatura
    conectar_banco_dados

    cursor = @connection.exec("
        SELECT 
        PRSUI.NRC AS CLIENTE,
        to_char(PRSUI.EVENT_DATE,'DD/MM/YYYY') AS DATA
    FROM 
        prs_usage_item prsui, 
        gpa_partnership gpapt, 
        gpa_usage_point gpaup,
        vcl_vehicle_access_point vvap,
        vcl_vehicle vv,
        cnt_access_point_identificator capi
    WHERE prsui.fk_gpapt_id = gpapt.ID
        AND prsui.fk_gpaup_id = gpaup.ID
        AND prsui.access_point_id =  vvap.fk_acpnt_id               
        AND vvap.fk_vclvc_id = vv.ID
        AND capi.fk_acpnt_id = vvap.fk_acpnt_id
        AND prsui.net_value IS NOT NULL
        AND prsui.vehicle_category IS NOT NULL
        AND prsui.FK_INVCE_ID IS NOT NULL
        AND prsui.net_value > 0
        AND not exists (select 1 from TB0271_CONTESTACAOCONV where TB0271_CD_ITEMCONTESTADO = prsui.ID)
        AND gpapt.ID = 263  --CONCESSIONARIA SEM SER NAO
        AND PRSUI.EVENT_DATE > TO_DATE('01/01/2020', 'DD/MM/YYYY') --2020
        and rownum < 2
    ORDER BY prsui.event_date desc
    ")

    while response = (cursor.fetch())
        @retorno = response.join('|')
        puts @retorno
    end

    cursor.close
    @connection.logoff 
end


def buscar_cliente_transacoes_pedagio_com_fatura
    query_transacao_pedagio_com_fatura

    @retornoCompleto = @retorno.split("|")
    @cliente, data = @retornoCompleto        

    return @cliente
end

def data_transacoes_pedagio_com_fatura
    query_transacao_pedagio_com_fatura

    @retornoCompleto = @retorno.split("|")
    cliente, @data = @retornoCompleto        

    return @data
end


def query_transacao_pedagio_sem_fatura
    conectar_banco_dados

    cursor = @connection.exec("
        select ui.NRC, to_char(ui.event_date, 'DD/MM/YYYY') as data
        from prs_usage_item ui
        where FK_RATEV_ID = '103001' 
        and FK_INVCE_ID IS NULL
        AND EVENT_DATE > sysdate - 60
        and status = 4
        and rownum < 2
    ")

    while response = (cursor.fetch())
        @retorno = response.join('|')
        puts @retorno
    end

    cursor.close
    @connection.logoff 
end


def buscar_cliente_transacoes_pedagio_sem_fatura
    query_transacao_pedagio_sem_fatura

    @retornoCompleto = @retorno.split("|")
    @cliente, data = @retornoCompleto        

    return @cliente
end

def data_transacoes_pedagio_sem_fatura
    query_transacao_pedagio_sem_fatura

    @retornoCompleto = @retorno.split("|")
    cliente, @data = @retornoCompleto        

    return @data
end


def query_transacao_pedagio_NAO
    conectar_banco_dados

    cursor = @connection.exec("
        SELECT 
        PRSUI.NRC AS CLIENTE,
        to_char(PRSUI.EVENT_DATE,'DD/MM/YYYY') AS DATA
    FROM 
        prs_usage_item prsui, 
        gpa_partnership gpapt, 
        gpa_usage_point gpaup,
        vcl_vehicle_access_point vvap,
        vcl_vehicle vv,
        cnt_access_point_identificator capi
    WHERE prsui.fk_gpapt_id = gpapt.ID
        AND prsui.fk_gpaup_id = gpaup.ID
        AND prsui.access_point_id =  vvap.fk_acpnt_id               
        AND vvap.fk_vclvc_id = vv.ID
        AND capi.fk_acpnt_id = vvap.fk_acpnt_id
        AND prsui.net_value IS NOT NULL
        AND prsui.vehicle_category IS NOT NULL
        AND prsui.net_value > 0
        AND not exists (select 1 from TB0271_CONTESTACAOCONV where TB0271_CD_ITEMCONTESTADO = prsui.ID and TB0271_DT_CRIACAO > sysdate - 5)
        AND gpapt.ID = 269  --('259', '269', '271') --CONCESSIONARIAS NAO
        AND PRSUI.EVENT_DATE < TO_DATE('10/10/2020', 'DD/MM/YYYY') --2020
        and exists (select 1 from cst_customer c where c.Id = prsui.FK_CUST_ID and c.PERSON_TYPE = 1)
        and rownum < 2
    ORDER BY prsui.event_date desc
    ")

    while response = (cursor.fetch())
        @retorno = response.join('|')
        puts @retorno
    end

    cursor.close
    @connection.logoff 
end


def buscar_cliente_transacoes_pedagio_NAO
    query_transacao_pedagio_NAO

    @retornoCompleto = @retorno.split("|")
    @cliente, data = @retornoCompleto        

    return @cliente
end

def data_transacoes_pedagio_NAO
    query_transacao_pedagio_NAO

    @retornoCompleto = @retorno.split("|")
    cliente, @data = @retornoCompleto        

    return @data
end

    def query_transacao_pedagio
        conectar_banco_dados

        cursor = @connection.exec("
            SELECT 
            PRSUI.NRC AS CLIENTE,
            to_char(PRSUI.EVENT_DATE,'DD/MM/YYYY') AS DATA
        FROM 
            prs_usage_item prsui, 
            gpa_partnership gpapt, 
            gpa_usage_point gpaup,
            vcl_vehicle_access_point vvap,
            vcl_vehicle vv,
            cnt_access_point_identificator capi
        WHERE prsui.fk_gpapt_id = gpapt.ID
            AND prsui.fk_gpaup_id = gpaup.ID
            AND prsui.access_point_id =  vvap.fk_acpnt_id               
            AND vvap.fk_vclvc_id = vv.ID
            AND capi.fk_acpnt_id = vvap.fk_acpnt_id
            AND prsui.net_value IS NOT NULL
            AND prsui.vehicle_category IS NOT NULL
            AND prsui.net_value > 0
            AND not exists (select 1 from TB0271_CONTESTACAOCONV where TB0271_CD_ITEMCONTESTADO = prsui.ID and TB0271_DT_CRIACAO > sysdate - 5)
            AND gpapt.ID = 271  --'259', '265', '266', '269', '275', '277') --CONCESSIONARIAS
            AND PRSUI.EVENT_DATE < TO_DATE('10/10/2020', 'DD/MM/YYYY') --2020
            and exists (select 1 from cst_customer c where c.Id = prsui.FK_CUST_ID and c.PERSON_TYPE = 1)
            and rownum < 2
        ORDER BY prsui.event_date desc
        ")

        while response = (cursor.fetch())
            @retorno = response.join('|')
            puts @retorno
        end

        cursor.close
        @connection.logoff 
    end


    def buscar_cliente_transacao_pedagio
        query_transacao_pedagio

        @retornoCompleto = @retorno.split("|")
        @cliente, data = @retornoCompleto        

        return @cliente
    end

    def data_transacoes_pedagio
        query_transacao_pedagio

        @retornoCompleto = @retorno.split("|")
        cliente, @data = @retornoCompleto        

        return @data
    end


    def query_transacao_pedagio_recontestar
        conectar_banco_dados

        cursor = @connection.exec("
            select c.TB0271_CD_CLIENTE, 
            (select TO_char(a.TB0384_DT_RECEBIMENTOTRANSACAO, 'DD/MM/YYYY') from tb0384_transacaoconcessionaria a where a.TB0384_ID_PASSAGEM = c.TB0271_ID_PASSAGEM) as data_transacao
            --,c.TB0271_ID_PASSAGEM, TB0271_ST_CONTESTACAO
            from TB0271_CONTESTACAOCONV c 
            where c.TB0271_ST_CONTESTACAO = 0 
            and c.TB0271_ID_PASSAGEM IS NOT NULL
            and c.TB0271_ID_PASSAGEM <> 0
            AND c.TB0271_DT_CRIACAO < TO_DATE('10/10/2020', 'DD/MM/YYYY') --ULTIMO REFRESH UAT
            and rownum < 2
            and not exists (select 1 from TB0271_CONTESTACAOCONV cc where cc.TB0271_ID_PASSAGEM = c.TB0271_ID_PASSAGEM and cc.TB0271_ST_CONTESTACAO = 1)
            AND not exists (select 1 from  TB0271_CONTESTACAOCONV dd where dd.TB0271_CD_CONTA = c.TB0271_CD_CONTA and dd.TB0271_DT_CRIACAO > sysdate - 5)  
            order by c.TB0271_DT_CRIACAO desc
        ")

        while response = (cursor.fetch())
            @retorno = response.join('|')
            puts @retorno
        end

        cursor.close
        @connection.logoff 
    end


    def buscar_cliente_pedagio_recontestar
        query_transacao_pedagio_recontestar

        @retornoCompleto = @retorno.split("|")
        @cliente, data = @retornoCompleto        

        return @cliente
    end

    def data_pedagio_recontestar
        query_transacao_pedagio_recontestar

        @retornoCompleto = @retorno.split("|")
        cliente, @data = @retornoCompleto        

        return @data
    end


    def buscar_cliente_pedagio_sem_registro
        conectar_banco_dados
        cursor = @connection.exec("
            SELECT 
            PRSUI.NRC AS CLIENTE
            FROM 
            prs_usage_item prsui, 
            gpa_partnership gpapt, 
            gpa_usage_point gpaup,
            vcl_vehicle_access_point vvap,
            vcl_vehicle vv,
            cnt_access_point_identificator capi
            WHERE prsui.fk_gpapt_id = gpapt.ID
            AND prsui.fk_gpaup_id = gpaup.ID
            AND prsui.access_point_id =  vvap.fk_acpnt_id               
            AND vvap.fk_vclvc_id = vv.ID
            AND capi.fk_acpnt_id = vvap.fk_acpnt_id
            AND prsui.net_value IS NOT NULL
            AND prsui.vehicle_category IS NOT NULL
            AND prsui.net_value > 0
            and event_date > to_date('01/01/2020','dd/mm/yyyy')
            AND gpapt.ID = 263  --'259', '265', '266', '269', '275', '277') --CONCESSIONARIAS
            AND not exists (select 1 from prs_usage_item ui where ui.ID = prsui.ID and ui.FK_RATEV_ID = '103001' and UI.EVENT_DATE BETWEEN '01/09/2020' and '10/09/2020') --2020
            and exists (select 1 from cst_customer c where c.Id = prsui.FK_CUST_ID and c.PERSON_TYPE = 1)
            and rownum < 2
            ORDER BY prsui.event_date asc
            ")
            while response = (cursor.fetch())
                return response
            end
    
            cursor.close
            @connection.logoff 
    end

    def buscar_cliente_pf_pre_debito_com_estadia
        conectar_banco_dados
        cursor = @connection.exec("
        SELECT 
        (SELECT CC.NRC FROM SUP_SCH.CST_CUSTOMER_COMPANY CC WHERE C.ID = CC.FK_CUST_ID) AS NRC
        FROM 
        SUP_SCH.CST_CUSTOMER C, SUP_SCH.CNT_CONTRACT N, SUP_SCH.CAT_PRODUCT P, SUP_SCH.CNT_CONTRACTED_PRODUCT CP,
        VCL_VEHICLE v, VCL_VEHICLE_ACCESS_POINT vap, VCL_VEHICLE_ACCESS_POINT_IDENT vi,
        SUP_SCH.ACC_PAYMENT_MODE MO, SUP_SCH.ACC_ACCOUNT A
        WHERE 1=1
        AND V.FK_CUST_ID = A.FK_CUST_ID
        AND A.ID = MO.FK_ACCNT_ID
        AND A.FK_CUST_ID = C.ID
        AND vi.FK_VCLAP_ID = vap.ID
        AND vap.FK_VCLVC_ID = v.id
        AND C.ID = v.FK_CUST_ID
        AND vi.FINAL_DATE is null
        AND N.FK_CUST_ID = C.ID
        AND N.ID = CP.FK_SVCTR_ID 
        AND CP.FK_PRDCT_ID = P.ID
        AND A.REAL_BALANCE < -50
        AND MO.PAY_MODE = 4	
        AND C.PERSON_TYPE = 1
        and exists (select 1 from prs_usage_item ui where  ui.FK_CUST_ID = c.ID and ui.FK_ACCNT_ID = a.ID and ui.FK_RATEV_ID = '103005' and ui.event_date between '01/09/2020' and '01/10/2020')
        AND ROWNUM < 2
            ")
            while response = (cursor.fetch())
                return response
            end
    
            cursor.close
            @connection.logoff 
    end


    def buscar_cliente_pf_pre_cartao_com_pedagio
        conectar_banco_dados
        cursor = @connection.exec("
            SELECT 
            (SELECT CC.NRC FROM SUP_SCH.CST_CUSTOMER_COMPANY CC WHERE C.ID = CC.FK_CUST_ID) AS NRC
            FROM 
            SUP_SCH.CST_CUSTOMER C, SUP_SCH.CNT_CONTRACT N, SUP_SCH.CAT_PRODUCT P, SUP_SCH.CNT_CONTRACTED_PRODUCT CP,
            VCL_VEHICLE v, VCL_VEHICLE_ACCESS_POINT vap, VCL_VEHICLE_ACCESS_POINT_IDENT vi,
            SUP_SCH.ACC_PAYMENT_MODE MO, SUP_SCH.ACC_ACCOUNT A
            WHERE 1=1
            AND V.FK_CUST_ID = A.FK_CUST_ID
            AND A.ID = MO.FK_ACCNT_ID
            AND A.FK_CUST_ID = C.ID
            AND vi.FK_VCLAP_ID = vap.ID
            AND vap.FK_VCLVC_ID = v.id
                  AND C.ID = v.FK_CUST_ID
                  AND vi.FINAL_DATE is null
                  AND N.FK_CUST_ID = C.ID
                  AND N.ID = CP.FK_SVCTR_ID 
                  AND CP.FK_PRDCT_ID = P.ID
                  AND A.REAL_BALANCE < -50
                  AND MO.PAY_MODE = 3	
                  AND C.PERSON_TYPE = 1
                  and exists (select 1 from prs_usage_item ui where  ui.FK_CUST_ID = c.ID and ui.FK_ACCNT_ID = a.ID and ui.FK_RATEV_ID = '103001' and ui.event_date between '01/09/2020' and '01/10/2020')
                  AND ROWNUM < 2
            ")
            while response = (cursor.fetch())
                return response
            end
    
            cursor.close
            @connection.logoff 
    end



    def query_transacao_estacionamento
        conectar_banco_dados

        cursor = @connection.exec("
            SELECT 
            PRSUI.NRC AS CLIENTE,
            to_char(PRSUI.EVENT_DATE,'DD/MM/YYYY') AS DATA
            FROM 
            prs_usage_item PRSUI
            WHERE 
            prsui.net_value IS NOT NULL
            AND prsui.net_value > 0
            AND not exists (select 1 from TB0271_CONTESTACAOCONV where TB0271_CD_cliente = prsui.nrc and TB0271_DT_CRIACAO > sysdate - 30)
            AND PRSUI.FK_RATEV_ID = '103005'
            AND PRSUI.EVENT_DATE < TO_DATE('10/10/2020', 'DD/MM/YYYY') --ULTIMO REFRESH UAT
            and rownum < 2
            ORDER BY prsui.event_date desc
        ")

        while response = (cursor.fetch())
            @retorno = response.join('|')
            puts @retorno
        end

        cursor.close
        @connection.logoff 
    end


    def buscar_cliente_transacao_estacionamento
        query_transacao_estacionamento

        @retornoCompleto = @retorno.split("|")
        @cliente, data = @retornoCompleto        

        return @cliente
    end

    def data_transacoes_estacionamento
        query_transacao_estacionamento

        @retornoCompleto = @retorno.split("|")
        cliente, @data = @retornoCompleto        

        return @data
    end


    def query_transacao_estacionamento_recontestar
        conectar_banco_dados

        cursor = @connection.exec("
            select c.TB0271_CD_CLIENTE,
            (select TO_char(a.est2_dataent, 'DD/MM/YYYY') from testpd02 a where a.EST2_codigo = c.tb0271_CD_ARQUIVO and a.EST2_SEQ = c.TB0271_SQ_TRANSACAO) as data_transacao
            from TB0271_CONTESTACAOCONV c 
            where c.TB0271_ST_CONTESTACAO = 0 
            AND c.TB0025_TP_CONVENIADO = 2
            AND c.TB0271_DT_CRIACAO < TO_DATE('10/10/2020', 'DD/MM/YYYY') --ULTIMO REFRESH UAT
            and not exists (select 1 from TB0271_CONTESTACAOCONV cc where cc.TB0271_CD_CONTA = c.TB0271_CD_CONTA and cc.TB0271_ST_CONTESTACAO = 1)
            AND not exists (select 1 from  TB0271_CONTESTACAOCONV dd where dd.TB0271_CD_CONTA = c.TB0271_CD_CONTA and dd.TB0271_DT_CRIACAO > sysdate - 30)  
            and rownum < 2
            order by c.TB0271_DT_CRIACAO desc
        ")

        while response = (cursor.fetch())
            @retorno = response.join('|')
            puts @retorno
        end

        cursor.close
        @connection.logoff 
    end


    def buscar_cliente_estacionamento_recontestar
        query_transacao_estacionamento_recontestar

        @retornoCompleto = @retorno.split("|")
        @cliente, data = @retornoCompleto        

        return @cliente
    end

    def data_estacionamento_recontestar
        query_transacao_estacionamento_recontestar

        @retornoCompleto = @retorno.split("|")
        cliente, @data = @retornoCompleto        

        return @data
    end


    def query_transacao_abastecimento
        conectar_banco_dados

        cursor = @connection.exec("
            SELECT 
            PRSUI.NRC AS CLIENTE,
            to_char(PRSUI.EVENT_DATE,'DD/MM/YYYY') AS DATA
            FROM 
            prs_usage_item PRSUI
            WHERE 
            prsui.net_value IS NOT NULL
            AND prsui.net_value > 0
            AND not exists (select 1 from TB0271_CONTESTACAOCONV where TB0271_CD_cliente = prsui.nrc and TB0271_DT_CRIACAO > sysdate - 30)
            AND PRSUI.FK_RATEV_ID = '100002002'
            AND PRSUI.EVENT_DATE < TO_DATE('10/10/2020', 'DD/MM/YYYY') --ULTIMO REFRESH UAT
            and rownum < 2
            ORDER BY prsui.event_date desc
        ")

        while response = (cursor.fetch())
            @retorno = response.join('|')
            puts @retorno
        end

        cursor.close
        @connection.logoff 
    end


    def buscar_cliente_transacao_abastecimento
        query_transacao_abastecimento

        @retornoCompleto = @retorno.split("|")
        @cliente, data = @retornoCompleto        

        return @cliente
    end

    def data_transacoes_abastecimento
        query_transacao_abastecimento

        @retornoCompleto = @retorno.split("|")
        cliente, @data = @retornoCompleto        

        return @data
    end


    def query_transacao_abastecimento_recontestar
        conectar_banco_dados

        cursor = @connection.exec("
            select c.TB0271_CD_CLIENTE,
            (select to_char(prsui.event_date, 'DD/MM/YYYY') from prs_usage_item PRSUI where TB0271_CD_ITEMCONTESTADO = prsui.ID) as data_transacao
            from TB0271_CONTESTACAOCONV c 
            where c.TB0271_ST_CONTESTACAO = 0 
            AND c.TB0025_TP_CONVENIADO = 3
            AND EXISTS (SELECT 1 FROM PRS_USAGE_ITEM UI WHERE TB0271_CD_ITEMCONTESTADO = ui.ID AND UI.FK_RATEV_ID = '100002002')
            AND not exists (select 1 from  TB0271_CONTESTACAOCONV dd where dd.TB0271_CD_CONTA = c.TB0271_CD_CONTA and dd.TB0271_DT_CRIACAO > sysdate - 30)  
            and rownum < 2
            order by c.TB0271_DT_CRIACAO desc
        ")

        while response = (cursor.fetch())
            @retorno = response.join('|')
            puts @retorno
        end

        cursor.close
        @connection.logoff 
    end


    def buscar_cliente_abastecimento_recontestar
        query_transacao_abastecimento_recontestar

        @retornoCompleto = @retorno.split("|")
        @cliente, data = @retornoCompleto        

        return @cliente
    end

    def data_abastecimento_recontestar
        query_transacao_abastecimento_recontestar

        @retornoCompleto = @retorno.split("|")
        cliente, @data = @retornoCompleto        

        return @data
    end


    def query_transacao_drive_thru
        conectar_banco_dados

        cursor = @connection.exec("
            SELECT 
            PRSUI.NRC AS CLIENTE,
            to_char(PRSUI.EVENT_DATE,'DD/MM/YYYY') AS DATA
            FROM 
            prs_usage_item PRSUI
            WHERE 
            prsui.net_value IS NOT NULL
            AND prsui.net_value > 0
            AND not exists (select 1 from TB0271_CONTESTACAOCONV where TB0271_CD_cliente = prsui.nrc and TB0271_DT_CRIACAO > sysdate - 30)
            AND PRSUI.FK_RATEV_ID = '100075000'
            AND PRSUI.EVENT_DATE < TO_DATE('10/10/2020', 'DD/MM/YYYY') --ULTIMO REFRESH UAT
            and rownum < 2
            ORDER BY prsui.event_date desc
        ")

        while response = (cursor.fetch())
            @retorno = response.join('|')
            puts @retorno
        end

        cursor.close
        @connection.logoff 
    end


    def buscar_cliente_transacao_drive_thru
        query_transacao_drive_thru

        @retornoCompleto = @retorno.split("|")
        @cliente, data = @retornoCompleto        

        return @cliente
    end

    def data_transacoes_drive_thru
        query_transacao_drive_thru

        @retornoCompleto = @retorno.split("|")
        cliente, @data = @retornoCompleto        

        return @data
    end


    def query_transacao_drive_thru_recontestar
        conectar_banco_dados

        cursor = @connection.exec("
            select c.TB0271_CD_CLIENTE,
            (select to_char(prsui.event_date, 'DD/MM/YYYY') from prs_usage_item PRSUI where TB0271_CD_ITEMCONTESTADO = prsui.ID) as data_transacao
            from TB0271_CONTESTACAOCONV c 
            where c.TB0271_ST_CONTESTACAO = 0 
            AND c.TB0025_TP_CONVENIADO = 3
            AND EXISTS (SELECT 1 FROM PRS_USAGE_ITEM UI WHERE TB0271_CD_ITEMCONTESTADO = ui.ID AND UI.FK_RATEV_ID = '100075000')
            AND not exists (select 1 from  TB0271_CONTESTACAOCONV dd where dd.TB0271_CD_CONTA = c.TB0271_CD_CONTA and dd.TB0271_DT_CRIACAO > sysdate - 5)  
            and rownum < 2
            order by c.TB0271_DT_CRIACAO desc
        ")

        while response = (cursor.fetch())
            @retorno = response.join('|')
            puts @retorno
        end

        cursor.close
        @connection.logoff 
    end


    def buscar_cliente_drive_thru_recontestar
        query_transacao_drive_thru_recontestar

        @retornoCompleto = @retorno.split("|")
        @cliente, data = @retornoCompleto        

        return @cliente
    end

    def data_drive_thru_recontestar
        query_transacao_drive_thru_recontestar

        @retornoCompleto = @retorno.split("|")
        cliente, @data = @retornoCompleto        

        return @data
    end


    def query_transacao_lava_rapido
        conectar_banco_dados

        cursor = @connection.exec("
            SELECT 
            PRSUI.NRC AS CLIENTE,
            to_char(PRSUI.EVENT_DATE,'DD/MM/YYYY') AS DATA
            FROM 
            prs_usage_item PRSUI
            WHERE 
            prsui.net_value IS NOT NULL
            AND prsui.net_value > 0
            AND not exists (select 1 from TB0271_CONTESTACAOCONV where TB0271_CD_cliente = prsui.nrc and TB0271_DT_CRIACAO > sysdate - 30)
            AND PRSUI.FK_RATEV_ID = '100237000'
            AND PRSUI.EVENT_DATE < TO_DATE('10/10/2020', 'DD/MM/YYYY') --ULTIMO REFRESH UAT
            and rownum < 2
            ORDER BY prsui.event_date desc
        ")

        while response = (cursor.fetch())
            @retorno = response.join('|')
            puts @retorno
        end

        cursor.close
        @connection.logoff 
    end


    def buscar_cliente_transacao_lava_rapido
        query_transacao_lava_rapido

        @retornoCompleto = @retorno.split("|")
        @cliente, data = @retornoCompleto        

        return @cliente
    end

    def data_transacoes_lava_rapido
        query_transacao_lava_rapido

        @retornoCompleto = @retorno.split("|")
        cliente, @data = @retornoCompleto        

        return @data
    end


    def query_transacao_lava_rapido_recontestar
        conectar_banco_dados

        cursor = @connection.exec("
            select c.TB0271_CD_CLIENTE,
            (select to_char(prsui.event_date, 'DD/MM/YYYY') from prs_usage_item PRSUI where TB0271_CD_ITEMCONTESTADO = prsui.ID) as data_transacao
            from TB0271_CONTESTACAOCONV c 
            where c.TB0271_ST_CONTESTACAO = 0 
            AND c.TB0025_TP_CONVENIADO = 3
            AND EXISTS (SELECT 1 FROM PRS_USAGE_ITEM UI WHERE TB0271_CD_ITEMCONTESTADO = ui.ID AND UI.FK_RATEV_ID = '100237000')
            AND not exists (select 1 from  TB0271_CONTESTACAOCONV dd where dd.TB0271_CD_CONTA = c.TB0271_CD_CONTA and dd.TB0271_DT_CRIACAO > sysdate - 5)  
            and rownum < 2
            order by c.TB0271_DT_CRIACAO desc
        ")

        while response = (cursor.fetch())
            @retorno = response.join('|')
            puts @retorno
        end

        cursor.close
        @connection.logoff 
    end


    def buscar_cliente_lava_rapido_recontestar
        query_transacao_lava_rapido_recontestar

        @retornoCompleto = @retorno.split("|")
        @cliente, data = @retornoCompleto        

        return @cliente
    end

    def data_lava_rapido_recontestar
        query_transacao_lava_rapido_recontestar

        @retornoCompleto = @retorno.split("|")
        cliente, @data = @retornoCompleto        

        return @data
    end



    def retorna_cliente_valido
        
        buscar_cliente_valido
        @retornoCompleto = @retorno.split("|")
        @cliente, placa, dispositivo = @retornoCompleto        

        return @cliente
    end

    def retorna_placa_valida
        
        buscar_cliente_valido
        @retornoCompleto = @retorno.split("|")
        cliente, @placa, dispositivo = @retornoCompleto        

        return @placa
    end

    def retorna_dispositivo_valido
        
        buscar_cliente_valido
        @retornoCompleto = @retorno.split("|")
        cliente, placa, @dispositivo = @retornoCompleto        

        return @dispositivo
    end


    def retorna_cliente_atendimento
        
        buscar_dados_atendimento
        @retornoCompleto = @retorno.split("|")
        @cliente, protocolo, ocorrencia, data_inicio = @retornoCompleto        

        return @cliente
    end

    def retorna_protocolo_atendimento
        
        buscar_dados_atendimento
        @retornoCompleto = @retorno.split("|")
        cliente, @protocolo, ocorrencia, data_inicio = @retornoCompleto        

        return @protocolo
    end


    def retorna_ocorrencia_atendimento
        
        buscar_dados_atendimento
        @retornoCompleto = @retorno.split("|")
        cliente, protocolo, @ocorrencia, data_inicio = @retornoCompleto        

        return @ocorrencia
    end


    def retorna_data_atendimento
        
        buscar_dados_atendimento
        @retornoCompleto = @retorno.split("|")
        cliente, protocolo, ocorrencia, @data_inicio = @retornoCompleto  
        
        return @data_inicio
    end


    def retorna_cliente_atendimento_funcionalidade
        buscar_funcionalidade_atendimento

        @retornoCompleto = @retorno.split("|")
        @cliente, funcionalidade, demanda, data_inicio = @retornoCompleto  

        return @cliente
    end

    def retorna_funcionalidade_atendimento
        buscar_funcionalidade_atendimento

        @retornoCompleto = @retorno.split("|")
        cliente, @funcionalidade, demanda, data_inicio = @retornoCompleto  

        return @funcionalidade
    end

    def retorna_demanda_atendimento
        buscar_funcionalidade_atendimento
        @retornoCompleto = @retorno.split("|")
        cliente, funcionalidade, @demanda, data_inicio = @retornoCompleto  

        return @demanda
    end

    def retorna_data_atendimento_funcionalidade
        buscar_funcionalidade_atendimento

        @retornoCompleto = @retorno.split("|")
        cliente, funcionalidade, demanda, @data_inicio = @retornoCompleto  

        return @data_inicio
    end

    def retorna_cliente_paginacao_atendimento
        buscar_cliente_atendimento_paginacao

        @retornoCompleto = @retorno.split("|")
        @cliente, data_inicio = @retornoCompleto  

        return @cliente
    end
    
    def retorna_data_paginacao_atendimento
        buscar_cliente_atendimento_paginacao

        @retornoCompleto = @retorno.split("|")
        cliente, @data_inicio = @retornoCompleto  

        return @data_inicio
    end


    #############################################
    #               QUERYS - JV CAIXA                      
    #############################################

    def buscar_dados_atendimento_caixa
                
        conectar_banco_dados

        cursor = @connection.exec("
            SELECT aa.TB0086_cd_cliente, bb.TB0086_NR_PROTOCOLO, cc.TB0090_NR_CONTROLEWORKFLOW as ocorrência 
            --to_char(aa.TB0085_DT_INICIOATENDIMENTO,'DD/MM/YYYY')
            FROM cadmo.tb0086_atendimentocliente aa, TB0088_ATENDIMENTODEMANDA bb, CST_CUSTOMER_COMPANY ccc, TB0090_WORKFLOWATENDIMENTO cc
            WHERE aa.TB0086_NR_PROTOCOLO = bb.TB0086_NR_PROTOCOLO
            and bb.TB0088_CD_ATENDIMENTODEMANDA = cc.TB0088_CD_ATENDIMENTODEMANDA
            and ccc.NRC = aa.TB0086_cd_cliente
            and ccc.FK_COMP_ID = '100006000'
            --and aa.TB0085_DT_FIMCONTATOCLIENTE is not null
            and aa.TB0085_DT_INICIOATENDIMENTO > sysdate - 30
            and ROWNUM < 2
        ")

        while response = (cursor.fetch())
            @retorno = response.join('|')
        end

        cursor.close
        @connection.logoff 
        
    end


    def retorna_cliente_atendimento_caixa
        
        buscar_dados_atendimento_caixa
        @retornoCompleto = @retorno.split("|")
        @cliente, protocolo, ocorrencia, data_inicio = @retornoCompleto        

        return @cliente
    end

    def retorna_protocolo_atendimento_caixa
        
        buscar_dados_atendimento_caixa
        @retornoCompleto = @retorno.split("|")
        cliente, @protocolo, ocorrencia, data_inicio = @retornoCompleto        

        return @protocolo
    end


    def retorna_ocorrencia_atendimento_caixa
        
        buscar_dados_atendimento_caixa
        @retornoCompleto = @retorno.split("|")
        cliente, protocolo, @ocorrencia, data_inicio = @retornoCompleto        

        return @ocorrencia
    end


    def retorna_data_atendimento_caixa
        
        buscar_dados_atendimento_caixa
        @retornoCompleto = @retorno.split("|")
        cliente, protocolo, ocorrencia, @data_inicio = @retornoCompleto  
        
        return @data_inicio
    end




end