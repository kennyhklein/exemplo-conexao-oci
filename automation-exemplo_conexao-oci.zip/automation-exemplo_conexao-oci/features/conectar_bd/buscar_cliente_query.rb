require 'ruby-oci8'

class BancoDeDados

    def conectar_banco_dados

                ##UAT
                #@connection = OCI8.new('<usuario do BD>', '<senha usuário do BD>', "//<nome do host>/<nome do serviço>")

                #EXEMPLO
                #@connection = OCI8.new('kenny_verotthi', 'KverENtthiNi30#', "//ORADB_EXEC6A4/EXEC6A4")
       
    end 



    def buscar_cliente_valido
        conectar_banco_dados
        cursor = @connection.exec("
            SELECT 
            (SELECT CC.NRC FROM SUP_SCH.CST_CUSTOMER_COMPANY CC WHERE C.ID = CC.FK_CUST_ID) AS NRC, v.plate as placa, 
            (select api.name from CNT_ACCESS_POINT_IDENTIFICATOR api where vi.fk_cntid_id = API.ID) as dispositivo
            FROM 
            SUP_SCH.CST_CUSTOMER C, SUP_SCH.CNT_CONTRACT N, SUP_SCH.CAT_PRODUCT P, SUP_SCH.CNT_CONTRACTED_PRODUCT CP,
            VCL_VEHICLE v, VCL_VEHICLE_ACCESS_POINT vap, VCL_VEHICLE_ACCESS_POINT_IDENT vi,
            SUP_SCH.ACC_PAYMENT_MODE MO, SUP_SCH.ACC_ACCOUNT A
            WHERE 1=1
            AND V.FK_CUST_ID = A.FK_CUST_ID
            AND A.ID = MO.FK_ACCNT_ID
            AND A.FK_CUST_ID = C.ID
            AND vi.FK_VCLAP_ID = vap.ID
            AND vap.FK_VCLVC_ID = v.id
                  AND C.ID = v.FK_CUST_ID
                  AND vi.FINAL_DATE is null
                  AND N.FK_CUST_ID = C.ID
                  AND N.ID = CP.FK_SVCTR_ID 
                  AND CP.FK_PRDCT_ID = P.ID
                  AND A.REAL_BALANCE < 0
                 AND EXISTS (select CC.FK_CUST_ID, count(1) from 
                          VCL_VEHICLE v, VCL_VEHICLE_ACCESS_POINT vap, VCL_VEHICLE_ACCESS_POINT_IDENT vi, CST_CUSTOMER_COMPANY cc
                          where vi.FK_VCLAP_ID = vap.ID
                          and vap.FK_VCLVC_ID = v.id
                          and vi.FINAL_DATE is null
                          and CC.FK_CUST_ID = v.FK_CUST_ID
                          and CC.FK_CUST_ID = C.ID
                          group by cc.FK_CUST_ID
                          having count(1) > 1)   
                            AND not exists(select 1 from CNT_CONTRACTED_PROD_STATUS_HIS CTSTH
                            where CTSTH.FK_CTPRD_ID = CP.ID 
                             AND CP.FK_PRDCT_ID = P.ID
                            AND N.ID = CP.FK_SVCTR_ID
                            AND N.FK_CUST_ID = C.ID
                            AND CTSTH.FK_CNTST_ID in (2,3) AND CTSTH.VALIDITY_END_DATE IS NULL)
                  AND ROWNUM < 2
            ")
        while response = (cursor.fetch())
            @retorno = response.join('|')
            return response
        end

        cursor.close
        @connection.logoff 
    end

        
    def retorna_cliente_valido
        
        buscar_cliente_valido
        @retornoCompleto = @retorno.split("|")
        @cliente, placa, dispositivo = @retornoCompleto        

        return @cliente
    end

    def retorna_placa_valida
        
        buscar_cliente_valido
        @retornoCompleto = @retorno.split("|")
        cliente, @placa, dispositivo = @retornoCompleto        

        return @placa
    end

    def retorna_dispositivo_valido
        
        buscar_cliente_valido
        @retornoCompleto = @retorno.split("|")
        cliente, placa, @dispositivo = @retornoCompleto        

        return @dispositivo
    end


end