# require 'report_builder'

# # Ex 1:
# ReportBuilder.configure do |config|
#   config.input_path = 'reports/features_report.json'
#   config.report_path = 'reports/features_report_call_center'
#   config.report_types = [:json, :html]
#   config.report_title = 'Test Results - Call Center'
#   config.additional_info = {browser: 'Chrome', environment: 'Stage 1'}
# end

# #Gruped Features Report
# # ReportBuilder.configure do |config|
# #     config.input_path = {
# #      'Group A' => 'reports/features_buscar_cliente_report',
# #      'Group B' => 'reports/features_consultar_atendimento_report',
# #      'Group C' => 'reports/features_contestar_transacoes_report'
# #     }
# # end

# ReportBuilder.build_report

