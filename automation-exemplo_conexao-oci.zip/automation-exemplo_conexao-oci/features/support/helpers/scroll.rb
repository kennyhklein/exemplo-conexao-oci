class Scroll
  def scroll_to(elemento)
    Capybara.current_session.driver.browser.execute_script("document.querySelector('#{elemento.instance_variable_get(:@query).locator}').scrollIntoView()")
  end
end