module Screenshot
  def print(scenario)
    scenario.failed? ? result = "failed" : result = "passed"
    foto = Capybara.current_session.save_screenshot("screenshot/#{scenario.name.downcase!}_#{result}.png")
    embed(foto, 'image/png', 'SCREENSHOT')
  end

  def self.delete_all_cookies
    Capybara.current_session.driver.browser.manage.delete_all_cookies
  end
end