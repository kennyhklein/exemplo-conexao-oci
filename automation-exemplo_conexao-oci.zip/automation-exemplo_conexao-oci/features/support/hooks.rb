require_relative 'helpers/screenshot.rb'
# require 'report_builder'

World(Screenshot)

After do |scenario|
  
  print(scenario)
  Screenshot.delete_all_cookies
end

# After do
#   ReportBuilder.configure do |config|
#     config.input_path = 'reports/features_report.json'
#     config.report_path = 'reports/features_report_call_center'
#   end
#   ReportBuilder.build_report
# end