require "capybara/cucumber"
#require 'pry'
#require 'rspec'
require 'selenium-webdriver'
require 'site_prism'
require "capybara"
#require "yaml"
require 'ruby-oci8'
#require 'httparty'

ENVIRONMENT_TYPE ||= ENV['ENVIRONMENT_TYPE']

URL = YAML.load_file "./features/support/config/dataset.yml"

CUCUMBER_PUBLISH_ENABLED=true

HEADLESS = ENV['HEADLESS'] ? true : false

Capybara.register_driver :selenium do |app|
  options = Selenium::WebDriver::Chrome::Options.new(args: [])
    if HEADLESS
      options.add_argument('--headless')
    end

  options.add_argument('--no-sandbox')
  options.add_argument('ignore-certificate-errors')
  options.add_argument('disable-popup-blocking')
  options.add_argument('disable-translate')
  options.add_argument('disable-infobars')
  Capybara::Selenium::Driver.new(app, :browser => :chrome, options: options)
end

Capybara.default_driver = :selenium

Capybara.configure do |config|
  config.default_max_wait_time = 10
end

Capybara.page.driver.browser.manage.window.maximize

today = Time.now.strftime('%Y_%m_%d').to_s
Capybara.save_path = File.expand_path("./reports/results/#{today}")